package DBAction;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import net.sf.json.JSONObject;

public class dbAction {

    private static String dbDriver = "com.mysql.jdbc.Driver";
    private static String dbUrl = "jdbc:mysql://localhost:3306/GraduationDesign?zeroDateTimeBehavior=convertToNull&characterEncoding=utf-8";//根据实际情况变化  
    private static String dbUser = "root";
    private static String dbPass = "root";

    public static Connection getConn() {
        Connection conn = null;
        try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public static String signUp(String username, String password, String email, String phone, String status, double balance, String thumbnailPath) throws SQLException, FileNotFoundException {

        String sql = "select * from user_profile where username='" + username + "'";
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                con.close();
                return "usernameHasExisted";
            } else {
                sql = "select * from user_profile where email='" + email + "'";
                rs = stmt.executeQuery(sql);
                if (rs.next()) {
                    con.close();
                    return "emailHasExisted";
                } else {
                    sql = "select * from user_profile where phone='" + phone + "'";
                    rs = stmt.executeQuery(sql);
                    if (rs.next()) {
                        con.close();
                        return "phoneHasExisted";
                    } else {

                        PreparedStatement ps = con.prepareStatement("insert into user_profile (`username`, `password`, `email`, `phone`, `status`, `balance`,`thumbnail`)"
                                + " values (?,?,?,?,?,?,?)");
                        ps.setString(1, username);
                        ps.setString(2, password);
                        ps.setString(3, email);
                        ps.setString(4, phone);
                        ps.setString(5, status);
                        ps.setDouble(6, balance);

                        if (!thumbnailPath.equals("")) {
                            File file = new File(thumbnailPath);
                            FileInputStream fis = new FileInputStream(file);
                            ps.setBinaryStream(7, fis, (int) file.length());
                        } else {
                            ps.setBinaryStream(7, null, 0);
                        }

                        ps.executeUpdate();
                        con.close();
                        return "success";
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            con.close();
        }
        return "failure";

    }

    public static Map<String, Object> login(String username, String password) throws SQLException {
        String sql = "select * from user_profile where username='" + username + "'";
        Connection con = getConn();
        Map<String, Object> userProfileMap = new HashMap<String, Object>();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {

                String passwordInDB = rs.getString("password");
                if (passwordInDB.equals(password)) {
                    String status = rs.getString("status");
                    int userID = rs.getInt("id");
                    double balance = rs.getDouble("balance");
                    userProfileMap.put("checkResponse", "success");
                    userProfileMap.put("status", status);
                    userProfileMap.put("username", username);
                    userProfileMap.put("balance", balance);
                    userProfileMap.put("userID", userID);
                    userProfileMap.put("loginType", "username");
                    con.close();
                    return userProfileMap;
                } else {
                    con.close();
                    userProfileMap.put("checkResponse", "passwordIncorrect");
                    return userProfileMap;
                }

            } else {
                sql = "select * from user_profile where email='" + username + "'";
                con = getConn();
                stmt = con.createStatement();
                rs = stmt.executeQuery(sql);
                if (rs.next()) {

                    String passwordInDB = rs.getString("password");
                    if (passwordInDB.equals(password)) {
                        String status = rs.getString("status");
                        String realUsername = rs.getString("username");
                        int userID = rs.getInt("id");
                        double balance = rs.getDouble("balance");
                        userProfileMap.put("balance", balance);
                        userProfileMap.put("username", realUsername);
                        userProfileMap.put("checkResponse", "success");
                        userProfileMap.put("status", status);
                        userProfileMap.put("userID", userID);

                        userProfileMap.put("loginType", "email");
                        con.close();
                        return userProfileMap;
                    } else {
                        con.close();
                        userProfileMap.put("checkResponse", "passwordIncorrect");
                        return userProfileMap;
                    }

                } else {
                    sql = "select * from user_profile where phone='" + username + "'";
                    con = getConn();
                    stmt = con.createStatement();
                    rs = stmt.executeQuery(sql);
                    if (rs.next()) {

                        String passwordInDB = rs.getString("password");
                        if (passwordInDB.equals(password)) {
                            String status = rs.getString("status");
                            String realUsername = rs.getString("username");
                            int userID = rs.getInt("id");
                            double balance = rs.getDouble("balance");
                            userProfileMap.put("balance", balance);
                            userProfileMap.put("checkResponse", "success");
                            userProfileMap.put("status", status);
                            userProfileMap.put("username", realUsername);
                            userProfileMap.put("userID", userID);
                            userProfileMap.put("loginType", "phone");
                            con.close();
                            return userProfileMap;
                        } else {
                            con.close();
                            userProfileMap.put("checkResponse", "passwordIncorrect");
                            return userProfileMap;
                        }

                    }
                }
            }

        } catch (SQLException e) {
            con.close();
            userProfileMap.put("checkResponse", "SQLFailure");
            return userProfileMap;
        }
        userProfileMap.put("checkResponse", "notExistedFailure");
        return userProfileMap;
    }

    public static Map<String, Object> getUserInfo(int userID) throws SQLException {
        String sql = "select * from user_profile where id=" + userID + "";
        Connection con = getConn();
        Map<String, Object> userProfileMap = new HashMap<String, Object>();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                String username = rs.getString("username");
                String password = rs.getString("password");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                Double balance = rs.getDouble("balance");
                Blob userThumbnail = rs.getBlob("thumbnail");
                userProfileMap.put("getUserResponse", "success");
                userProfileMap.put("username", username);
                userProfileMap.put("password", password);
                userProfileMap.put("email", email);
                userProfileMap.put("phone", phone);
                userProfileMap.put("balance", balance);
                userProfileMap.put("thumbnail", userThumbnail);
                con.close();
                return userProfileMap;
            }
        } catch (SQLException e) {
            con.close();
            userProfileMap.put("getUserResponse", "SQLFailure");
            return userProfileMap;
        }
        userProfileMap.put("getUserResponse", "notExistedFailure");
        return userProfileMap;
    }

    public static Map<String, Object> getItemsInfoThroghID(int itemID) throws SQLException {

        String sql = "select * from items where id = " + itemID;

        Connection con = getConn();
        try {

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                Map<String, Object> aRowMap = new HashMap<String, Object>();

                aRowMap.put("msg", "success");

                aRowMap.put("idInDB", rs.getInt("id"));
                aRowMap.put("name", rs.getString("name"));
                aRowMap.put("price", rs.getDouble("price"));
                aRowMap.put("introduction", rs.getString("introduction"));
                aRowMap.put("seller", rs.getString("seller"));
                aRowMap.put("thumbnail", rs.getBlob("thumbnail"));
                aRowMap.put("author", rs.getString("author"));
                aRowMap.put("numbersInCache", rs.getInt("numbersInCache"));
                return aRowMap;
            }

        } catch (SQLException e) {
            con.close();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("msg", "sqlFalse");
            return aRowMap;
        }
        return null;

    }

    public static List<Map<String, Object>> getItemsInfo(String params) throws SQLException {

        String sql = "";

        switch (params) {
            case "getAll":
                sql = "select * from items ";
                break;
            default:
                JSONObject paramsJSON_getItems = JSONObject.fromObject(params);
                String action = paramsJSON_getItems.getString("action");

                switch (action) {
                    case "initialize":
                        String username_initialize = paramsJSON_getItems.getString("username");
                        sql = "select * from items where seller != '" + username_initialize + "' order by id desc limit 20";

                        break;
                    case "refresh":
                        String username_refresh = paramsJSON_getItems.getString("username");
                        sql = "select * from items where seller != '" + username_refresh + "' order by id desc limit 20";

                        break;
                    case "loadMore":
                        int minId = paramsJSON_getItems.getInt("minId");
                        String username_loadMore = paramsJSON_getItems.getString("username");
                        sql = "select * from items where id < " + minId + " and seller != '" + username_loadMore + "' order by id desc limit 10";
                        break;

                    case "getMyItems_initialize":
                        String username_getMyItems_initialize = paramsJSON_getItems.getString("username");
                        sql = "select * from (select * from items where seller = '" + username_getMyItems_initialize + "') as myitem "
                                + "order by id desc limit 20";
                        break;

                    case "getMyItems_refresh":
                        String username_getMyItems_refresh = paramsJSON_getItems.getString("username");

                        sql = "select * from (select * from items where seller = '" + username_getMyItems_refresh + "') as myitem "
                                + "order by id desc limit 20";
                        break;

                    case "getMyItems_loadMore":
                        String username_getMyItems_loadMore = paramsJSON_getItems.getString("username");
                        int minId_loadMore = paramsJSON_getItems.getInt("minId");
                        sql = "select * from (select * from items where seller = '" + username_getMyItems_loadMore + "') as myitem where id<" + minId_loadMore
                                + " order by id desc limit 10";
                        break;

                }

                break;

        }
        Connection con = getConn();
        try {

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            boolean existsFlag = false;
            List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

            while (rs.next()) {
                existsFlag = true;
                Map<String, Object> aRowMap = new HashMap<String, Object>();
                if (rs.isFirst()) {
                    aRowMap.put("msg", "success");
                }
                aRowMap.put("idInDB", rs.getInt("id"));
                aRowMap.put("name", rs.getString("name"));
                aRowMap.put("price", rs.getDouble("price"));
                aRowMap.put("introduction", rs.getString("introduction"));
                aRowMap.put("seller", rs.getString("seller"));
                aRowMap.put("thumbnail", rs.getBlob("thumbnail"));
                aRowMap.put("author", rs.getString("author"));
                aRowMap.put("numbersInCache", rs.getInt("numbersInCache"));
                list.add(aRowMap);
            }
            if (existsFlag) {

                return list;
            }
        } catch (SQLException e) {
            con.close();
            List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("msg", "sqlFalse");
            list2.add(aRowMap);
            return list2;
        }
        return null;
    }

    public static String addItem(String name, double price, String intro, String seller, String thumbnailPath, String author, int numbersInCache) throws SQLException, FileNotFoundException {
        String sql = "select * from items where name = '" + name + "'";
        Connection con = getConn();
        try {

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                return "itemsNameHasExisted";
            } else if (!thumbnailPath.equals("")) {
                File file = new File(thumbnailPath);
                FileInputStream fis = new FileInputStream(file);

                PreparedStatement ps = con.prepareStatement("insert into items (`name`, `price`, `introduction`, `seller`, `thumbnail`,`author`,`numbersInCache`)"
                        + " values (?,?,?,?,?,?,?)");
                ps.setString(1, name);
                ps.setDouble(2, price);
                ps.setString(3, intro);
                ps.setString(4, seller);
                ps.setBinaryStream(5, fis, (int) file.length());
                ps.setString(6, author);
                ps.setInt(7, numbersInCache);
                ps.executeUpdate();
            } else {
                PreparedStatement ps = con.prepareStatement("insert into items (`name`, `price`, `introduction`, `seller`,`author`,`numbersInCache`)"
                        + " values (?,?,?,?,?,?)");
                ps.setString(1, name);
                ps.setDouble(2, price);
                ps.setString(3, intro);
                ps.setString(4, seller);
                ps.setString(5, author);
                ps.setInt(6, numbersInCache);
                ps.executeUpdate();
            }

        } catch (SQLException e) {
            return "failure";
        }
        return "success";
    }

    public static String editItems(int row, String column, Object value) throws SQLException, FileNotFoundException, IOException {

        Connection con = getConn();//此处为通过自己写的方法getConn()获得连接 

        if (column.equals("thumbnail")) {
            File file = new File((String) value);
            FileInputStream fis = new FileInputStream(file);

//            ByteBuffer nbf = ByteBuffer.allocate((int) file.length());
//            byte[] array = new byte[1024];  
//            int offset = 0, length = 0;
//            while ((length = fis.read(array)) > 0) {
//                if (length != 1024)
//                    nbf.put(array, 0, length);
//                else
//                    nbf.put(array);
//                offset += length;
//            }
//            fis.close();
//            byte[] content = nbf.array();
//            Statement stmt = con.createStatement(
//                    ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    ResultSet.CONCUR_UPDATABLE);
//            
//            String sql = "select * from items";
//            ResultSet rs = stmt.executeQuery(sql);
//            
//            if (rs.next()) {
//                rs.updateBytes(6, content);
//                rs.updateRow();
//            }
            PreparedStatement ps = con.prepareStatement("update items set " + column + "=? where id=" + row);
            ps.setBinaryStream(1, fis, (int) file.length());
            ps.executeUpdate();

        } else {
            String sql = "update items set " + column + "='" + value + "' where id=" + row;

            try {
                Statement stmt = con.createStatement();
                stmt.executeUpdate(sql);

            } catch (SQLException e) {
                return "failure";
            }
        }

        return "success";
    }

    public static String deleteItem(int row) throws SQLException {
        String sql = "delete from  items where id =" + row;
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate(sql);

            sql = "update items set id=id-1 where id >" + row;
            stmt.executeUpdate(sql);

            sql = "select max(id) as id from items";
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int maxId = rs.getInt("id");
                sql = "alter table items AUTO_INCREMENT=" + (maxId + 1);
                stmt.executeUpdate(sql);
            }

            sql = "select * from  shoppingCarts";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {

                Connection con2 = getConn();
                stmt = con2.createStatement();
                String itemsIDAndNumStringFromDB = rs.getString("itemsIDNum");

                if (itemsIDAndNumStringFromDB.contains(",")) {

                    StringTokenizer st = new StringTokenizer(itemsIDAndNumStringFromDB, ",");
                    int tokensCount = st.countTokens();

                    String[] itemsIDAndNum = new String[tokensCount];
                    for (int i = 0; i < tokensCount; i++) {
                        itemsIDAndNum[i] = st.nextToken();
                    }

                    String[] itemsID = new String[tokensCount];
                    int[] itemsNum = new int[tokensCount];
                    for (int i = 0; i < tokensCount; i++) {
                        StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNum[i], "*");
                        itemsID[i] = itemsIDAndNumTokenizer.nextToken();
                        itemsNum[i] = Integer.parseInt(itemsIDAndNumTokenizer.nextToken());
                    }

                    String deletedItemsIDNumStr = "";
                    boolean isItemExists = false;
                    if (!itemsID[0].equals(String.valueOf(row))) {
                        deletedItemsIDNumStr += itemsID[0] + "*" + itemsNum[0];
                        for (int i = 1; i < tokensCount; i++) {
                            if (!itemsID[i].equals(String.valueOf(row))) {
                                deletedItemsIDNumStr += "," + itemsID[i] + "*" + itemsNum[i];
                            } else {
                                isItemExists = true;
                            }
                        }
                    } else {
                        isItemExists = true;
                        deletedItemsIDNumStr += itemsID[1] + "*" + itemsNum[1];
                        for (int i = 2; i < tokensCount; i++) {
                            if (!itemsID[i].equals(String.valueOf(row))) {
                                deletedItemsIDNumStr += "," + itemsID[i] + "*" + itemsNum[i];
                            }
                        }
                    }
                    if (isItemExists) {
                        int shoppingCartId = rs.getInt("id");
                        sql = "update shoppingCarts set itemsIDNum = '" + deletedItemsIDNumStr + "' where id =" + shoppingCartId + "";
                        stmt.executeUpdate(sql);
                    }

                } else {

                    StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNumStringFromDB, "*");
                    String itemsID = itemsIDAndNumTokenizer.nextToken();

                    if (itemsID.equals(String.valueOf(row))) {
                        int shoppingCartId = rs.getInt("id");
                        sql = "delete from shoppingCarts where id =" + shoppingCartId + "";
                        stmt.executeUpdate(sql);

                        sql = "update shoppingCarts set id=id-1 where id >" + shoppingCartId;
                        stmt.executeUpdate(sql);

                        sql = "select max(id) as id from shoppingCarts";

                        ResultSet rs2 = stmt.executeQuery(sql);

                        if (rs2.next()) {
                            int maxId = rs2.getInt("id");
                            sql = "alter table shoppingCarts AUTO_INCREMENT=" + (maxId + 1);
                            stmt.executeUpdate(sql);
                        }

                    }

                }

            }

        } catch (SQLException e) {
            con.close();
            return "failure";
        }
        con.close();
        return "success";
    }

    public static List<Map<String, Object>> getPeopleInfo(String refreshParam, String loginType) throws SQLException {

        String sql = "";

        if (refreshParam == null) {
            sql = "select * from user_profile ";
        } else {

            switch (loginType) {

                case "username":
                    sql = "select * from user_profile where username = '" + refreshParam + "'";
                    break;
                case "email":
                    sql = "select * from user_profile where email = '" + refreshParam + "'";
                    break;
                case "phone":
                    sql = "select * from user_profile where phone = '" + refreshParam + "'";
                    break;

            }
        }
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            boolean existsFlag = false;
            List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

            while (rs.next()) {
                existsFlag = true;
                Map<String, Object> aRowMap = new HashMap<String, Object>();
                if (rs.isFirst()) {
                    aRowMap.put("msg", "success");
                }
                aRowMap.put("username", rs.getString("username"));
                aRowMap.put("password", rs.getString("password"));
                aRowMap.put("email", rs.getString("email"));
                aRowMap.put("phone", rs.getString("phone"));
                aRowMap.put("status", rs.getString("status"));
                aRowMap.put("balance", rs.getDouble("balance"));
                aRowMap.put("thumbnail", rs.getBlob("thumbnail"));

                list.add(aRowMap);
            }
            if (existsFlag) {

                return list;
            }
        } catch (SQLException e) {
            con.close();
            List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("msg", "sqlFalse");
            list2.add(aRowMap);
            return list2;
        }
        return null;
    }

    public static String addPeople(String username, String password, String email, String phone, String status, double balance, String thumbnailPath) throws SQLException, FileNotFoundException {
        return signUp(username, password, email, phone, status, balance, thumbnailPath);
    }

    public static String editPeopleThumbnail(int row, byte[] value) {
        Connection con = getConn();

        try {
            PreparedStatement ps = con.prepareStatement("update user_profile set thumbnail =? where id=" + row + "");
            ps.setBytes(1, value);
            ps.executeUpdate();
        } catch (SQLException e) {
            return "failure";
        }
        return "success";

    }

    public static String editPeople(int row, String column, Object value) throws SQLException, FileNotFoundException {
        Connection con = getConn();
        if (column.equals("thumbnail")) {
            File file = new File((String) value);
            FileInputStream fis = new FileInputStream(file);

            PreparedStatement ps = con.prepareStatement("update user_profile set " + column + "=? where id=" + row + "");
            ps.setBinaryStream(1, fis, (int) file.length());
            ps.executeUpdate();

        } else if (column.equals("username")) {
            String sql = "select * from user_profile where id =" + row;
            try {
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
                if (rs.next()) {

                    String originalUsername = rs.getString("username");

                    sql = "select * from items where seller ='" + originalUsername + "'";
                    rs = stmt.executeQuery(sql);
                    while (rs.next()) {
                        rs.updateString("seller", (String) value);
                    }

                    sql = "select * from orders where buyer ='" + originalUsername + "'";
                    rs = stmt.executeQuery(sql);
                    while (rs.next()) {
                        rs.updateString("buyer", (String) value);
                    }

                    sql = "select * from orders where seller ='" + originalUsername + "'";
                    rs = stmt.executeQuery(sql);
                    while (rs.next()) {
                        rs.updateString("seller", (String) value);
                    }

                    sql = "update user_profile set username='" + value + "' where id=" + row + "";
                    stmt.executeUpdate(sql);
                }

            } catch (SQLException e) {
                return "failure";
            }

        } else {
            String sql = "update user_profile set " + column + "='" + value + "' where id=" + row + "";
            try {
                Statement stmt = con.createStatement();
                stmt.executeUpdate(sql);

            } catch (SQLException e) {
                return "failure";
            }
        }

        return "success";
    }

    public static String deletePeople(int row) throws SQLException {

        Connection con = getConn();

        String sql = "select username from user_profile where id = " + row;

        try {
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery(sql);
            ArrayList<Integer> itemIds = new ArrayList<Integer>();
            if (rs.next()) {
                String username = rs.getString("username");

                sql = "select id from items where seller = '" + username + "'";
                rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    itemIds.add(rs.getInt("id"));
                }

                sql = "delete from  items where seller ='" + username + "'";
                stmt.executeUpdate(sql);

                sql = "delete from  orders where buyer ='" + username + "'";
                stmt.executeUpdate(sql);

                sql = "delete from  orders where seller ='" + username + "'";
                stmt.executeUpdate(sql);

            }

            sql = "delete from  user_profile where id =" + row;
            stmt.executeUpdate(sql);

            sql = "delete from  shoppingCarts where userID =" + row;
            stmt.executeUpdate(sql);

            ArrayList<Integer> addressIds = new ArrayList<Integer>();
            sql = "select id from addresses where userID = " + row;
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                addressIds.add(rs.getInt("id"));
            }

            sql = "delete from  addresses where userID =" + row;
            stmt.executeUpdate(sql);

            sql = "update user_profile set id=id-1 where id >" + row;
            stmt.executeUpdate(sql);

            sql = "update shoppingCarts set id=id-1 where id >" + row;
            stmt.executeUpdate(sql);

            for (int i = itemIds.size() - 1; i >= 0; i--) {
                sql = "update items set id=id-1 where id >" + itemIds.get(i);
                stmt.executeUpdate(sql);
            }

            for (int i = addressIds.size() - 1; i >= 0; i--) {
                sql = "update addresses set id=id-1 where id >" + addressIds.get(i);
                stmt.executeUpdate(sql);
            }

            sql = "select max(id) as id from user_profile";
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int maxId = rs.getInt("id");
                sql = "alter table user_profile AUTO_INCREMENT=" + (maxId + 1);
                stmt.executeUpdate(sql);
            }

            sql = "select max(id) as id from shoppingCarts";
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int maxId = rs.getInt("id");
                sql = "alter table shoppingCarts AUTO_INCREMENT=" + (maxId + 1);
                stmt.executeUpdate(sql);
            }

            sql = "select max(id) as id from items";
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int maxId = rs.getInt("id");
                sql = "alter table items AUTO_INCREMENT=" + (maxId + 1);
                stmt.executeUpdate(sql);
            }

            sql = "select max(id) as id from addresses";
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int maxId = rs.getInt("id");
                sql = "alter table addresses AUTO_INCREMENT=" + (maxId + 1);
                stmt.executeUpdate(sql);
            }

        } catch (SQLException e) {
            return "failure";
        }
        return "success";
    }

    public static List<Map<String, Object>> getShoppingCartInfo(int userID) throws SQLException {

        String sql = "select * from  user_profile where id =" + userID + "";
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

            if (rs.next()) {
                sql = "select * from  shoppingCarts where userID =" + userID + "";
                rs = stmt.executeQuery(sql);

                String itemsIDAndNumStringFromDB = "";

                if (rs.next()) {
                    itemsIDAndNumStringFromDB = rs.getString("itemsIDNum");

                    if (itemsIDAndNumStringFromDB.contains(",")) {

                        StringTokenizer st = new StringTokenizer(itemsIDAndNumStringFromDB, ",");
                        int tokensCount = st.countTokens();

                        String[] itemsIDAndNum = new String[tokensCount];
                        for (int i = 0; i < tokensCount; i++) {
                            itemsIDAndNum[i] = st.nextToken();
                        }

                        String[] itemsID = new String[tokensCount];
                        int[] itemsNum = new int[tokensCount];
                        for (int i = 0; i < tokensCount; i++) {
                            StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNum[i], "*");
                            itemsID[i] = itemsIDAndNumTokenizer.nextToken();
                            itemsNum[i] = Integer.parseInt(itemsIDAndNumTokenizer.nextToken());
                        }

                        for (int i = 0; i < tokensCount; i++) {

                            Map<String, Object> anItemMap = new HashMap<String, Object>();
                            if (i == 0) {
                                anItemMap.put("generallyMsg", "generallySuccess");
                            }

                            sql = "select * from items where id = " + itemsID[i];
                            rs = stmt.executeQuery(sql);

                            if (rs.next()) {
                                anItemMap.put("locallyMsg", "locallyExists");
                                anItemMap.put("idInDB", rs.getInt("id"));
                                anItemMap.put("name", rs.getString("name"));
                                anItemMap.put("price", rs.getDouble("price"));
                                anItemMap.put("introduction", rs.getString("introduction"));
                                anItemMap.put("seller", rs.getString("seller"));
                                anItemMap.put("thumbnail", rs.getBlob("thumbnail"));
                                anItemMap.put("author", rs.getString("author"));
                                anItemMap.put("numbersInCache", rs.getInt("numbersInCache"));
                                anItemMap.put("itemNum", itemsNum[i]);
                            } else {
                                anItemMap.put("locallyMsg", "locallyNone");
                            }
                            list.add(anItemMap);
                        }
                        return list;
                    } else {
                        StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNumStringFromDB, "*");
                        String itemsID = itemsIDAndNumTokenizer.nextToken();
                        int itemsNum = Integer.parseInt(itemsIDAndNumTokenizer.nextToken());

                        Map<String, Object> anItemMap = new HashMap<String, Object>();

                        anItemMap.put("generallyMsg", "generallySuccess");

                        sql = "select * from items where id = " + itemsID;
                        rs = stmt.executeQuery(sql);

                        if (rs.next()) {
                            anItemMap.put("locallyMsg", "locallyExists");
                            anItemMap.put("idInDB", rs.getInt("id"));
                            anItemMap.put("name", rs.getString("name"));
                            anItemMap.put("price", rs.getDouble("price"));
                            anItemMap.put("introduction", rs.getString("introduction"));
                            anItemMap.put("seller", rs.getString("seller"));
                            anItemMap.put("thumbnail", rs.getBlob("thumbnail"));
                            anItemMap.put("author", rs.getString("author"));
                            anItemMap.put("numbersInCache", rs.getInt("numbersInCache"));
                            anItemMap.put("itemNum", itemsNum);
                        } else {
                            anItemMap.put("locallyMsg", "locallyNone");
                        }
                        list.add(anItemMap);

                        return list;
                    }

                } else {
                    Map<String, Object> anItemMap = new HashMap<String, Object>();
                    anItemMap.put("generallyMsg", "userNoItemsInShoppingCart");
                    list.add(anItemMap);
                    return list;
                }
            } else {
                Map<String, Object> anItemMap = new HashMap<String, Object>();

                anItemMap.put("generallyMsg", "noUser");
                list.add(anItemMap);
                return list;
            }

        } catch (SQLException e) {
            con.close();
            List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("generallyMsg", "sqlFalse");
            list2.add(aRowMap);
            return list2;
        }

    }

    public static Map<String, Object> putInShoppingCart(int userID, int itemId) throws SQLException {
        String sql = "select * from  shoppingCarts where userID ='" + userID + "'";
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            String itemsIDAndNumStringFromDB = "";

            if (rs.next()) {
                itemsIDAndNumStringFromDB = rs.getString("itemsIDNum");

                if (itemsIDAndNumStringFromDB.contains(",")) {

                    StringTokenizer st = new StringTokenizer(itemsIDAndNumStringFromDB, ",");
                    int tokensCount = st.countTokens();

                    String[] itemsIDAndNum = new String[tokensCount];
                    for (int i = 0; i < tokensCount; i++) {
                        itemsIDAndNum[i] = st.nextToken();
                    }

                    int[] originalItemsID = new int[tokensCount];
                    int[] itemsNum = new int[tokensCount];

                    boolean hasExisted = false;
                    for (int i = 0; i < tokensCount; i++) {
                        StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNum[i], "*");
                        originalItemsID[i] = Integer.parseInt(itemsIDAndNumTokenizer.nextToken());
                        if (originalItemsID[i] == itemId) {
                            hasExisted = true;
                            itemsNum[i] = Integer.parseInt(itemsIDAndNumTokenizer.nextToken()) + 1;
                        } else {
                            itemsNum[i] = Integer.parseInt(itemsIDAndNumTokenizer.nextToken());
                        }
                    }

                    String addInShoppingCartStr = "";

                    if (hasExisted) {
                        addInShoppingCartStr += "" + originalItemsID[0] + "*" + itemsNum[0];
                        for (int i = 1; i < tokensCount; i++) {
                            addInShoppingCartStr += "," + originalItemsID[i] + "*" + itemsNum[i];
                        }

                    } else {
                        addInShoppingCartStr += "" + itemId + "*1";
                        for (int i = 0; i < tokensCount; i++) {
                            addInShoppingCartStr += "," + originalItemsID[i] + "*" + itemsNum[i];
                        }
                    }

                    sql = "update shoppingCarts set itemsIDNum = '" + addInShoppingCartStr + "' where userID ='" + userID + "'";
                    stmt.executeUpdate(sql);
                    con.close();
                    Map<String, Object> aRowMap = new HashMap<String, Object>();
                    aRowMap.put("msg", "success");
                    return aRowMap;

                } else {

                    StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNumStringFromDB, "*");
                    int originalItemID = Integer.parseInt(itemsIDAndNumTokenizer.nextToken());
                    int originalItemNum = Integer.parseInt(itemsIDAndNumTokenizer.nextToken());
                    String addInShoppingCartStr = "";
                    if (originalItemID == itemId) {

                        addInShoppingCartStr += "" + originalItemID + "*" + (originalItemNum + 1);
                        sql = "update shoppingCarts set itemsIDNum = '" + addInShoppingCartStr + "' where userID ='" + userID + "'";
                        stmt.executeUpdate(sql);
                        con.close();
                        Map<String, Object> aRowMap = new HashMap<String, Object>();
                        aRowMap.put("msg", "success");
                        return aRowMap;
                    } else {
                        addInShoppingCartStr += "" + itemId + "*1," + originalItemID + "*" + originalItemNum;
                        sql = "update shoppingCarts set itemsIDNum = '" + addInShoppingCartStr + "' where userID ='" + userID + "'";
                        stmt.executeUpdate(sql);
                        con.close();
                        Map<String, Object> aRowMap = new HashMap<String, Object>();
                        aRowMap.put("msg", "success");
                        return aRowMap;
                    }

                }

            } else {

                sql = "insert into shoppingCarts (`itemsIDNum`, `userID`)"
                        + "values ('" + itemId + "*1', '" + userID + "');";
                stmt.executeUpdate(sql);

                Map<String, Object> aRowMap = new HashMap<String, Object>();
                aRowMap.put("msg", "success");
                return aRowMap;
            }
        } catch (SQLException e) {
            con.close();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("msg", "sqlFalse");
            return aRowMap;
        }

    }

    public static String deleteShoppingCart(int userID) throws SQLException {

        String sql = "select * from  shoppingCarts where userID = " + userID;
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {

                int id = rs.getInt("id");

                sql = "delete from  shoppingCarts where userID = " + userID;
                stmt.executeUpdate(sql);

                sql = "update shoppingCarts set id=id-1 where id >" + id;
                stmt.executeUpdate(sql);

                sql = "select max(id) as id from shoppingCarts";
                rs = stmt.executeQuery(sql);

                if (rs.next()) {
                    int maxId = rs.getInt("id");
                    sql = "alter table shoppingCarts AUTO_INCREMENT=" + (maxId + 1);
                    stmt.executeUpdate(sql);
                }

            } else {
                return "noUser";
            }
        } catch (SQLException e) {
            con.close();

            return "failure";
        }
        return "success";
    }

    public static Map<String, Object> deleteItemInShoppingCart(int userID, String itemName, String itemSeller) throws SQLException {

        String sql = "select * from  items where name = '" + itemName + "' and seller = '" + itemSeller + "'";
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int deleteItemId = rs.getInt("id");

                sql = "select * from  shoppingCarts where userID ='" + userID + "'";
                rs = stmt.executeQuery(sql);

                String itemsIDAndNumStringFromDB = "";

                if (rs.next()) {
                    itemsIDAndNumStringFromDB = rs.getString("itemsIDNum");

                    if (itemsIDAndNumStringFromDB.contains(",")) {

                        StringTokenizer st = new StringTokenizer(itemsIDAndNumStringFromDB, ",");
                        int tokensCount = st.countTokens();

                        String[] itemsIDAndNum = new String[tokensCount];
                        for (int i = 0; i < tokensCount; i++) {
                            itemsIDAndNum[i] = st.nextToken();
                        }

                        String[] itemsID = new String[tokensCount];
                        int[] itemsNum = new int[tokensCount];
                        for (int i = 0; i < tokensCount; i++) {
                            StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNum[i], "*");
                            itemsID[i] = itemsIDAndNumTokenizer.nextToken();
                            itemsNum[i] = Integer.parseInt(itemsIDAndNumTokenizer.nextToken());
                        }

                        String deletedItemsIDNumStr = "";
                        boolean isItemExists = false;
                        if (!itemsID[0].equals(String.valueOf(deleteItemId))) {
                            deletedItemsIDNumStr += itemsID[0] + "*" + itemsNum[0];
                            for (int i = 1; i < tokensCount; i++) {
                                if (!itemsID[i].equals(String.valueOf(deleteItemId))) {
                                    deletedItemsIDNumStr += "," + itemsID[i] + "*" + itemsNum[i];
                                } else {
                                    isItemExists = true;
                                }
                            }
                        } else {
                            isItemExists = true;
                            deletedItemsIDNumStr += itemsID[1] + "*" + itemsNum[1];
                            for (int i = 2; i < tokensCount; i++) {
                                if (!itemsID[i].equals(String.valueOf(deleteItemId))) {
                                    deletedItemsIDNumStr += "," + itemsID[i] + "*" + itemsNum[i];
                                }
                            }
                        }
                        if (isItemExists) {
                            sql = "update shoppingCarts set itemsIDNum = '" + deletedItemsIDNumStr + "' where userID ='" + userID + "'";
                            stmt.executeUpdate(sql);
                            con.close();
                            Map<String, Object> aRowMap = new HashMap<String, Object>();
                            aRowMap.put("msg", "success");
                            return aRowMap;
                        }

                    } else {

                        StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNumStringFromDB, "*");
                        String itemsID = itemsIDAndNumTokenizer.nextToken();

                        if (itemsID.equals(String.valueOf(deleteItemId))) {

                            sql = "select * from shoppingCarts where userID ='" + userID + "'";
                            rs = stmt.executeQuery(sql);
                            if (rs.next()) {
                                int deleteShoppingCartId = rs.getInt("id");

                                sql = "delete from shoppingCarts where userID ='" + userID + "'";
                                stmt.executeUpdate(sql);

                                sql = "update shoppingCarts set id=id-1 where id >" + deleteShoppingCartId;
                                stmt.executeUpdate(sql);

                                sql = "select max(id) as id from shoppingCarts";
                                rs = stmt.executeQuery(sql);

                                if (rs.next()) {
                                    int maxId = rs.getInt("id");
                                    sql = "alter table shoppingCarts AUTO_INCREMENT=" + (maxId + 1);
                                    stmt.executeUpdate(sql);
                                    con.close();
                                    Map<String, Object> aRowMap = new HashMap<String, Object>();
                                    aRowMap.put("msg", "success");
                                    return aRowMap;
                                }

                            }

                        }

                    }

                } else {
                    con.close();
                    Map<String, Object> aRowMap = new HashMap<String, Object>();
                    aRowMap.put("msg", "userIDHasNoItems");
                    return aRowMap;
                }

            }
        } catch (SQLException e) {
            con.close();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("msg", "sqlFalse");
            return aRowMap;
        }
        con.close();
        Map<String, Object> aRowMap = new HashMap<String, Object>();
        aRowMap.put("msg", "itemNotExists");
        return aRowMap;

    }

    public static Map<String, Object> editItemNumInShoppingCart(int userID, String itemName, String itemSeller, int edittedNum) throws SQLException {

        String sql = "select * from  items where name = '" + itemName + "' and seller = '" + itemSeller + "'";
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {

                int editItemId = rs.getInt("id");

                sql = "select * from  shoppingCarts where userID ='" + userID + "'";
                rs = stmt.executeQuery(sql);

                String itemsIDAndNumStringFromDB = "";

                if (rs.next()) {
                    itemsIDAndNumStringFromDB = rs.getString("itemsIDNum");

                    if (itemsIDAndNumStringFromDB.contains(",")) {

                        StringTokenizer st = new StringTokenizer(itemsIDAndNumStringFromDB, ",");
                        int tokensCount = st.countTokens();

                        String[] itemsIDAndNum = new String[tokensCount];
                        for (int i = 0; i < tokensCount; i++) {
                            itemsIDAndNum[i] = st.nextToken();
                        }

                        String[] itemsID = new String[tokensCount];
                        int[] itemsNum = new int[tokensCount];
                        for (int i = 0; i < tokensCount; i++) {
                            StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNum[i], "*");
                            itemsID[i] = itemsIDAndNumTokenizer.nextToken();
                            itemsNum[i] = Integer.parseInt(itemsIDAndNumTokenizer.nextToken());
                        }

                        String edittedItemsIDNumStr = "";
                        boolean isItemExists = false;
                        if (!itemsID[0].equals(String.valueOf(editItemId))) {
                            edittedItemsIDNumStr += itemsID[0] + "*" + itemsNum[0];
                            for (int i = 1; i < tokensCount; i++) {
                                if (!itemsID[i].equals(String.valueOf(editItemId))) {
                                    edittedItemsIDNumStr += "," + itemsID[i] + "*" + itemsNum[i];
                                } else {
                                    edittedItemsIDNumStr += "," + itemsID[i] + "*" + edittedNum;
                                    isItemExists = true;
                                }
                            }
                        } else {
                            isItemExists = true;
                            edittedItemsIDNumStr += itemsID[0] + "*" + edittedNum;
                            for (int i = 1; i < tokensCount; i++) {

                                edittedItemsIDNumStr += "," + itemsID[i] + "*" + itemsNum[i];

                            }
                        }
                        if (isItemExists) {
                            sql = "update shoppingCarts set itemsIDNum = '" + edittedItemsIDNumStr + "' where userID ='" + userID + "'";
                            stmt.executeUpdate(sql);

                            con.close();
                            Map<String, Object> aRowMap = new HashMap<String, Object>();
                            aRowMap.put("msg", "success");
                            return aRowMap;
                        }

                    } else {

                        StringTokenizer itemsIDAndNumTokenizer = new StringTokenizer(itemsIDAndNumStringFromDB, "*");
                        String itemsID = itemsIDAndNumTokenizer.nextToken();

                        if (itemsID.equals(String.valueOf(editItemId))) {

                            String edittedItemsIDNumStr = itemsID + "*" + edittedNum;
                            sql = "update shoppingCarts set itemsIDNum = '" + edittedItemsIDNumStr + "' where userID ='" + userID + "'";
                            stmt.executeUpdate(sql);

                            con.close();
                            Map<String, Object> aRowMap = new HashMap<String, Object>();
                            aRowMap.put("msg", "success");
                            return aRowMap;
                        }

                    }

                } else {
                    con.close();
                    Map<String, Object> aRowMap = new HashMap<String, Object>();
                    aRowMap.put("msg", "userIDHasNoItems");
                    return aRowMap;
                }

            }
        } catch (SQLException e) {
            con.close();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("msg", "sqlFalse");
            return aRowMap;
        }
        con.close();
        Map<String, Object> aRowMap = new HashMap<String, Object>();
        aRowMap.put("msg", "itemNotExists");
        return aRowMap;

    }

    public static List<Map<String, Object>> getOrdersInfo(String params) throws SQLException {
        String sql = "";
        String sql2 = "";
        String status = "";
        String orderType = "";
        switch (params) {
            case "getAll":
                sql = "select * from orders ";
                break;
            default:
                JSONObject paramsJSON_getItems = JSONObject.fromObject(params);
                String action = paramsJSON_getItems.getString("action");
                status = paramsJSON_getItems.getString("status");
                String buyer = "";
                String seller = "";

                switch (status) {

                    case "buyer":
                        buyer = paramsJSON_getItems.getString("buyer");
                        break;
                    case "seller":
                        buyer = paramsJSON_getItems.getString("buyer");
                        seller = paramsJSON_getItems.getString("seller");
                        break;

                }
                switch (action) {
                    case "initialize":
                        sql = "select * from orders where buyer = '" + buyer + "'";
                        sql2 = "select * from orders where seller = '" + seller + "'";
                        break;
                    case "refresh":
                        sql = "select * from orders where buyer = '" + buyer + "'";
                        sql2 = "select * from orders where seller = '" + seller + "'";
                        break;
                }

                break;

        }
        Connection con = getConn();
        try {

            Statement stmt = con.createStatement();
            List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
            boolean existsFlag = false;

            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                existsFlag = true;
                Map<String, Object> aRowMap = new HashMap<String, Object>();
                if (rs.isFirst()) {
                    aRowMap.put("msg", "success");
                }
                aRowMap.put("orderType", "buyer");
                aRowMap.put("ordersID", rs.getString("ordersID"));
                aRowMap.put("address", rs.getString("address"));
                aRowMap.put("buyer", rs.getString("buyer"));
                aRowMap.put("seller", rs.getString("seller"));
                aRowMap.put("itemIDAndNum", rs.getString("itemIDAndNum"));
                aRowMap.put("sumPrice", rs.getDouble("sumPrice"));
                aRowMap.put("hasBeenReceived", rs.getString("hasBeenReceived"));
                aRowMap.put("hasSent", rs.getString("hasSent"));

                if (rs.getString("expressID") == null) {
                    aRowMap.put("expressID", "");
                } else {
                    aRowMap.put("expressID", rs.getString("expressID"));
                }

                list.add(aRowMap);
            }

            if (status.equals("seller")) {
                rs = stmt.executeQuery(sql2);

                while (rs.next()) {
                    Map<String, Object> aRowMap = new HashMap<String, Object>();
                    aRowMap.put("orderType", "seller");
                    aRowMap.put("ordersID", rs.getString("ordersID"));
                    aRowMap.put("address", rs.getString("address"));
                    aRowMap.put("buyer", rs.getString("buyer"));
                    aRowMap.put("seller", rs.getString("seller"));
                    aRowMap.put("itemIDAndNum", rs.getString("itemIDAndNum"));
                    aRowMap.put("sumPrice", rs.getDouble("sumPrice"));
                    aRowMap.put("hasBeenReceived", rs.getString("hasBeenReceived"));
                    aRowMap.put("hasSent", rs.getString("hasSent"));
                    if (rs.getString("expressID") == null) {
                        aRowMap.put("expressID", "");
                    } else {
                        aRowMap.put("expressID", rs.getString("expressID"));
                    }
                    list.add(aRowMap);
                }
            }

            if (existsFlag) {

                return list;
            }
        } catch (SQLException e) {
            con.close();
            List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("msg", "sqlFalse");
            list2.add(aRowMap);
            return list2;
        }
        return null;
    }

    public static String checkUser(String username) throws SQLException {
        String sql = "select * from  user_profile where username = '" + username + "'";
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                con.close();
                return "success";
            }
        } catch (SQLException e) {
            con.close();
            return "sqlFalse";
        }

        con.close();
        return "failure";
    }

    public static String addOrder(String ordersID, String address, String buyer, String seller,
            String itemIDAndNum, double sumPrice, String hasBeenReceived, String hasSent) throws SQLException {

        String sql = "select * from orders where ordersID = '" + ordersID + "'";
        Connection con = getConn();
        try {

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                return "ordersHasExisted";
            } else {

                PreparedStatement ps = con.prepareStatement("insert into orders (`ordersID`, `address`, `buyer`, `seller`, `itemIDAndNum`,`sumPrice`,`hasBeenReceived`,`hasSent`)"
                        + " values (?,?,?,?,?,?,?,?)");
                ps.setString(1, ordersID);
                ps.setString(2, address);
                ps.setString(3, buyer);
                ps.setString(4, seller);
                ps.setString(5, itemIDAndNum);
                ps.setDouble(6, sumPrice);
                ps.setString(7, hasBeenReceived);
                ps.setString(8, hasSent);
                ps.executeUpdate();
            }

        } catch (SQLException e) {
            return "failure";
        }
        return "success";

    }

    public static String deleteOrder(String ordersID) throws SQLException {

        Connection con = getConn();
        Statement stmt = con.createStatement();

        String sql = "delete from  orders where ordersID = '" + ordersID + "'";
        try {
            stmt.executeUpdate(sql);

        } catch (SQLException e) {
            return "failure";
        }

        return "success";
    }

    public static String editOrder(String ordersID, String column, Object value) throws SQLException {

        Connection con = getConn();
        Statement stmt = con.createStatement();

        String sql = "update orders set " + column + "='" + value + "' where ordersID ='" + ordersID + "'";

        try {
            stmt.executeUpdate(sql);

        } catch (SQLException e) {
            return "failure";
        }

        return "success";
    }

    public static List<Map<String, Object>> getDefaultAddressInfo(int userID) throws SQLException {
        Connection con = getConn();
        try {
            Statement stmt = con.createStatement();
            String sql = "select * from addresses where userID = " + userID + " and isDefault = 'Y'";

            ResultSet rs = stmt.executeQuery(sql);
            boolean existsFlag = false;
            List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

            while (rs.next()) {
                existsFlag = true;
                Map<String, Object> aRowMap = new HashMap<String, Object>();
                if (rs.isFirst()) {
                    aRowMap.put("msg", "success");
                }
                aRowMap.put("addressIDInDB", rs.getInt("id"));
                aRowMap.put("address_road", rs.getString("address_road"));
                aRowMap.put("address_receiver", rs.getString("address_receiver"));
                aRowMap.put("address_phone", rs.getString("address_phone"));
                aRowMap.put("address_passcode", rs.getString("address_passcode"));
                list.add(aRowMap);
            }
            if (existsFlag) {

                return list;
            }
        } catch (SQLException e) {
            con.close();
            List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("msg", "sqlFalse");
            list2.add(aRowMap);
            return list2;
        }
        return null;
    }

    public static List<Map<String, Object>> getAddressesInfo(int userID) throws SQLException {

        Connection con = getConn();
        try {

            Statement stmt = con.createStatement();
            String sql = "select * from addresses where userID = " + userID;

            ResultSet rs = stmt.executeQuery(sql);
            boolean existsFlag = false;
            List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

            while (rs.next()) {
                existsFlag = true;
                Map<String, Object> aRowMap = new HashMap<String, Object>();
                if (rs.isFirst()) {
                    aRowMap.put("msg", "success");
                }
                aRowMap.put("addressIDInDB", rs.getInt("id"));
                aRowMap.put("address_road", rs.getString("address_road"));
                aRowMap.put("address_receiver", rs.getString("address_receiver"));
                aRowMap.put("address_phone", rs.getString("address_phone"));
                aRowMap.put("address_passcode", rs.getString("address_passcode"));
                aRowMap.put("isDefault", rs.getString("isDefault"));
                list.add(aRowMap);
            }
            if (existsFlag) {

                return list;
            }
        } catch (SQLException e) {
            con.close();
            List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();
            Map<String, Object> aRowMap = new HashMap<String, Object>();
            aRowMap.put("msg", "sqlFalse");
            list2.add(aRowMap);
            return list2;
        }
        return null;
    }

    public static String addAddress(int userID, String receiver, String phone, String passcode, String address, String isDefault) throws SQLException {
        String sql = "select * from addresses where userID = " + userID;
        Connection con = getConn();
        try {

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String receiverInDB = rs.getString("address_receiver");
                String phoneInDB = rs.getString("address_phone");
                String passcodeInDB = rs.getString("address_passcode");
                String addressInDB = rs.getString("address_road");

                if (receiverInDB.equals(receiver) && phoneInDB.equals(phone)
                        && passcodeInDB.equals(passcode) && addressInDB.equals(address)) {
                    return "addressHasExisted";
                }
            }

            if (isDefault.equals("N")) {
                PreparedStatement ps = con.prepareStatement("insert into addresses (`address_receiver`, `address_phone`, `address_passcode`, `address_road`,`userID`,`isDefault`)"
                        + " values (?,?,?,?,?,?)");
                ps.setString(1, receiver);
                ps.setString(2, phone);
                ps.setString(3, passcode);
                ps.setString(4, address);
                ps.setInt(5, userID);
                ps.setString(6, isDefault);
                ps.executeUpdate();
            } else {

                sql = "select * from addresses where userID = " + userID + " and isDefault = 'Y'";
                rs = stmt.executeQuery(sql);

                if (rs.next()) {

                    int id = rs.getInt("id");

                    sql = "update addresses set isDefault = 'N' where id = " + id;
                    stmt.executeUpdate(sql);

                }

                PreparedStatement ps = con.prepareStatement("insert into addresses (`address_receiver`, `address_phone`, `address_passcode`, `address_road`,`userID`,`isDefault`)"
                        + " values (?,?,?,?,?,?)");
                ps.setString(1, receiver);
                ps.setString(2, phone);
                ps.setString(3, passcode);
                ps.setString(4, address);
                ps.setInt(5, userID);
                ps.setString(6, isDefault);
                ps.executeUpdate();

            }

        } catch (SQLException e) {
            return "failure";
        }
        return "success";

    }

    public static String deleteAddress(int idInDB) throws SQLException {
        Connection con = getConn();

        String sql = "select * from addresses where id = " + idInDB;

        try {
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery(sql);
            ArrayList<Integer> itemIds = new ArrayList<Integer>();
            if (rs.next()) {

                sql = "delete from  addresses where id =" + idInDB;
                stmt.executeUpdate(sql);

                sql = "update addresses set id=id-1 where id >" + idInDB;
                stmt.executeUpdate(sql);

                sql = "select max(id) as id from addresses";
                rs = stmt.executeQuery(sql);

                if (rs.next()) {
                    int maxId = rs.getInt("id");
                    sql = "alter table addresses AUTO_INCREMENT=" + (maxId + 1);
                    stmt.executeUpdate(sql);
                }

            } else {
                return "noAddress";
            }

        } catch (SQLException e) {
            return "failure";
        }
        return "success";
    }

    public static String editAddress(int idInDB, String column, String value) throws SQLException {
        Connection con = getConn();

        String sql = "select * from addresses where id = " + idInDB;

        try {
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {

                sql = "update addresses set " + column + "='" + value + "' where id=" + idInDB;
                stmt.executeUpdate(sql);

            } else {
                return "noAddress";
            }

        } catch (SQLException e) {
            return "failure";
        }
        return "success";
    }
}
