/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package PeopleManagement;

import DBAction.dbAction;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author xiangjun
 */
public class DeletePeople {
    private final PeopleManagement superView;
    
    public DeletePeople(PeopleManagement superView){
        this.superView=superView;
    }
    
    public void deletePeople(int rowNum){
        try {
            String result = dbAction.deletePeople(rowNum);
            if (result.equals("failure")) {
                JOptionPane.showMessageDialog(null, "SQL goes wrong,please check!", "alert", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "successful deletion", "alert", JOptionPane.ERROR_MESSAGE);
                superView.showPeopleList();
            }

        } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "SQL goes wrong,please check!", "alert", JOptionPane.ERROR_MESSAGE);
            }
    }
}
