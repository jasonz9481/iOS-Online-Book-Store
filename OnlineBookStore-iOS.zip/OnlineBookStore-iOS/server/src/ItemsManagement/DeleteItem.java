/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemsManagement;

import DBAction.dbAction;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author xiangjun
 */
public class DeleteItem {

    private final ItemsManagement superView;

    public DeleteItem(ItemsManagement superView) {
        this.superView = superView;
    }

    public void deleteItem(int rowNum) {
        try {
            String result = dbAction.deleteItem(rowNum);
            if (result.equals("failure")) {
                JOptionPane.showMessageDialog(null, "SQL goes wrong,please check!", "message", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "success", "message", JOptionPane.ERROR_MESSAGE);
                superView.showItemsList();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "SQL goes wrong,please check!", "message", JOptionPane.ERROR_MESSAGE);
        }
    }
}
