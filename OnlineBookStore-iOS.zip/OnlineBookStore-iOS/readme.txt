This is a handbook for the online bookstore project.

Database:
1.Before doing any other things, please install the mysql database or start it if you have installed it.
2.Then you can run the sql file in the directory I create for this project to build a database.

Server:
1.The server project is a netbeans project, so you need to install netbeans before you open it, or you can copy all of those java files and use another IDE to compile them. Note:you must copy all those jars in the 'lib' directory, since those are necessary libraries.
2.After running it, you can press the 'boot up' button to open this server and waiting for the message s from the clients.
3.You can also use those management functions to manage the corresponding thing.
4.Initially there is no items in the database, so you should use the server to add some items to it if you want to see more function in client-end.


Client:
1.Initially, there is no user account in the database, so you should first sign up.
2.After signing up, you can use the account to log in.
3.This is a project that need to be opened by XCode 7.2.