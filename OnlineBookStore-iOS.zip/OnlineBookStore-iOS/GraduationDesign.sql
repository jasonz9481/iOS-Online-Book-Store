SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema graduationdesign
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema GraduationDesign
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `GraduationDesign` ;
USE `GraduationDesign` ;

-- -----------------------------------------------------
-- Table `GraduationDesign`.`addresses`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GraduationDesign`.`addresses` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `address_road` VARCHAR(200) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `address_receiver` VARCHAR(45) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `address_phone` VARCHAR(11) NULL DEFAULT NULL,
  `address_passcode` VARCHAR(10) NULL DEFAULT NULL,
  `userID` INT(11) NULL DEFAULT NULL,
  `isDefault` VARCHAR(1) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC),
  UNIQUE INDEX `address_receiver_UNIQUE` (`address_receiver` ASC))
ENGINE = MyISAM
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `GraduationDesign`.`items`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GraduationDesign`.`items` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) CHARACTER SET 'utf8' NOT NULL,
  `price` DOUBLE NOT NULL,
  `introduction` VARCHAR(100) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `seller` VARCHAR(45) CHARACTER SET 'utf8' NOT NULL,
  `thumbnail` LONGBLOB NULL DEFAULT NULL,
  `author` VARCHAR(45) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `numbersInCache` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC),
  UNIQUE INDEX `name_UNIQUE` (`name` ASC))
ENGINE = MyISAM
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `GraduationDesign`.`orders`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GraduationDesign`.`orders` (
  `ordersID` VARCHAR(11) NOT NULL,
  `address` VARCHAR(500) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `buyer` VARCHAR(20) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `seller` VARCHAR(20) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `itemIDAndNum` VARCHAR(45) NULL DEFAULT NULL,
  `sumPrice` DOUBLE NULL DEFAULT NULL,
  `hasBeenReceived` VARCHAR(1) NULL DEFAULT NULL,
  `hasSent` VARCHAR(1) NULL DEFAULT NULL,
  `expressID` VARCHAR(20) NULL DEFAULT NULL,
  PRIMARY KEY (`ordersID`),
  UNIQUE INDEX `id_UNIQUE` (`ordersID` ASC))
ENGINE = MyISAM
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `GraduationDesign`.`shoppingCarts`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GraduationDesign`.`shoppingCarts` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `itemsIDNum` VARCHAR(45) NULL DEFAULT NULL,
  `userID` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC),
  UNIQUE INDEX `userID_UNIQUE` (`userID` ASC))
ENGINE = MyISAM
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `GraduationDesign`.`user_profile`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `GraduationDesign`.`user_profile` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) CHARACTER SET 'latin1' NOT NULL,
  `email` VARCHAR(45) CHARACTER SET 'latin1' NOT NULL,
  `phone` VARCHAR(45) CHARACTER SET 'latin1' NOT NULL,
  `status` VARCHAR(45) CHARACTER SET 'latin1' NOT NULL,
  `balance` DOUBLE NULL DEFAULT NULL,
  `thumbnail` LONGBLOB NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC),
  UNIQUE INDEX `username_UNIQUE` (`username` ASC))
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
