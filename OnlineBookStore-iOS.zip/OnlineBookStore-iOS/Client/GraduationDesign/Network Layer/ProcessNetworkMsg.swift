//
//  ProcessNetworkMsg.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/13.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import Foundation


class ProcessNetworkMsg {
    var relatedController:UIViewController?
    var msgToSend:JSON
    let request:String
    let params:JSON
    let msg:String
    var thumbnailArrayToSend = [UInt8]()
    var thumbnailArrayToSendHasBeenEditted = false
    let serverIP:String = "localhost"
    let serverPort:Int = 6666
    var socketClient:TCPClient?
    
    init(relatedController:UIViewController,request:String,params:JSON,msg:String){
        self.relatedController = relatedController
        self.request = request
        self.params = params
        self.msg = msg
        let msgToSendDic = ["request": request,"params":
            params.rawString()!,"msg": msg]
        msgToSend = JSON(msgToSendDic)
        socketClient = TCPClient(addr: serverIP, port: serverPort)
    }
    
    init(relatedController:UIViewController,request:String,params:JSON,msg:String,thumbnailArrayToSend:[UInt8]){
        self.relatedController = relatedController
        self.request = request
        self.params = params
        self.msg = msg
        self.thumbnailArrayToSend = thumbnailArrayToSend
        self.thumbnailArrayToSendHasBeenEditted = true
        let msgToSendDic = ["request": request,"params":
            params.rawString()!,"msg": msg]
        msgToSend = JSON(msgToSendDic)
        socketClient = TCPClient(addr: serverIP, port: serverPort)
        
    }
    
    func processSocket(){
        //new a thread
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), {
            //connect the server
            let (success,msg)=self.socketClient!.connect(timeout: 5)
            
            if success{
                self.sendMessage()
                
                if self.thumbnailArrayToSendHasBeenEditted{
                    
                    self.sendRawIntArray(self.thumbnailArrayToSend)
                }
                
                switch self.request{
                    
                    //--------------------------SIGN UP--------------------------------//
                case "signUp":
                    
                     let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        switch response{
                            
                        case "usernameHasExisted":
                            dispatch_async(dispatch_get_main_queue(), {
                                //the code run in main thread
                                showAlertDialog(self.relatedController!,title: "Alert",message: "Sorry,this username has been occupied,please change another one!",OKHandler: nil)
                            })
                            break
                        case "emailHasExisted":
                            dispatch_async(dispatch_get_main_queue(), {

                                showAlertDialog(self.relatedController!,title:"Alert",message: "Sorry,this username has been occupied,please change another one!",OKHandler: nil)
                            })
                            break
                            
                        case "phoneHasExisted":
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                showAlertDialog(self.relatedController!,title:"Alert",message: "Sorry,this username has been occupied,please change another one!",OKHandler: nil)
                            })
                            break
                            
                        default://"success"
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                
                                showAlertDialog(self.relatedController!,title:"Alert",message: "Congradulations!You can log in now!", OKHandler: { (action) -> Void in
                                    
                                    let returnToLoginStoryBoard = UIStoryboard(name: "Login", bundle: nil).instantiateViewControllerWithIdentifier("Login")
                                    
                                    self.relatedController!.presentViewController(returnToLoginStoryBoard, animated: true, completion: nil)
                                })
                                
                                
                            })
                            break
                        }
                        break
                        
                    
                    
                    //--------------------------SIGN UP--------------------------------//
                    
                    
                    //--------------------------LOG IN--------------------------------//
                    
                case "login":
                    
                    let msgFromServer = self.readMsg()

                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        switch response {
                            
                        case "userNotExisted" :
                            dispatch_async(dispatch_get_main_queue(), {

                                showAlertDialog(self.relatedController!,title:"Alert",message: "Sorry,this username doesn't exist, please log in after signing up",OKHandler: nil)
                            })
                            break
                            
                        case "passwordIncorrect" :
                            dispatch_async(dispatch_get_main_queue(), {

                                showAlertDialog(self.relatedController!,title:"Alert",message: "Sorry,the password is not correct!",OKHandler: nil)
                            })
                            break
                            
                        default ://success
                            
                            let userIdDic = msgFromServerJSON["params"] as! NSDictionary
                            
                            
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                showAlertDialog(self.relatedController!,title:"alert",message: "Congradulations!Log in successfully!", OKHandler: { (action) -> Void in
                                    
                                    let mainViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("mainView") as! MainViewController
                                    
                                    mainViewController.userID = userIdDic["userID"] as! Int
                                    mainViewController.username = userIdDic["username"] as! String
                                    mainViewController.loginType = userIdDic["loginType"] as! String
                                    mainViewController.status = userIdDic["status"] as! String
                                    mainViewController.balance = userIdDic["balance"] as! Double
                                    
                                    self.relatedController!.presentViewController(mainViewController, animated: true, completion: nil)
                                    
                                    
                                })
                            })
                            break
                        }
                        
                        break
                        
                    
                    //--------------------------LOG IN--------------------------------//
                    
                    //--------------------------GET ITEMS--------------------------------//
                    
                case "getItems":
                    
                    let (msgFromServerArray,msgFromServerUInt8Array) = self.readMsgs()
                    
                    if msgFromServerArray.count != 0{
                        
                        for var i = 0; i < msgFromServerArray.count; i++ {
                            
                            let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServerArray[i], options: NSJSONReadingOptions()) as! NSDictionary
                            
                            let response = msgFromServerJSON["response"] as! NSString
                            switch response{
                                
                            case "failure":
                                
                                let responseMsg = msgFromServerJSON["msg"] as! NSString
                                switch responseMsg{
                                case "sqlFalse":
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "it fails to run the sql,please check the code in server",OKHandler: nil)
                                    })
                                    break
                                    
                                default:
                                    
                                    break
                                }
                                
                                break
                                
                            default://成功
                                
                                if var itemDic = msgFromServerJSON["params"] {
                                    itemDic = itemDic as! NSDictionary
                                    
                                    let itemIdInDB:Int
                                    if let tempItemIdInDB = itemDic["idInDB"]{
                                        itemIdInDB = tempItemIdInDB as! Int
                                    }else{
                                        itemIdInDB = 0
                                    }
                                    
                                    
                                    let itemName:String
                                    if let tempItemName = itemDic["name"]{
                                        itemName = tempItemName as! String
                                    }else{
                                        itemName = ""
                                    }
                                    
                                    let tempItemPrice = itemDic["price"]
                                    let itemPrice:Double
                                    if tempItemPrice != nil{
                                        itemPrice = tempItemPrice as! Double
                                    }else{
                                        itemPrice = 0.00
                                    }
                                    
                                    let tempItemIntroduction = itemDic["introduction"]
                                    let itemIntroduction:String
                                    if tempItemIntroduction != nil{
                                        itemIntroduction = tempItemIntroduction as! String
                                    }else{
                                        itemIntroduction = ""
                                    }
                                    
                                    let tempItemSeller = itemDic["seller"]
                                    let itemSeller:String
                                    if tempItemSeller != nil{
                                        itemSeller = tempItemSeller as! String
                                    }else{
                                        itemSeller = ""
                                    }
                                    
                                    let tempItemAuthor = itemDic["author"]
                                    let itemAuthor:String
                                    if tempItemAuthor != nil{
                                        itemAuthor = tempItemAuthor as! String
                                    }else{
                                        itemAuthor = ""
                                    }
                                    
                                    let tempItemNumbersInCache = itemDic["numbersInCache"]
                                    let itemNumbersInCache:Int
                                    if tempItemNumbersInCache != nil{
                                        itemNumbersInCache = tempItemNumbersInCache as! Int
                                    }else{
                                        itemNumbersInCache = 0
                                    }
                                    
                                    dispatch_async(dispatch_get_main_queue(), {
                                        
                                        var tempThumbnailImage = UIImage(named:"noImage.jpg")
                                        
                                        let imageData = UIImagePNGRepresentation(tempThumbnailImage!)
                                        let count = imageData!.length / sizeof(UInt8)
                                        
                                        // create an array of Uint8
                                        var array = [UInt8](count: count, repeatedValue: 0)
                                        
                                        // copy bytes into array
                                        imageData!.getBytes(&array, length: count)
                                        
                                        let realEachItem: Item = Item(itemIdInDB:itemIdInDB,itemName: itemName, itemSeller: itemSeller, itemEachPrice: itemPrice, itemIntroduction: itemIntroduction,thumbnailUInt8Array:array,itemAuthor:itemAuthor,itemNumbersInCache: itemNumbersInCache )

                                        let realRelatedController = self.relatedController as! ItemsTableViewController
                                        
                                        realRelatedController.items.append(realEachItem)
                                        
                                        realRelatedController.itemsTable.reloadData()
                                        
                                    })
                                    
                                }else{
                                    
                                }
                                
                                break
                                
                            }
                        }
                        
                    }else{
                        dispatch_async(dispatch_get_main_queue(), {
                            //需要主线程执行的代码
                            let realRelatedController = self.relatedController as! ItemsTableViewController
                            realRelatedController.footer.endRefreshingWithNoMoreData()
                        })
                    }
                    
                    break
                    //--------------------------GET ITEMS--------------------------------//
                    
                    //--------------------------GET SHOPPING CART------------------------//
                case "getShoppingCart":
                    
                    //由于有多个商品，所以存为数组
                    let (msgFromServerArray,msgFromServerUInt8Array) = self.readMsgs()
                    
                    if msgFromServerArray.count != 0 {
                        
                        for var i = 0; i < msgFromServerArray.count; i++ {

                            let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServerArray[i], options: NSJSONReadingOptions()) as! NSDictionary
                            
                            let response = msgFromServerJSON["response"] as! NSString
                            switch response{
                                
                            case "failure":
                                
                                let responseMsg = msgFromServerJSON["msg"] as! NSString
                                switch responseMsg{
                                case "noUser":
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "Your username has been deleted,please sign up again!",OKHandler: { (action) -> Void in
                                            
                                            let loginViewController = UIStoryboard(name: "Login", bundle: nil).instantiateViewControllerWithIdentifier("Login") as! LoginViewController
                                            
                                            
                                            self.relatedController!.presentViewController(loginViewController, animated: true, completion: nil)
                                            
                                            
                                        })
                                    })
                                    break
                                case "userNoItemsInShoppingCart":
                                    dispatch_async(dispatch_get_main_queue(), {

                                        if self.msg != "notShowNoneDialog"{
                                             showAlertDialog(self.relatedController!,title:"Alert",message: "There is no items in your cart!Please add some to it!",OKHandler: nil)
                                        }
                                        
                                        let realRelatedController = self.relatedController as! ShoppingCartTableViewController
                                        
                                        realRelatedController.itemsInShoppingCart = []
                                        
                                        realRelatedController.itemsNumberInShoppingCart = []
                                        
                                        realRelatedController.shoppingCartTable.reloadData()
                                        
                                    })
                                    break
                                case "sqlFalse":
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "it fails while running the sql,please check the code in the server",OKHandler: nil)
                                        
                                        let realRelatedController = self.relatedController as! ShoppingCartTableViewController
                                        
                                        realRelatedController.itemsInShoppingCart = []
                                        
                                        realRelatedController.itemsNumberInShoppingCart = []
                                        
                                        realRelatedController.shoppingCartTable.reloadData()
                                    })
                                    break
                                    
                                default://locallyNone
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"alert",message: "It throws an exception while analyzing the information of "+String(i)+"th item,please check the code in server",OKHandler: { (action) -> Void in
                                            
                                            let realRelatedController = self.relatedController as! ShoppingCartTableViewController
                                            
                                            realRelatedController.itemsInShoppingCart = []
                                            
                                            realRelatedController.itemsNumberInShoppingCart = []
                                            
                                            realRelatedController.shoppingCartTable.reloadData()
                                            
                                            
                                        })
                                    })
                                    return
                                }
                                
                                break
                            default://success
                                
                                if var itemDic = msgFromServerJSON["params"] {
                                    itemDic = itemDic as! NSDictionary
                                    
                                    let itemIdInDB:Int
                                    if let tempItemIdInDB = itemDic["idInDB"]{
                                        itemIdInDB = tempItemIdInDB as! Int
                                    }else{
                                        itemIdInDB = 0
                                    }
                                    
                                    let itemName:String
                                    if let tempItemName = itemDic["name"]{
                                        itemName = tempItemName as! String
                                    }else{
                                        itemName = ""
                                    }
                                    
                                    let tempItemPrice = itemDic["price"]
                                    let itemPrice:Double
                                    if tempItemPrice != nil{
                                        itemPrice = tempItemPrice as! Double
                                    }else{
                                        itemPrice = 0.00
                                    }
                                    
                                    let tempItemIntroduction = itemDic["introduction"]
                                    let itemIntroduction:String
                                    if tempItemIntroduction != nil{
                                        itemIntroduction = tempItemIntroduction as! String
                                    }else{
                                        itemIntroduction = ""
                                    }
                                    
                                    let tempItemSeller = itemDic["seller"]
                                    let itemSeller:String
                                    if tempItemSeller != nil{
                                        itemSeller = tempItemSeller as! String
                                    }else{
                                        itemSeller = ""
                                    }
                                    
                                    let tempItemNum = itemDic["itemNum"]
                                    let itemNum:Int
                                    if tempItemNum != nil{
                                        itemNum = tempItemNum as! Int
                                    }else{
                                        itemNum = 0
                                    }
                                    
                                    let tempItemAuthor = itemDic["author"]
                                    let itemAuthor:String
                                    if tempItemAuthor != nil{
                                        itemAuthor = tempItemAuthor as! String
                                    }else{
                                        itemAuthor = ""
                                    }
                                    
                                    let tempItemNumbersInCache = itemDic["numbersInCache"]
                                    let itemNumbersInCache:Int
                                    if tempItemNumbersInCache != nil{
                                        itemNumbersInCache = tempItemNumbersInCache as! Int
                                    }else{
                                        itemNumbersInCache = 0
                                    }
                                    
                                    dispatch_async(dispatch_get_main_queue(), {
                                        
                                        let tempThumbnailImage = UIImage(named:"noImage.jpg")
                                        
                                        let imageData = UIImagePNGRepresentation(tempThumbnailImage!)
                                        let count = imageData!.length / sizeof(UInt8)
                                        
                                        // create an array of Uint8
                                        var array = [UInt8](count: count, repeatedValue: 0)
                                        
                                        // copy bytes into array
                                        imageData!.getBytes(&array, length: count)
                                        
                                        
                                        
                                        let realEachItem: Item = Item(itemIdInDB:itemIdInDB,itemName: itemName, itemSeller: itemSeller, itemEachPrice: itemPrice, itemIntroduction: itemIntroduction,thumbnailUInt8Array:array,itemAuthor:itemAuthor,itemNumbersInCache: itemNumbersInCache )
                                        
                                        let realRelatedController = self.relatedController as! ShoppingCartTableViewController
                                        
                                        realRelatedController.itemsInShoppingCart.append(realEachItem)
                                        
                                        realRelatedController.itemsNumberInShoppingCart.append(itemNum)
                                        
                                        realRelatedController.shoppingCartTable.reloadData()
                                        
                                        realRelatedController.sumPrice += itemPrice * Double(itemNum)
                                        
                                        var sumPriceStr:String = "sum：$"
                                        sumPriceStr += String(realRelatedController.sumPrice)
                                        
                                        realRelatedController.sumPriceLabel.text = sumPriceStr
                                        
                                    })
                                    
                                }else{
                                    
                                }
                                
                                
                                break
                                
                                
                            }
                            
                        }
                        
                    }else{
                        dispatch_async(dispatch_get_main_queue(), {
                            
                            if self.msg != "notShowNoneDialog"{

                                showAlertDialog(self.relatedController!,title:"alert",message: "There is no item in your cart!Please add some to it!",OKHandler: nil)
                            }
                            
                            
                        })
                    }
                    
                    
                    break
                    //--------------------------GET SHOPPING CART------------------------//
                    
                    //--------------------------PUT IN SHOPPING CART--------------------//
                case "putInShoppingCart":
                    
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "it fails while runnign the sql,please check the code in server!",OKHandler: nil)
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {

                                showAlertDialog(self.relatedController!,title:"Alert",message: "Adding to the cart successfully",OKHandler: { (action) -> Void in
                                    
                                    if shoppingCartTableViewControllerHasBeenInitialized{
                                        
                                        thisShoppingCartTableViewController.autoRefreshShoppingCart()
                                    }
                                    
                                })
                            })
                            
                            break
                            
                            
                            
                        }
                        
                    
                    
                    break
                    
                    //--------------------------PUT IN SHOPPING CART--------------------//
                    
                    
                    //--------------------------DELETE ITEMS IN SHOPPING CART------------//
                    
                case "deleteItemInShoppingCart":
                    
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "userIDHasNoItems":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "There is no item in your cart,please put some in it!",OKHandler: { (action) -> Void in
                                        
                                        let realRelatedController = self.relatedController as! ShoppingCartTableViewController
                                        
                                        realRelatedController.autoRefreshShoppingCart()
                                        
                                    })
                                })
                                
                                break
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in server",OKHandler: nil)
                                })
                                break
                                
                            case "itemNotExists":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "This item does't exist!",OKHandler: { (action) -> Void in
                                        
                                        let realRelatedController = self.relatedController as! ShoppingCartTableViewController

                                        realRelatedController.autoRefreshShoppingCart()
                                        
                                    })
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {

                                showAlertDialog(self.relatedController!,title:"Alert",message: "Deleting successfully",OKHandler: { (action) -> Void in
                                    
                                    let realRelatedController = self.relatedController as! ShoppingCartTableViewController
                                    
                                    realRelatedController.autoRefreshShoppingCart()
                                    
                                })
                            })
                            
                            break
                        }
                        
                    
                    
                    //--------------------------DELETE ITEMS IN SHOPPING CART------------//
                    
                    //--------------------------EDIT ITEMS NUM IN SHOPPING CART----------//
                case "editShoppingCartItemsNumber":
                    
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "userIDHasNoItems":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "There is no item in your cart,please put some in it!",OKHandler: { (action) -> Void in
                                        
                                        let realRelatedController = self.relatedController as! ShoppingCartTableViewController
                                        
                                        realRelatedController.autoRefreshShoppingCart()
                                        
                                    })
                                })
                                
                                break
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server",OKHandler: nil)
                                })
                                break
                                
                            case "itemNotExists":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "This item doesn't exist",OKHandler: { (action) -> Void in
                                        
                                        let realRelatedController = self.relatedController as! ShoppingCartTableViewController
                                        
                                        realRelatedController.autoRefreshShoppingCart()
                                        
                                    })
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                    
                                    let realRelatedController = self.relatedController as! ShoppingCartTableViewController
                                    
                                    realRelatedController.autoRefreshShoppingCart()
                                    
                                
                            })
                            
                            break
                        }
                    
                    
                    
                    break
                    //--------------------------EDIT ITEMS NUM IN SHOPPING CART----------//
                    
                    //--------------------------GET USER INFO-------------------------//
                    
                case "getUserInfo":
                    
                    let (msgFromServer,msgFromServerUInt8Array) = self.readUserProfile()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        switch response {
                            
                        case "userNotExisted" :
                            dispatch_async(dispatch_get_main_queue(), {

                                showAlertDialog(self.relatedController!,title:"Alert",message: "Your username has been deleted,please sign up again!",OKHandler: { (action) -> Void in
                                    
                                    let loginViewController = UIStoryboard(name: "Login", bundle: nil).instantiateViewControllerWithIdentifier("Login") as! LoginViewController
                                    
                                    
                                    self.relatedController!.presentViewController(loginViewController, animated: true, completion: nil)
                                    
                                    
                                })
                            })
                            break
                            
                        default ://success
                            
                            let userProfileDic = msgFromServerJSON["params"] as! NSDictionary
                            
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                    
                                    let meViewController = self.relatedController as! MeViewController
                                    
                                    meViewController.username = userProfileDic["username"] as! String
                                    meViewController.password = userProfileDic["password"] as! String
                                    meViewController.email = userProfileDic["email"] as! String
                                    meViewController.phone = userProfileDic["phone"] as! String
                                    meViewController.balance = userProfileDic["balance"] as! Double
                                    meViewController.thumbnailArray = msgFromServerUInt8Array
                                    
                                    meViewController.userInfoTable.reloadData()

                            })
                            break
                            
                        }
                        
                    
                    
                    
                    break
                    //--------------------------GET USER INFO-------------------------//
                    
                    
                    //--------------------------REFRESH USERINFO------------------------//
                case "refreshUserInfo":
                    
                    let (msgFromServer,msgFromServerUInt8Array) = self.readUserProfile()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,pleaase check the code in the server!",OKHandler: nil)
                                })
                                break
                                
                            case "none":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "Your username has been deleted,please sign up again",OKHandler: { (action) -> Void in
                                        
                                        let loginViewController = UIStoryboard(name: "Login", bundle: nil).instantiateViewControllerWithIdentifier("Login") as! LoginViewController
                                        
                                        
                                        self.relatedController!.presentViewController(loginViewController, animated: true, completion: nil)
                                        
                                        
                                    })
                                })
                                break
                                
                            default:
                                
                                break
                            }
                            
                            break
                            
                        default://success
                            
                            let params:NSDictionary = msgFromServerJSON["params"] as! NSDictionary
                            
                            let realRelatedController = self.relatedController as! MeViewController
                            
                            realRelatedController.username = params["username"] as! String
                            
                            realRelatedController.password = params["password"] as! String
                            
                            realRelatedController.phone = params["phone"] as! String
                            
                            realRelatedController.email = params["email"] as! String
                            
                            realRelatedController.status = params["status"] as! String
                            
                            realRelatedController.balance = params["balance"] as! Double
                            
                            realRelatedController.thumbnailArray = msgFromServerUInt8Array
                            
                            realRelatedController.userInfoTable.reloadData()
                            
                            
                            break
                            
                            
                        }
                        
                    
                    
                    break
                    
                    //--------------------------REFRESH USERINFO------------------------//
                    
                    //--------------------------EDIT USERINFO------------------------//
                case "editUserInfo":
                    
                   let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                })
                                break
                                
                            case "transferProblem":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "There is a problem while transmiting the thumbnail,Please check!",OKHandler: { (action) -> Void in
                                        
                                        let realRelatedController = self.relatedController as! MeDetailsTableViewController
                                        realRelatedController.thumbnailType = "UInt8Array"
                                        realRelatedController.meDetailsInfoTable.reloadData()
                                        realRelatedController.thumbnailHasBeenEditted = false
                                        
                                        if !realRelatedController.usernameHasBeenEditted && !realRelatedController.passwordHasBeenEditted && !realRelatedController.emailHasBeenEditted && !realRelatedController.phoneHasBeenEditted {
                                            
                                            realRelatedController.navigationItem.rightBarButtonItem?.enabled = false
                                        
                                        }
                                        
                                    })
                                    
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                        
                                let realRelatedController = self.relatedController as! MeDetailsTableViewController

                                let paramsDic = try! NSJSONSerialization.JSONObjectWithData( self.params.rawData(), options: NSJSONReadingOptions()) as! NSDictionary
                                
                                let key = paramsDic["key"] as! String
                                
                                let value = paramsDic["value"] as! String
                                
                                switch key{
                                    
                                case "thumbnail":
                                    
                                    realRelatedController.downLayerMeViewController.thumbnailArray = self.thumbnailArrayToSend
                                    
                                    break
                                    
                                case "username":
                                    
                                    realRelatedController.downLayerMeViewController.username = value
                                    
                                    break
                                    
                                case "password":

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "You has modified your passcode,pleas log in again!",OKHandler: { (action) -> Void in
                                        
                                        let loginViewController = UIStoryboard(name: "Login", bundle: nil).instantiateViewControllerWithIdentifier("Login") as! LoginViewController
                                        
                                        
                                        self.relatedController!.presentViewController(loginViewController, animated: true, completion: nil)
                                        
                                        
                                    })
                                   
                                    
                                    break
                                    
                                case "email":
                                    
                                    realRelatedController.downLayerMeViewController.email = value
                                    
                                    break
                                    
                                default ://phone
                                    
                                    realRelatedController.downLayerMeViewController.phone = value
                                    
                                    break
                                }
                                
                                realRelatedController.downLayerMeViewController.userInfoTable.reloadData()
                                
                                realRelatedController.navigationController?.popViewControllerAnimated(true)
                                
                            })
                            
                            break
                            
                            
                            
                        }
                        
                        
                    
                    break
                    //--------------------------EDIT USERINFO------------------------//
                    
                    //--------------------------TOP UP------------------------//
                case "topUp":
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while runnig the sql,please check the code in the server!",OKHandler: nil)
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                showAlertDialog(self.relatedController!,title:"Alert",message: "Toping up successfully!",OKHandler: { (action) -> Void in
                                    
                                    let realRelatedController = self.relatedController as! MeTopUpViewController
                                    
                                    var balanceAfterTopingUp = msgFromServerJSON["params"] as! String

                                    let balanceAfterTopingUpDouble = Double(balanceAfterTopingUp)
                                    balanceAfterTopingUp = NSString(format: "%.2f" , balanceAfterTopingUpDouble!) as String
                                    
                                    realRelatedController.balanceLabel.text = balanceAfterTopingUp
                                    
                                    realRelatedController.downLayerController.balance = balanceAfterTopingUpDouble!
                                    
                                    realRelatedController.downLayerController.userInfoTable.reloadData()

                                    let defaults = NSUserDefaults.standardUserDefaults()
                                    defaults.setObject(balanceAfterTopingUpDouble!, forKey: "balance")
                                    
                                })
                                
                            })
                           break
                            
                        }
                        
                        
                        
                    
                    
                    break
                    //--------------------------TOP UP------------------------//
                    
                    //--------------------------GET MY ITEMS------------------------//
                case "getMyItems":
                    
                    let (msgFromServerArray,msgFromServerUInt8Array) = self.readMsgs()
                    
                    if msgFromServerArray.count != 0{
                            
                            for var i = 0; i < msgFromServerArray.count; i++ {
                                
                            
                                let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData(msgFromServerArray[i], options: NSJSONReadingOptions()) as! NSDictionary
                                
                                let response = msgFromServerJSON["response"] as! NSString
                                switch response{
                                    
                                case "failure":
                                    
                                    let responseMsg = msgFromServerJSON["msg"] as! NSString
                                    switch responseMsg{
                                    case "sqlFalse":
                                        dispatch_async(dispatch_get_main_queue(), {
                                            
                                            showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                        })
                                        break
                                        
                                    default:
                                        
                                        break
                                    }
                                    
                                    break
                                    
                                default:
                                    
                                    if var itemDic = msgFromServerJSON["params"] {
                                        itemDic = itemDic as! NSDictionary
                                        
                                        let itemIdInDB:Int
                                        if let tempItemIdInDB = itemDic["idInDB"]{
                                            itemIdInDB = tempItemIdInDB as! Int
                                        }else{
                                            itemIdInDB = 0
                                        }
                                        
                                        
                                        let itemName:String
                                        if let tempItemName = itemDic["name"]{
                                            itemName = tempItemName as! String
                                        }else{
                                            itemName = ""
                                        }
                                        
                                        let tempItemPrice = itemDic["price"]
                                        let itemPrice:Double
                                        if tempItemPrice != nil{
                                            itemPrice = tempItemPrice as! Double
                                        }else{
                                            itemPrice = 0.00
                                        }
                                        
                                        let tempItemIntroduction = itemDic["introduction"]
                                        let itemIntroduction:String
                                        if tempItemIntroduction != nil{
                                            itemIntroduction = tempItemIntroduction as! String
                                        }else{
                                            itemIntroduction = ""
                                        }
                                        
                                        let tempItemSeller = itemDic["seller"]
                                        let itemSeller:String
                                        if tempItemSeller != nil{
                                            itemSeller = tempItemSeller as! String
                                        }else{
                                            itemSeller = ""
                                        }
                                        
                                        let tempItemAuthor = itemDic["author"]
                                        let itemAuthor:String
                                        if tempItemAuthor != nil{
                                            itemAuthor = tempItemAuthor as! String
                                        }else{
                                            itemAuthor = ""
                                        }
                                        
                                        let tempItemNumbersInCache = itemDic["numbersInCache"]
                                        let itemNumbersInCache:Int
                                        if tempItemNumbersInCache != nil{
                                            itemNumbersInCache = tempItemNumbersInCache as! Int
                                        }else{
                                            itemNumbersInCache = 0
                                        }
                                        
                                        dispatch_async(dispatch_get_main_queue(), {
                                            
                                            
                                            var tempThumbnailImage = UIImage(named:"noImage.jpg")
                                            
                                            let imageData = UIImagePNGRepresentation(tempThumbnailImage!)
                                            let count = imageData!.length / sizeof(UInt8)
                                            
                                            
                                            var array = [UInt8](count: count, repeatedValue: 0)
                                            
                                            
                                            imageData!.getBytes(&array, length: count)
                                            
                                            
                                            let realEachItem: Item = Item(itemIdInDB:itemIdInDB,itemName: itemName, itemSeller: itemSeller, itemEachPrice: itemPrice, itemIntroduction: itemIntroduction,thumbnailUInt8Array:array,itemAuthor:itemAuthor,itemNumbersInCache: itemNumbersInCache )
                                            
                                            let realRelatedController = self.relatedController as! MyItemsTableViewController
                                            
                                            realRelatedController.items.append(realEachItem)
                                            
                                            realRelatedController.myItemsTable.reloadData()
                                            
                                        })
                                        
                                    }else{
                                        
                                    }
                                    
                                    break
                                    
                                }
                            }
                            
                            
                        
                    }else{
                        dispatch_async(dispatch_get_main_queue(), {
                            
                            let realRelatedController = self.relatedController as! MyItemsTableViewController
                            realRelatedController.footer.endRefreshingWithNoMoreData()
                            realRelatedController.myItemsTable.reloadData()
                        })
                    }
                    
                    break
                    
                    //--------------------------GET MY ITEMS------------------------//
                    
                    //--------------------------ADD ITEMS-------------------------//
                case "addItems":
                    
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                })
                                break
                                
                            case "itemsNameHasExisted":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "The item's name has already existed,please change to another one!",OKHandler: nil)
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                
                                let realRelatedController = self.relatedController as! AddItemsTableViewController
                                realRelatedController.downLayerController.autoRefreshMyItemsTable()
                                
                                realRelatedController.navigationController?.popViewControllerAnimated(true)
                                
                                
                            })
                            break
                            
                        }
                        
                    
                    break
                    //--------------------------ADD ITEMS-------------------------//
   
                    //--------------------------DELETE ITEMS IN CACHE---------------//
                case "deleteItemInCache":
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                showAlertDialog(self.relatedController!,title:"Alert",message: "Delete successfully!",OKHandler: { (action) -> Void in
                                    
                                    let realRelatedController = self.relatedController as! MyItemsTableViewController
                                    
                                    realRelatedController.autoRefreshMyItemsTable()
                                    
                                    thisItemsTableViewController.autoRefreshItemsTable()
                                    
                                    if shoppingCartTableViewControllerHasBeenInitialized{
                                        thisShoppingCartTableViewController.autoRefreshShoppingCart()
                                    }
                                    
                                    
                                })
                                
                            })
                            break
                            
                        }
                        
                        
                        
                    
                    
                    break
                    //--------------------------DELETE ITEMS IN CACHE---------------//
                    
                    //--------------------------EDIT ITEMS IN CACHE---------------//
                case "editItemNumberInCache":
                    
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {
                                    
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                
                                let realRelatedController = self.relatedController as! MyItemsTableViewController
                                
                                realRelatedController.autoRefreshMyItemsTable()
                                
                                thisItemsTableViewController.autoRefreshItemsTable()

                                
                            })
                            break
                            
                        }

                    
                    break
                    //--------------------------EDIT ITEMS IN CACHE---------------//
                    
                    //--------------------------GET DEFAULT ADDRESS---------------//
                case "getDefaultAddress":
                    let msgFromServerArray = self.readMsgsWithNoThumbnail()
                    
                    if msgFromServerArray.count != 0{
                        
                        for msgFromServer in msgFromServerArray {
                            
                            let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                            
                            let response = msgFromServerJSON["response"] as! NSString
                            
                            switch response {
                                
                            case "failure":
                                
                                let msg = msgFromServerJSON["msg"] as! NSString
                                
                                switch msg{
                                    
                                case "sqlFalse":
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                    })
                                    break
                                    
                                default:
                                    
                                    break
                                    
                                }
                            default://success
                                if var addressDic = msgFromServerJSON["params"] {
                                    addressDic = addressDic as! NSDictionary
                                    
                                    let addressIdInDB:Int
                                    if let tempAddressIdInDB = addressDic["addressIDInDB"]{
                                        addressIdInDB = tempAddressIdInDB as! Int
                                    }else{
                                        addressIdInDB = 0
                                    }
                                    
                                    let addressRoad:String
                                    if let tempAddressRoad = addressDic["address_road"]{
                                        addressRoad = tempAddressRoad as! String
                                    }else{
                                        addressRoad = ""
                                    }
                                    
                                    
                                    let addressReceiver:String
                                    if let tempAddressReceiver = addressDic["address_receiver"]{
                                        addressReceiver = tempAddressReceiver as! String
                                    }else{
                                        addressReceiver = ""
                                    }
                                    
                                    let addressPhone:String
                                    if let tempAddressPhone = addressDic["address_phone"]{
                                        addressPhone = tempAddressPhone as! String
                                    }else{
                                        addressPhone = ""
                                    }
                                    
                                    let addressPasscode:String
                                    if let tempAddressPasscode = addressDic["address_passcode"]{
                                        addressPasscode = tempAddressPasscode as! String
                                    }else{
                                        addressPasscode = ""
                                    }
                                    
                                
                                    
                                    dispatch_async(dispatch_get_main_queue(), {
                                        
                                        let realEachAddress: OrderAddress = OrderAddress(idInDB:addressIdInDB,receiver:addressReceiver,phone:addressPhone,passcode:addressPasscode,road: addressRoad,isDefault:"Y")
                                        
                                        let realRelatedController = self.relatedController as! OrderTableViewController
                                        
                                        realRelatedController.orderAddress = realEachAddress
                                        
                                        realRelatedController.orderInfoTable.reloadData()
                                        
                                    })
                                    
                                }else{
                                    
                                }
                                break
                                
                            }
                            
                        }
                    }else{
                        dispatch_async(dispatch_get_main_queue(), {
                            
                            let realRelatedController = self.relatedController as! OrderTableViewController
                            realRelatedController.orderInfoTable.reloadData()
                        })

                    }
                    
                    break
                    //--------------------------GET DEFAULT ADDRESS---------------//
                    
                    //--------------------------GET ADDRESSES---------------------//
                    
                case "getAddresses":
                      let msgFromServerArray = self.readMsgsWithNoThumbnail()
                      
                      if msgFromServerArray.count != 0{
 
                        for msgFromServer in msgFromServerArray {
                            
                            let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                            
                            let response = msgFromServerJSON["response"] as! NSString
                            
                            switch response {
                                
                            case "failure":
                                
                                let msg = msgFromServerJSON["msg"] as! NSString
                                
                                switch msg{
                                    
                                case "sqlFalse":
                                    dispatch_async(dispatch_get_main_queue(), {
                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                    })
                                    break
                                    
                                default:
                                    
                                    break
                                    
                                }
                            default://success
                                if var addressDic = msgFromServerJSON["params"] {
                                    addressDic = addressDic as! NSDictionary
                                    
                                    let addressIdInDB:Int
                                    if let tempAddressIdInDB = addressDic["addressIDInDB"]{
                                        addressIdInDB = tempAddressIdInDB as! Int
                                    }else{
                                        addressIdInDB = 0
                                    }
                                    
                                    let addressRoad:String
                                    if let tempAddressRoad = addressDic["address_road"]{
                                        addressRoad = tempAddressRoad as! String
                                    }else{
                                        addressRoad = ""
                                    }
                                    
                                    
                                    let addressReceiver:String
                                    if let tempAddressReceiver = addressDic["address_receiver"]{
                                        addressReceiver = tempAddressReceiver as! String
                                    }else{
                                        addressReceiver = ""
                                    }
                                    
                                    let addressPhone:String
                                    if let tempAddressPhone = addressDic["address_phone"]{
                                        addressPhone = tempAddressPhone as! String
                                    }else{
                                        addressPhone = ""
                                    }
                                    
                                    let addressPasscode:String
                                    if let tempAddressPasscode = addressDic["address_passcode"]{
                                        addressPasscode = tempAddressPasscode as! String
                                    }else{
                                        addressPasscode = ""
                                    }
                                    
                                    let isDefault:String
                                    if let tempIsDefault = addressDic["isDefault"]{
                                        isDefault = tempIsDefault as! String
                                    }else{
                                        isDefault = ""
                                    }
                                    
                                    dispatch_async(dispatch_get_main_queue(), {

                                        let realEachAddress: OrderAddress = OrderAddress(idInDB:addressIdInDB,receiver:addressReceiver,phone:addressPhone,passcode:addressPasscode,road: addressRoad,isDefault:isDefault)
                                        
                                        let realRelatedController = self.relatedController as! OrderAddressesTableViewController
                                        
                                        realRelatedController.addresses.append(realEachAddress)
                                        
                                        realRelatedController.orderAddressesTable.reloadData()
                                        
                                    })
                                    
                                }else{
                                    
                                }
                                break
                                
                            }
                            
                        }
                      }else{
                        dispatch_async(dispatch_get_main_queue(), {
                            
                            let realRelatedController = self.relatedController as! OrderAddressesTableViewController
                            
                            realRelatedController.orderAddressesTable.reloadData()
                        })
                        
                      }

                    break
                    //--------------------------GET ADDRESSES---------------------//
                    
                    //--------------------------ADD ADDRESSES---------------------//
                 case "addAddress":
                    
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                })
                                break
                                
                            case "addressHasExisted":
                                dispatch_async(dispatch_get_main_queue(), {

                                    showAlertDialog(self.relatedController!,title:"Alert",message: "The address has already existed,please input again!",OKHandler: nil)
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                let realRelatedController = self.relatedController as! OrderAddressAddingViewController
                                
                                showAlertDialog(realRelatedController, title: "Alert", message: "Add successfully!", OKHandler: { (action) -> Void in
                                    
                                   
                                    realRelatedController.downLayerController.autoRefresh()
                                    
                                    realRelatedController.navigationController?.popViewControllerAnimated(true)
                                    
                                })
                                
                                
                                
                            })
                            break
                            
                        }
                        
                    

                    break
                    //--------------------------ADD ADDRESSES---------------------//
                    
                    //--------------------------DELETE ADDRESS--------------------//
                case "deleteAddress":
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                })
                                break
                                
                            case "noAddress":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "Sorry,this address doesn't exist!",OKHandler: nil)
                                    let realRelatedController = self.relatedController as! OrderAddressesTableViewController
                                    
                                    realRelatedController.autoRefresh()
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                let realRelatedController = self.relatedController as! OrderAddressesTableViewController
                                
                                showAlertDialog(realRelatedController, title: "Alert", message: "Delete successfully!", OKHandler: { (action) -> Void in
                                    
                                    
                                    realRelatedController.autoRefresh()
                                    realRelatedController.downLayerController.autoRefresh()
                                    
                                    
                                })
                                
                                
                                
                            })
                            break
                            
                        }
                        
                    
                    
                    
                    break
                    //--------------------------DELETE ADDRESS--------------------//
                    
                    //--------------------------EDIT ADDRESS----------------------//
                case "editAddress":
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server",OKHandler: nil)
                                })
                                break
                                
                            case "noAddress":
                                dispatch_async(dispatch_get_main_queue(), {
                                    showAlertDialog(self.relatedController!,title:"Alert",message: "Sorry,this address doesn't exist!",OKHandler: nil)
                                    let realRelatedController = self.relatedController as! OrderAddressesTableViewController
                                    
                                    realRelatedController.autoRefresh()
                                })
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                let realRelatedController = self.relatedController as! OrderAddressEditingViewController
                                
                                realRelatedController.downLayerController.autoRefresh()
                                
                                realRelatedController.downLayerController.downLayerController.autoRefresh()
                                
                                realRelatedController.navigationController?.popViewControllerAnimated(true)
                                
                            })
                            break
                            
                        }
                        
                    
                    break
                    //--------------------------EDIT ADDRESS----------------------//
                    
                    //--------------------------SUBMIT ORDER----------------------//
                case "submitOrder":
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let params = msgFromServerJSON["params"] as! NSString
                            
                            switch params {
                                
                            case "getBuyerName":
                                let msg = msgFromServerJSON["msg"] as! NSString
                                
                                switch msg{
                                    
                                case "sqlFalse":
                                    
                                    dispatch_async(dispatch_get_main_queue(), {
                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server!",OKHandler: nil)
                                    })
                                    break
                                    
                                case "notExistedFailure":
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "We can't find the name of the buyer!",OKHandler: nil)
                                    })
                                    break
                                    
                                default:
                                    
                                    break
                                    
                                }
                                break
                                
                            case "addOrder":
                                let msg = msgFromServerJSON["msg"] as! NSString
                                
                                switch msg{
                                    
                                case "sqlFalse":
                                    
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server",OKHandler: nil)
                                    })
                                    break
                                    
                                case "ordersHasExisted":
                                    
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It generates a same express number,please run it again!",OKHandler: nil)
                                    })
                                    break
                                    
                                default:
                                    
                                    break
                                    
                                }
                                break
                                
                            case "deleteShoppingCart":
                                let msg = msgFromServerJSON["msg"] as! NSString
                                
                                switch msg{
                                    
                                case "sqlFalse":
                                    
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server",OKHandler: nil)
                                    })
                                    break
                                    
                                case "noUser":
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "Sorry,the cart of your profile has been deleted!",OKHandler: nil)
                                        
                                    })
                                    break
                                    
                                default:
                                    
                                    break
                                    
                                }
                                break
                                
                            case "editBalance":
                                let msg = msgFromServerJSON["msg"] as! NSString
                                
                                switch msg{
                                    
                                case "sqlFalse":
                                    
                                    dispatch_async(dispatch_get_main_queue(), {
                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server",OKHandler: nil)
                                    })
                                    break
                                    
                                default:
                                    
                                    break
                                    
                                }
                                break
                                
                            case "editItemNumInCache":
                                let msg = msgFromServerJSON["msg"] as! NSString
                                
                                switch msg{
                                    
                                case "sqlFalse":
                                    
                                    dispatch_async(dispatch_get_main_queue(), {
                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server",OKHandler: nil)
                                    })
                                    break
                                    
                                default:
                                    
                                    break
                                    
                                }
                                break
                                
                            default:
                                
                                break
                                
                            }
                            

                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                let realRelatedController = self.relatedController as! OrderTableViewController
                                
                                showAlertDialog(realRelatedController, title: "Alert", message: "Check successfully!", OKHandler: { (action) -> Void in
                                    
                                    
                                    realRelatedController.downLayerController.autoRefreshShoppingCart()
                                    
                                    
                                    realRelatedController.navigationController?.popViewControllerAnimated(true)
                                    
                                    if meControllerHasBeenInitialized {
                                        relatedMeController.refreshUserInfo()
                                    }
                                    
                                    thisItemsTableViewController.autoRefreshItemsTable()
                                    
                                })

                                
                            })
                            break
                            
                        }
                        
                    
                    break
                    //--------------------------SUBMIT ORDER----------------------//
                    
                    //--------------------------GET ORDERS----------------------//
                case "getOrders":
                    
                    let msgFromServerArray = self.readMsgsWithNoThumbnail()
                    
                    if msgFromServerArray.count != 0{
                        
                        for msgFromServer in msgFromServerArray {
                            
                            let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                            
                            let response = msgFromServerJSON["response"] as! NSString
                            
                            switch response {
                                
                            case "failure":
                                
                                let msg = msgFromServerJSON["msg"] as! NSString
                                
                                switch msg{
                                    
                                case "sqlFalse":
                                    dispatch_async(dispatch_get_main_queue(), {
                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code in the server",OKHandler: nil)
                                    })
                                    break
                                    
                                default:
                                    
                                    break
                                    
                                }
                            default://success
                                if var orderDic = msgFromServerJSON["params"] {
                                    orderDic = orderDic as! NSDictionary
                                    
                                    let ordersID:String
                                    if let tempOrdersID = orderDic["ordersID"]{
                                        ordersID = tempOrdersID as! String
                                    }else{
                                        ordersID = ""
                                    }
                                    
                                    let address:String
                                    if let tempAddress = orderDic["address"]{
                                        address = tempAddress as! String
                                    }else{
                                        address = ""
                                    }
                                    
                                    
                                    let itemsInfo:String
                                    if let tempItemsInfo = orderDic["itemsInfo"]{
                                        itemsInfo = tempItemsInfo as! String
                                    }else{
                                        itemsInfo = ""
                                    }
                                    
                                    let sumPrice:Double
                                    if let tempSumPrice = orderDic["sumPrice"]{
                                        sumPrice = tempSumPrice as! Double
                                    }else{
                                        sumPrice = 0.0
                                    }
                                    
                                    let hasBeenReceived:String
                                    if let tempHasBeenReceived = orderDic["hasBeenReceived"]{
                                        hasBeenReceived = tempHasBeenReceived as! String
                                    }else{
                                        hasBeenReceived = ""
                                    }
                                    
                                    let hasSent:String
                                    if let tempHasSent = orderDic["hasSent"]{
                                        hasSent = tempHasSent as! String
                                    }else{
                                        hasSent = ""
                                    }
                                    
                                    
                                    let expressID = orderDic["expressID"] as! String

                                    
                                    
                                    let orderType:String
                                    if let tempOrderType = msgFromServerJSON["msg"]{
                                        orderType = tempOrderType as! String
                                    }else{
                                        orderType = ""
                                    }
                                    
                                    if orderType == "buyer" {
                                        
                                        let seller:String
                                        if let tempSeller = orderDic["seller"]{
                                            seller = tempSeller as! String
                                        }else{
                                            seller = ""
                                        }
                                        
                                        dispatch_async(dispatch_get_main_queue(), {
                                            
                                            var itemInfoToView:String = ""
                                            
                                            if itemsInfo.containsString("@"){
                                                let itemsInfoArrGeneral = itemsInfo.characters.split {$0 == "@"}
                                                
                                                let itemsInfoArr = String(itemsInfoArrGeneral[0]).characters.split {$0 == ","}
                                                
                                                itemInfoToView += "itemname：" + String(itemsInfoArr[0]) + "\n"
                                                itemInfoToView += "price：" + String(itemsInfoArr[1]) + "dollars\n"
                                                itemInfoToView += "number：" + String(itemsInfoArr[2])
                                                
                                                for var i = 1 ; i < itemsInfoArrGeneral.count ; i++ {
                                                    
                                                    itemInfoToView += "\n\n"
                                                    
                                                    let itemsInfoArr = String(itemsInfoArrGeneral[i]).characters.split {$0 == ","}
                                                    
                                                    itemInfoToView += "itemname：" + String(itemsInfoArr[0]) + "\n"
                                                    itemInfoToView += "price：" + String(itemsInfoArr[1]) + "dollars\n"
                                                    itemInfoToView += "number：" + String(itemsInfoArr[2]) + "\n"
                                                    itemInfoToView += "seller：" + seller
                                                    
                                                }
                                                
                                                
                                                
                                            }else {
                                                let itemsInfoArr = itemsInfo.characters.split {$0 == ","}
                                                
                                                itemInfoToView += "itemname：" + String(itemsInfoArr[0]) + "\n"
                                                itemInfoToView += "price：" + String(itemsInfoArr[1]) + "dollars\n"
                                                itemInfoToView += "number：" + String(itemsInfoArr[2]) + "\n"
                                                itemInfoToView += "seller：" + seller
                                                
                                            }
                                            
                                            let realEachOrder:Order = Order(id:ordersID,address:address,itemsInfo:itemInfoToView,sumPrice:sumPrice,buyerOrSeller:seller,orderType: "buyer" ,hasBeenReceived:hasBeenReceived,hasSent:hasSent,expressID: expressID)
                                            
                                            let realRelatedController = self.relatedController as! MyOrdersTableViewController
                                            
                                            realRelatedController.buyerOrders.append(realEachOrder)
                                            realRelatedController.myOrdersTable.reloadData()
                                            
                                        })
                                        
                                        
                                    }else if orderType == "seller" {
                                        
                                        
                                        let buyer:String
                                        if let tempBuyer = orderDic["buyer"]{
                                            buyer = tempBuyer as! String
                                        }else{
                                            buyer = ""
                                        }
                                        
                                        dispatch_async(dispatch_get_main_queue(), {
                                            
                                            var itemInfoToView:String = ""
                                            //需要主线程执行的代码
                                            if itemsInfo.containsString("@"){
                                                let itemsInfoArrGeneral = itemsInfo.characters.split {$0 == "@"}
                                                
                                                let itemsInfoArr = String(itemsInfoArrGeneral[0]).characters.split {$0 == ","}
                                                
                                                itemInfoToView += "itemname：" + String(itemsInfoArr[0]) + "\n"
                                                itemInfoToView += "price：" + String(itemsInfoArr[1]) + "dollars\n"
                                                itemInfoToView += "number：" + String(itemsInfoArr[2])
                                                
                                                for var i = 1 ; i < itemsInfoArrGeneral.count ; i++ {
                                                    
                                                    itemInfoToView += "\n\n"
                                                    
                                                    let itemsInfoArr = String(itemsInfoArrGeneral[i]).characters.split {$0 == ","}
                                                    
                                                    itemInfoToView += "itemname：" + String(itemsInfoArr[0]) + "\n"
                                                    itemInfoToView += "price：" + String(itemsInfoArr[1]) + "dollars\n"
                                                    itemInfoToView += "number：" + String(itemsInfoArr[2]) + "\n"
                                                    itemInfoToView += "seller：" + buyer
                                                    
                                                }
                                                
                                                
                                                
                                            }else {
                                                let itemsInfoArr = itemsInfo.characters.split {$0 == ","}
                                                
                                                itemInfoToView += "itemname：" + String(itemsInfoArr[0]) + "\n"
                                                itemInfoToView += "price：" + String(itemsInfoArr[1]) + "dollars\n"
                                                itemInfoToView += "number：" + String(itemsInfoArr[2]) + "\n"
                                                itemInfoToView += "seller：" + buyer
                                                
                                            }
                                            
                                            let realEachOrder:Order = Order(id:ordersID,address:address,itemsInfo:itemInfoToView,sumPrice:sumPrice,buyerOrSeller:buyer,orderType: "seller" ,hasBeenReceived:hasBeenReceived,hasSent:hasSent,expressID: expressID)
                                            
                                            let realRelatedController = self.relatedController as! MyOrdersTableViewController
                                            
                                            realRelatedController.sellerOrders.append(realEachOrder)
                                            realRelatedController.myOrdersTable.reloadData()
                                            
                                        })
                                        
                                        
                                        
                                    }
                                    
                                    
                                    
                                    
                                }else{
                                    
                                }
                                break
                                
                            }
                            
                        }
                    }else{
                        dispatch_async(dispatch_get_main_queue(), {
                            
                            let realRelatedController = self.relatedController as! MyOrdersTableViewController
                            
                            realRelatedController.myOrdersTable.reloadData()
                        })
                        
                    }
                    
                    break
                    //--------------------------GET ORDERS----------------------//
                    
                    //--------------------------HAS SENT ITEMS----------------------//
                case "hasSentItems":
                    
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                
                                let params = msgFromServerJSON["params"] as! NSString
                                
                                switch params {
                                    
                                case "editStatus":
                                    dispatch_async(dispatch_get_main_queue(), {

                                        showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code of the server",OKHandler: nil)
                                    })
                                    break
                                    
                                case "editExressID":
                                    dispatch_async(dispatch_get_main_queue(), {

                                         showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code of the server",OKHandler: nil)
                                    })
                                    break
                                    
                                default:
                                    break
                                }
                                
                                
                                break
  
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                let realRelatedController = self.relatedController as! MyOrdersTableViewController
                                
                                realRelatedController.autoRefresh()
                                
                            })
                            break
                            
                        }
                        
                    
                    
                    break
                    //--------------------------HAS SENT ITEMS----------------------//
                    
                    //--------------------------HAS RECEIVED----------------------//
                 case "hasReceived":
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                
                                dispatch_async(dispatch_get_main_queue(), {
                                     showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code of the server",OKHandler: nil)
                                })
                                
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                let realRelatedController = self.relatedController as! MyOrdersTableViewController
                                
                                realRelatedController.autoRefresh()
                                
                            })
                            break
                            
                        }
                        
                    

                    break
                    //--------------------------HAS RECEIVED----------------------//
                    
                    //--------------------------DELETE ORDER----------------------//
                case "deleteOrder":
                    let msgFromServer=self.readMsg()
                        
                        let msgFromServerJSON = try! NSJSONSerialization.JSONObjectWithData( msgFromServer, options: NSJSONReadingOptions()) as! NSDictionary
                        
                        let response = msgFromServerJSON["response"] as! NSString
                        
                        switch response {
                            
                        case "failure":
                            
                            let msg = msgFromServerJSON["msg"] as! NSString
                            
                            switch msg{
                                
                            case "sqlFalse":
                                
                                dispatch_async(dispatch_get_main_queue(), {
                                     showAlertDialog(self.relatedController!,title:"Alert",message: "It fails while running the sql,please check the code of the server",OKHandler: nil)
                                })
                                
                                break
                                
                            default:
                                
                                break
                                
                            }
                        default://success
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                let realRelatedController = self.relatedController as! MyOrdersTableViewController
                                
                                realRelatedController.autoRefresh()
                                
                            })
                            break
                            
                        }
                        
                    
                    break
                    //--------------------------DELETE ORDER----------------------//
                    
                default:
                    break
                    
                    
                }
                
                
                
                
            }else {
                dispatch_async(dispatch_get_main_queue(), {
                     showAlertDialog(self.relatedController!,title:"Alert",message: "Connection fails!",OKHandler: nil)
                })
            }
            

            let (disconnectSuccess,disconnectMsg)=self.socketClient!.close()
            
            if disconnectSuccess{
                
            }else{
                dispatch_async(dispatch_get_main_queue(), {

                    showAlertDialog(self.relatedController!,title:"Alert",message: "Connection fails:"+disconnectMsg,OKHandler: nil)
                })
            }
            
        })
        
    }
    
    func sendMessage(){

        
        if let rawString = msgToSend.rawString(){
            
            var modifiedMsgToSend = rawString.deleteStr("\n")
            
            modifiedMsgToSend += "\n"
            
            self.socketClient!.send(str: modifiedMsgToSend)
        }
    }
    
    func sendThumbnailStr(thumbnailStrToSend:String){
        
        var modifiedMsgToSend = thumbnailStrToSend.deleteStr("\n")
        
        modifiedMsgToSend += "\n"
        
        self.socketClient!.send(str: modifiedMsgToSend)
    }
    
    
    func sendRawIntArray(UInt8Array:[UInt8]){
        
        self.socketClient!.send(data: UInt8Array)
        
    }
    
    func readMsg() -> NSData {
        var data = NSData()
        
        var dataFromServerOriginalArray = [UInt8]()
        while true{
            if let dataFromServer = self.socketClient!.read(1000){
                
                for item in dataFromServer{
                    dataFromServerOriginalArray.append(item)
                }
                
                
            }else{
                break
            }
            
        }
        data = NSData(bytes: dataFromServerOriginalArray, length: dataFromServerOriginalArray.count)
        return data
        
    }

    
    func readMsgsWithNoThumbnail() -> [NSData]{
        
        var everyDataFromServer = NSData()
        var everyDataArray = [UInt8]()
        var DataFromServerArray = [NSData]()
        
        while true{
            if let dataFromServer = self.socketClient!.read(100){
                
                for item in dataFromServer{
                    
                    let everyChar = Character( UnicodeScalar(item))
                    if everyChar != "\n"{
                        
                        everyDataArray.append(item)

                    }else{
                        
                        everyDataFromServer = NSData(bytes: everyDataArray, length: everyDataArray.count)
                        DataFromServerArray.append(everyDataFromServer)
                        everyDataArray = []
                    }
                    
                }
                
            }else{
                break
            }
            
        }
        
        return DataFromServerArray
        
    }
    
    func readMsgs()->([NSData],[[UInt8]]){
        
        var everyDataFromServer = NSData()
        var everyDataArray = [UInt8]()
        var DataFromServerArray = [NSData]()
        var DataFromServerUInt8Array = [UInt8]()
        
        var imageArray = [[UInt8]]()
        
        var imgBegin:Bool = false
        
        while true{
            if let dataFromServer = self.socketClient!.read(100){
                
                for item in dataFromServer{
                    if imgBegin{
                        let everyChar = Character( UnicodeScalar(item))
                        if everyChar == "\t"{
                           imageArray.append(DataFromServerUInt8Array)
                        }else{
                            DataFromServerUInt8Array.append(item)
                        }
                    }else{
                        let everyChar = Character( UnicodeScalar(item))
                        if everyChar != "\n"{
                            if everyChar == "\t"{
                                imgBegin = true
                            }else{
                                everyDataArray.append(item)
                            }
                            
                        }else{
                            everyDataFromServer = NSData(bytes: everyDataArray, length: everyDataArray.count)
                            DataFromServerArray.append(everyDataFromServer)
                            everyDataArray = []
                        }
                    }
                }
                
            }else{
                break
            }
            
        }
        
        
        if DataFromServerArray.count == 0 && imageArray.count == 0{
            return ([],[[]])
        }else{
            return (DataFromServerArray,imageArray)
        }


    }
    
    func readUserProfile()->(NSData,[UInt8]) {
        var dataFromServer = NSData()
        var dataArray = [UInt8]()
        var dataFromServerUInt8Array = [UInt8]()
        
        var imgBegin = false
        
        while true{
            if let dataFromServer = self.socketClient!.read(1000){
                
                for item in dataFromServer{
                    
                    if imgBegin{
                        dataFromServerUInt8Array.append(item)
                    }else{
                        let everyChar = Character( UnicodeScalar(item))
                        
                        if everyChar == "\t"{
                            imgBegin = true
                        }else{
                            dataArray.append(item)
                        }
                    }
                    
                    
                }
                
            }else{
                break
            }
        }
        dataFromServer = NSData(bytes: dataArray, length: dataArray.count)
        return (dataFromServer,dataFromServerUInt8Array)
    }
    
 
    
}

