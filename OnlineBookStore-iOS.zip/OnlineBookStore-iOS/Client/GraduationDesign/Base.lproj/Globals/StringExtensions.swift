//
//  StringExtensions.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/27.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import Foundation


extension String{
    
    func deleteStr(rawString:Character)->String{
        var modifiedMsgToSend = ""
        for item in self.characters{
            if item != rawString{
                modifiedMsgToSend.append(item)
            }
        }
        return modifiedMsgToSend
    }
}