//
//  Functions.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/3.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import Foundation



func showAlertDialog(relatedController:UIViewController,title:String, message:String,OKHandler:((UIAlertAction) -> Void)?){
    let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.Alert)
    let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: OKHandler)
    alertController.addAction(OKAction)
    relatedController.presentViewController(alertController, animated: true, completion: nil)
}

func showAlertDialog(relatedController:UIViewController,title:String, message:String,OKHandler:((UIAlertAction) -> Void)?,cancelHandler:((UIAlertAction) -> Void)?){
    let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.Alert)
    let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: OKHandler)
    let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Default, handler: cancelHandler)
    alertController.addAction(cancelAction)
    alertController.addAction(OKAction)
    relatedController.presentViewController(alertController, animated: true, completion: nil)
}



func verifyInputInfo(username:String,password:String,email:String,phone:String)->String{
    if username == ""{
        return "usernameHasNotInput"
    }else if password == ""{
        return "passwordHasNotInput"
    }else if verifyEmail(email) == "hasNotInput"{
        return "emailHasNotInput"
    }else if verifyEmail(email) == "invalid"{
        return "invalidEmail"
    }else if verifyPhone(phone) == "hasNotInput"{
        return "phoneHasNotInput"
    }else{
        return "valid"
    }
}

func verifyEmail(email:String)->String{
    if email == ""{
        return "hasNotInput"
    }else if email.containsString("@")==false || (email.hasSuffix(".com")==false && email.hasSuffix(".net")==false){
        return "invalid"
    }else {
        return "valid"
    }
    
}

func verifyPhone(phone:String)->String{
    if phone == ""{
        return "hasNotInput"
    }else {
        return "valid"
    }
    
}
