//
//  Structs.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/31.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import Foundation

struct Item {
    var itemIdInDB:Int
    var itemName: String
    var itemSeller: String
    var itemEachPrice: Double
    var itemIntroduction: String
    var thumbnailUInt8Array: [UInt8]
    var itemAuthor:String
    var itemNumbersInCache:Int
}

struct UserProfile {
    var username:String
    var email:String
    var phone:String
    var thumbnailUInt8Array: [UInt8]
}

struct OrderAddress {
    var idInDB:Int
    var receiver:String
    var phone:String
    var passcode:String
    var road:String
    var isDefault:String
}

struct Order {
    var id:String
    var address:String
    var itemsInfo:String
    var sumPrice:Double
    var buyerOrSeller:String
    var orderType:String
    var hasBeenReceived:String
    var hasSent:String
    var expressID:String
}