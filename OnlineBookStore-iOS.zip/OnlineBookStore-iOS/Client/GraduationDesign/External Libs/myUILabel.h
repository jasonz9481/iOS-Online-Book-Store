//
//  myUILabel.h
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/10.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

#ifndef myUILabel_h
#define myUILabel_h

#import <UIKit/UIKit.h>
typedef enum
{
    VerticalAlignmentTop = 0, // default
    VerticalAlignmentMiddle,
    VerticalAlignmentBottom,
} VerticalAlignment;
@interface myUILabel : UILabel
{
@private
    VerticalAlignment _verticalAlignment;
}

@property (nonatomic) VerticalAlignment verticalAlignment;

@end


#endif /* myUILabel_h */
