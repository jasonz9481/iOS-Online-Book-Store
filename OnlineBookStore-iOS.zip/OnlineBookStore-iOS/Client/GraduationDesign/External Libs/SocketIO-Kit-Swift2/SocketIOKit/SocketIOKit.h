//
//  SocketIOKit.h
//  SocketIOKit
//
//  Created by Ricardo Pereira on 22/05/2015.
//  Copyright (c) 2015 Ricardo Pereira. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SocketIOKit.
FOUNDATION_EXPORT double SocketIOKitVersionNumber;

//! Project version string for SocketIOKit.
FOUNDATION_EXPORT const unsigned char SocketIOKitVersionString[];


