//
//  Tests.swift
//  Tests
//
//  Created by Ricardo Pereira on 22/05/2015.
//  Copyright (c) 2015 Ricardo Pereira. All rights reserved.
//

import Quick
import Nimble
import SocketIOKit

class SocketIOKitSpec: QuickSpec {
    override func spec() {
        it("is 1 + 1 = 2") {
            // TODO
            expect(1 + 1).to(equal(2))
        }
    }
}