//
//  LoginViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/7.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet var backgroundView: UIView!
    
    @IBOutlet weak var iconImg: UIImageView!
    
    @IBOutlet weak var usernameTF: UITextField!
    
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var loginBtn: UIButton!
    
    @IBAction func loginBtnAction(sender: AnyObject) {
        
        let username = usernameTF.text
        let password = passwordTF.text
        
        if username != nil || password != nil{
            if verifyInpuInfo(username!, password: password!) == "valid" {
                
                //check the username
                var params = NSDictionary()
                
                params = ["username": username!, "password": password!]
                
                let paramsJSON = JSON(params)
                
                let modifiedParamsJSON = JSON(paramsJSON.rawString()!.deleteStr("\n"))
                
                //send logging in request
                let processNetworkMsg = ProcessNetworkMsg(relatedController: self,request: "login",params: modifiedParamsJSON,msg: "")
                
                processNetworkMsg.processSocket()
                
                
            }else{
                if verifyInpuInfo(username!, password: password!) == "usernameHasNotInput"{
                    showAlertDialog(self, title: "Alert", message: "Please input a username!", OKHandler: nil)
                }else if verifyInpuInfo(username!, password: password!) == "passwordHasNotInput" {
                    showAlertDialog(self, title: "Alert", message: "Please input a password", OKHandler: nil)
                }
            }
        }else{
            showAlertDialog(self, title: "Alert", message: "There is a problem in the widget,please check!", OKHandler: nil)
        }
        
        
        
        
    }
    
    
    func verifyInpuInfo(username:String,password:String)->String{
        if username == ""{
            return "usernameHasNotInput"
        }else if password == ""{
            return "passwordHasNotInput"
        }else{
            return "valid"
        }
        
        
    }
    
    @IBOutlet weak var signUpBtn: UIButton!
    
    @IBAction func signUpBtnAction(sender: UIButton) {
        let signUpStoryBoard = UIStoryboard(name: "SignUp", bundle: nil).instantiateViewControllerWithIdentifier("SignUp")
        
        self.presentViewController(signUpStoryBoard, animated: true, completion: nil)
        
        
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        backgroundView.backgroundColor = UIColor(patternImage: UIImage(named:"background.jpg")!)
        usernameTF.clearButtonMode = UITextFieldViewMode.WhileEditing
        passwordTF.clearButtonMode = UITextFieldViewMode.WhileEditing
        passwordTF.secureTextEntry = true
        loginBtn.layer.cornerRadius = 8
        signUpBtn.layer.cornerRadius = 8
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
