//
//  MyOrdersTableViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/20.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class MyOrdersTableViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var myOrdersTable: UITableView!
    
    var buyerOrders:[Order] = []
    var sellerOrders:[Order] = []
    
    var username = String()
    
    var status = String()
    

    var header = MJRefreshNormalHeader()

    override func viewDidLoad() {
        super.viewDidLoad()
        

        header.setRefreshingTarget(self, refreshingAction: Selector("headerRefresh"))
        self.myOrdersTable.mj_header = header

        self.myOrdersTable.tableFooterView = UIView()
        
        switch status{
            
        case "buyer":
            let getOrdersParams = JSON(["action":"initialize","status":status,"buyer":username])
            
            ProcessNetworkMsg(relatedController: self, request: "getOrders", params: getOrdersParams, msg: "").processSocket()
            break
            
        case "seller":
            let getOrdersParams = JSON(["action":"initialize","status":status,"buyer":username,"seller":username])
            
            ProcessNetworkMsg(relatedController: self, request: "getOrders", params: getOrdersParams, msg: "").processSocket()
            break
            
        default:
            break
        }
        
    }
    
    
    func headerRefresh(){
        
        buyerOrders = []
        sellerOrders = []

        switch status{
            
        case "buyer":
            let getOrdersParams = JSON(["action":"refresh","status":status,"buyer":username])
            
            ProcessNetworkMsg(relatedController: self, request: "getOrders", params: getOrdersParams, msg: "").processSocket()
            break
            
        case "seller":
            let getOrdersParams = JSON(["action":"refresh","status":status,"buyer":username,"seller":username])
            
            ProcessNetworkMsg(relatedController: self, request: "getOrders", params: getOrdersParams, msg: "").processSocket()
            break
            
        default:
            break
        }

        self.myOrdersTable.mj_header.endRefreshing()
    }
    
    func autoRefresh(){
        buyerOrders = []
        sellerOrders = []
        
        switch status{
            
        case "buyer":
            let getOrdersParams = JSON(["action":"refresh","status":status,"buyer":username])
            
            ProcessNetworkMsg(relatedController: self, request: "getOrders", params: getOrdersParams, msg: "").processSocket()
            break
            
        case "seller":
            let getOrdersParams = JSON(["action":"refresh","status":status,"buyer":username,"seller":username])
            
            ProcessNetworkMsg(relatedController: self, request: "getOrders", params: getOrdersParams, msg: "").processSocket()
            break
            
        default:
            break
        }

        
    }
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch status {
            
        case "buyer":
            
            return buyerOrders.count + 1
            
        default://seller
            
            if buyerOrders.count == 0 {
                
                if sellerOrders.count == 0{
                    return 1
                }else{
                    return sellerOrders.count + 2
                }
                
            }else {
                if sellerOrders.count == 0 {
                    return buyerOrders.count + 2
                }else {
                    return buyerOrders.count + sellerOrders.count + 2
                }
            }
            

            
        }
        
        
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        switch status {
            
        case "buyer":
            
            if indexPath.row == 0{
                return 50
            }else{
                return 292
            }
            
        default://seller
            
            if buyerOrders.count == 0{
                
                if sellerOrders.count == 0{
                    return 50
                }else{
                    switch indexPath.row {
                        
                    case 0 :
                        return 50
                    case 1:
                        return 50
                    default:
                        return 292
                    }
                }
  
            }else{
                
                if sellerOrders.count == 0{
                    switch indexPath.row {
                        
                    case 0 :
                        return 50
                    case 1...buyerOrders.count:
                        return 292
                    default:
                        return 50
                    }
                    
                }else{
                    switch indexPath.row {
                        
                    case 0 :
                        return 50
                    case 1...buyerOrders.count:
                        return 292
                    case buyerOrders.count + 1:
                        return 50
                    default:
                        return 292
                    }
                }
                
                
            }
  
        }
        
        
        
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch status {
            
        case "buyer":
            
            switch indexPath.row {
                
            case 0:
                
                let titleCell = tableView.dequeueReusableCellWithIdentifier("titleCell", forIndexPath: indexPath) as! TitleCell
                titleCell.configureTitleInfo("my orders")
                
                return titleCell
                
            default:
                let myOrdersDetailsCell = tableView.dequeueReusableCellWithIdentifier("orderDetailsCell", forIndexPath: indexPath) as! MyOrdersDetailsCell
                myOrdersDetailsCell.configureOrdersDetails(self.buyerOrders[indexPath.row - 1],relatedController: self)
                
                return myOrdersDetailsCell
            }

            
        default://seller
            
            if buyerOrders.count == 0{
                
                if sellerOrders.count == 0 {
                    let titleCell = tableView.dequeueReusableCellWithIdentifier("titleCell", forIndexPath: indexPath) as! TitleCell
                    titleCell.configureTitleInfo("sorry,you haven't any orders now!")
                    
                    return titleCell
                }else{
                    switch indexPath.row {
                        
                    case 0:
                        
                        let titleCell = tableView.dequeueReusableCellWithIdentifier("titleCell", forIndexPath: indexPath) as! TitleCell
                        titleCell.configureTitleInfo("you have no placed orders")
                        
                        return titleCell
                        
                    case 1:
                        
                        let titleCell = tableView.dequeueReusableCellWithIdentifier("titleCell", forIndexPath: indexPath) as! TitleCell
                        titleCell.configureTitleInfo("orders to deliver")
                        
                        return titleCell
                    default :
                        
                        let sellerOrdersDetailsCell = tableView.dequeueReusableCellWithIdentifier("orderDetailsCell", forIndexPath: indexPath) as! MyOrdersDetailsCell
                        sellerOrdersDetailsCell.configureOrdersDetails(self.sellerOrders[indexPath.row - 2],relatedController: self)
                        
                        return sellerOrdersDetailsCell
                        
                    }
                    
                    
                    
                }
                
            }else{
                
                if sellerOrders.count == 0 {
                    switch indexPath.row {
                        
                    case 0:
                        
                        let titleCell = tableView.dequeueReusableCellWithIdentifier("titleCell", forIndexPath: indexPath) as! TitleCell
                        titleCell.configureTitleInfo("placed orders:")
                        
                        return titleCell
                        
                    case 1...buyerOrders.count:
                        let buyerOrdersDetailsCell = tableView.dequeueReusableCellWithIdentifier("orderDetailsCell", forIndexPath: indexPath) as! MyOrdersDetailsCell
                        buyerOrdersDetailsCell.configureOrdersDetails(self.buyerOrders[indexPath.row - 1],relatedController: self)
                        
                        return buyerOrdersDetailsCell
                        
                    default:
                        
                        let titleCell = tableView.dequeueReusableCellWithIdentifier("titleCell", forIndexPath: indexPath) as! TitleCell
                        titleCell.configureTitleInfo("you have no orders to deliver")
                        
                        return titleCell
                    }
                }else{
                    switch indexPath.row {
                        
                    case 0:
                        
                        let titleCell = tableView.dequeueReusableCellWithIdentifier("titleCell", forIndexPath: indexPath) as! TitleCell
                        titleCell.configureTitleInfo("placed orders")
                        
                        return titleCell
                        
                    case 1...buyerOrders.count:
                        let buyerOrdersDetailsCell = tableView.dequeueReusableCellWithIdentifier("orderDetailsCell", forIndexPath: indexPath) as! MyOrdersDetailsCell
                        buyerOrdersDetailsCell.configureOrdersDetails(self.buyerOrders[indexPath.row - 1],relatedController: self)
                        
                        return buyerOrdersDetailsCell
                        
                    case buyerOrders.count + 1:
                        
                        let titleCell = tableView.dequeueReusableCellWithIdentifier("titleCell", forIndexPath: indexPath) as! TitleCell
                        titleCell.configureTitleInfo("orders to deliver")
                        
                        return titleCell
                    default :
                        
                        let sellerOrdersDetailsCell = tableView.dequeueReusableCellWithIdentifier("orderDetailsCell", forIndexPath: indexPath) as! MyOrdersDetailsCell
                        sellerOrdersDetailsCell.configureOrdersDetails(self.sellerOrders[indexPath.row - (buyerOrders.count + 2)],relatedController: self)
                        
                        return sellerOrdersDetailsCell
                        
                    }
                    
                }
                
                
                
            }
            
            
        }
        
        
        
        
        
        
    }
    //-----------------------------以上是跟列表相关的回调函数--------------------------------------//

    
}
