//
//  MeTableViewCell.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/28.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class  UserProfileTableViewCell: UITableViewCell {
    
    @IBOutlet weak var userThumnailImg: UIImageView!
    
    @IBOutlet weak var usernameLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!
    
    func configueUserProfileInfo(username:String,email:String,phone:String,thumbnailUInt8Array:[UInt8]){
        usernameLabel.text = "username:" + username
        emailLabel.text = "email:" + email
        phoneLabel.text = "phone:" + phone
        
        userThumnailImg.image = UIImage(data: NSData(bytes: thumbnailUInt8Array, length: thumbnailUInt8Array.count))
    }
    
}


class  BalanceTableViewCell: UITableViewCell {
    
    @IBOutlet weak var balanceTitleLabel: UILabel!
    
    @IBOutlet weak var topUpLabel: UILabel!
    
    func configueBalanceInfo(balance:Double){
        let balanceDoubleToString = NSString(format: "%.2f" , balance) as String
        balanceTitleLabel.text = "balance: $" + balanceDoubleToString
        topUpLabel.text = "top up"
    }
    
}

class  ActionTableViewCell: UITableViewCell {
    
    @IBOutlet weak var actionTitleLabel: UILabel!

    
    func configureActionInfo(actionTitle:String){
        actionTitleLabel.text = actionTitle
    }
    
}

class ExitBtnTableViewCell: UITableViewCell {
    
    var relatedController = UIViewController()
    
    @IBOutlet weak var exitBtn: UIButton!
    
    @IBAction func exitAction(sender: UIButton) {
        
        showAlertDialog(relatedController,title:"Alert",message: "Are your sure to exit?",OKHandler: { (action) -> Void in
            
            let loginViewController = UIStoryboard(name: "Login", bundle: nil).instantiateViewControllerWithIdentifier("Login") as! LoginViewController
            
            
            self.relatedController.presentViewController(loginViewController, animated: true, completion: nil)
            
            
        },cancelHandler: nil)

    }
    
    func configureExitBtnInfo(exitBtnTitle:String,relatedController:UIViewController){
        exitBtn.titleLabel?.text = exitBtnTitle
        self.relatedController = relatedController
    }
}
