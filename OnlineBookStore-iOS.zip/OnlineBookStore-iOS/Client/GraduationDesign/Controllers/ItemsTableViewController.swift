//
//  ItemsListViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/9.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

var thisItemsTableViewController = ItemsTableViewController()

class ItemsTableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchResultsUpdating{
    
    
    // MARK: - Outlet -
    
    @IBOutlet var backgroundView: UIView!
    
    @IBOutlet weak var itemsTable: UITableView!
    
    //MARK: - Property -
    var items: [Item] = []
    let itemCellIdentifier = "itemsTableCell"

    var header = MJRefreshNormalHeader()

    var footer = MJRefreshAutoNormalFooter()
    

    var itemSearchController = UISearchController()

    var searchArray:[Item] = [Item](){
        didSet  {self.itemsTable.reloadData()}
    }

    var userID = Int()
    var username = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        thisItemsTableViewController = self
        
        let defaults = NSUserDefaults.standardUserDefaults()
        userID = defaults.objectForKey("userID") as! Int
        username = defaults.objectForKey("username") as! String
 
        let getItemsParams = JSON(["action":"initialize","username":username])
        
        ProcessNetworkMsg(relatedController: self, request: "getItems", params: getItemsParams, msg: "").processSocket()
        
        
        
        header.setRefreshingTarget(self, refreshingAction: Selector("headerRefresh"))
        self.itemsTable.mj_header = header
        
        footer.setRefreshingTarget(self, refreshingAction: Selector("footerRefresh"))
        self.itemsTable.tableFooterView = footer
        self.itemsTable.mj_footer = footer
        
        
        self.itemSearchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.hidesNavigationBarDuringPresentation = false
            controller.dimsBackgroundDuringPresentation = false
            controller.searchBar.searchBarStyle = .Minimal
            controller.searchBar.sizeToFit()
            self.itemsTable.tableHeaderView = controller.searchBar
            
            return controller
        })()
        
        
        // Do any additional setup after loading the view.
    }
    
    var hasLoadedMore = false
    
    func headerRefresh(){
        
        let getItemsParams = JSON(["action":"refresh","username":username])
        
        items = []
        
        if hasLoadedMore{
            footer = MJRefreshAutoNormalFooter()
            footer.setRefreshingTarget(self, refreshingAction: Selector("footerRefresh"))
            self.itemsTable.tableFooterView = footer
            self.itemsTable.mj_footer = footer
        }
        
        
        ProcessNetworkMsg(relatedController: self, request: "getItems", params: getItemsParams, msg: "").processSocket()
        self.itemsTable.mj_header.endRefreshing()
    }
    
    var index = 0
    func footerRefresh(){

        let getItemsParams = JSON(["action":"loadMore","minId": items[items.count - 1].itemIdInDB,"username":username])
        
        ProcessNetworkMsg(relatedController: self, request: "getItems", params: getItemsParams, msg: "").processSocket()
        
        self.itemsTable.mj_footer.endRefreshing()
        
        hasLoadedMore = true
        
    }
    
    func autoRefreshItemsTable(){
        
        let getItemsParams = JSON(["action":"refresh","username":username])
        
        items = []
        
        if hasLoadedMore{
            footer = MJRefreshAutoNormalFooter()
            footer.setRefreshingTarget(self, refreshingAction: Selector("footerRefresh"))
            self.itemsTable.tableFooterView = footer
            self.itemsTable.mj_footer = footer
        }
        
        
        ProcessNetworkMsg(relatedController: self, request: "getItems", params: getItemsParams, msg: "").processSocket()
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "viewDetails"{
            let controller = segue.destinationViewController as! ItemsDetailsViewController
            let selectedItemsIdInDB = sender as! Int
            
            for item in items{
                
                if item.itemIdInDB == selectedItemsIdInDB{
                    controller.itemThumbnailUInt8Array = item.thumbnailUInt8Array
                    controller.itemName = item.itemName
                    controller.itemPrice = item.itemEachPrice
                    controller.itemSeller = item.itemSeller
                    controller.itemIntro = item.itemIntroduction
                    controller.itemIdInDB = item.itemIdInDB
                    controller.itemAuthor = item.itemAuthor
                    controller.itemNumbersInCache = item.itemNumbersInCache
                    controller.userID = userID
                    
                }
            }
        }
    }

    

    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.itemSearchController.active){
            return self.searchArray.count
        } else{
            return self.items.count
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let itemCell = tableView.dequeueReusableCellWithIdentifier(itemCellIdentifier, forIndexPath: indexPath) as! ItemsTableViewCell
        
        if (self.itemSearchController.active){
            itemCell.configueItemInfo(self.searchArray[indexPath.row],relatedController: self)
            return itemCell
        }else{
            itemCell.configueItemInfo(items[indexPath.row],relatedController: self)
            return itemCell
        }
        
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let selectedItemIdInDB = items[indexPath.row].itemIdInDB
        
        self.performSegueWithIdentifier("viewDetails", sender: selectedItemIdInDB)
    }
    
    
    

    
    func updateSearchResultsForSearchController(searchController: UISearchController){
        
         self.searchArray.removeAll(keepCapacity: false)
        
        let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@",searchController.searchBar.text!)
        
        var itemsName = [String]()
        
        for eachItem in items{
            itemsName.append(eachItem.itemName)
        }
        
        let array = (itemsName as NSArray).filteredArrayUsingPredicate(searchPredicate)
        
        for var i = 0; i < array.count; i++ {
            for var j = 0; j < items.count; j++ {
                
                if items[j].itemName == (array as! [String])[i]{
                    searchArray.append(items[j])
                }
                
            }
            
        }
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
