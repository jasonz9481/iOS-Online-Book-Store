//
//  MeDetailsEdtionView.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/11.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class MeDetailsEdtionView: UIViewController,UINavigationControllerDelegate {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var valueTF: UITextField!
    
    var titleStr = String()
    
    var valueStr = String()
    
    var placeholder = String()
    
    var downLayerController = MeDetailsTableViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let barButtonItem = UIBarButtonItem(title: "Save", style: UIBarButtonItemStyle.Plain, target: self, action: "saveEdition")
        self.navigationItem.rightBarButtonItem = barButtonItem
        
        
        titleLabel.text = titleStr
        valueTF.placeholder = placeholder
        valueTF.text = valueStr
        
    }
    
    func saveEdition(){
        
        switch titleStr{
            
        case "username:":
            
            let editText = valueTF.text!
            downLayerController.edittedUsername = editText
            
            if editText != downLayerController.username{
                downLayerController.usernameHasBeenEditted = true
                downLayerController.navigationItem.rightBarButtonItem?.enabled = true
            }else{
                downLayerController.usernameHasBeenEditted = false
            }
            
            break
            
        case "password:":
            
            let editText = valueTF.text!
            
            downLayerController.edittedPassword = editText
            
            if editText != downLayerController.password{
                downLayerController.passwordHasBeenEditted = true
                downLayerController.navigationItem.rightBarButtonItem?.enabled = true
            }else{
                downLayerController.passwordHasBeenEditted = false
            }
            
            
            break
            
        case "email:":
            
            let editText = valueTF.text!
            
            downLayerController.edittedEmail = editText
            
            if editText != downLayerController.email{
                downLayerController.emailHasBeenEditted = true
                downLayerController.navigationItem.rightBarButtonItem?.enabled = true
            }else{
                downLayerController.emailHasBeenEditted = false
            }
            
            break
            
        default:
            
            let editText = valueTF.text!
            
            downLayerController.edittedPhone = editText
            
            if editText != downLayerController.phone{
                downLayerController.phoneHasBeenEditted = true
                downLayerController.navigationItem.rightBarButtonItem?.enabled = true
            }else{
                downLayerController.phoneHasBeenEditted = false
            }
            
            break
            
        }
        
        downLayerController.meDetailsInfoTable.reloadData()
        
        self.navigationController?.popViewControllerAnimated(true)
    }

    
}
