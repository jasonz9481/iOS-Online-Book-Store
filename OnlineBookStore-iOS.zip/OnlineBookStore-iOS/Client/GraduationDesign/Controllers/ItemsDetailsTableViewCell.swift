//
//  ItemsDetailsTableViewCell.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/10.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class ItemsDetailsShortInfoTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var valueLabel: UILabel!
    
    func configureDetailsInfo(title:String,value:String){
        
        titleLabel.text = title
        valueLabel.text = value
    }

}


class ItemsDetailsIntroTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var valueLabel: myUILabel!

    
    func configureDetailsInfo(value:String){
        
        valueLabel.lineBreakMode = NSLineBreakMode.ByWordWrapping
        valueLabel.numberOfLines = 0
        valueLabel.verticalAlignment = VerticalAlignmentTop
        
        titleLabel.text = "Introduction:"
        valueLabel.text = value
    }
    
}