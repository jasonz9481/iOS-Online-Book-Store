//
//  ItemsDetailsViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/10.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class ItemsDetailsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var itemThumbnailImg: UIImageView!
    
    @IBOutlet weak var itemDetailsTable: UITableView!
    
    var itemThumbnailUInt8Array = [UInt8]()
    
    var itemName = String()
    
    var itemPrice = Double()
    
    var itemSeller = String()
    
    var itemIntro = String()

    var itemIdInDB = Int()
    
    var itemAuthor = String()
    
    var itemNumbersInCache = Int()
    
    
    var userID = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        itemThumbnailImg.image = UIImage(data: NSData(bytes: itemThumbnailUInt8Array, length: itemThumbnailUInt8Array.count))
        
        let barButtonItem = UIBarButtonItem(title: "PutInCart", style: UIBarButtonItemStyle.Plain, target: self, action: "putInShoppingCart")
        self.navigationItem.rightBarButtonItem = barButtonItem
        
        // Do any additional setup after loading the view.
    }
    
    func putInShoppingCart(){

        let putInShoppingCartParams = JSON(["itemId":itemIdInDB,"userId":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "putInShoppingCart", params: putInShoppingCartParams, msg: "").processSocket()
        
        
        
    }
    

    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 6
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == 5{
            return 150
        }else{
            return 40
        }
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.row{
            
        case 0:
            let itemNameCell = tableView.dequeueReusableCellWithIdentifier("itemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! ItemsDetailsShortInfoTableViewCell
            itemNameCell.configureDetailsInfo("Name:",value:self.itemName)
            
            return itemNameCell
            
        case 1:
            let itemSellerCell = tableView.dequeueReusableCellWithIdentifier("itemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! ItemsDetailsShortInfoTableViewCell
            itemSellerCell.configureDetailsInfo("Author:",value:self.itemAuthor)
            
            return itemSellerCell
            
        case 2:
            let itemPriceCell = tableView.dequeueReusableCellWithIdentifier("itemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! ItemsDetailsShortInfoTableViewCell
            itemPriceCell.configureDetailsInfo("Price:",value:String(self.itemPrice))
            
            return itemPriceCell
            
            
        case 3:
            let itemSellerCell = tableView.dequeueReusableCellWithIdentifier("itemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! ItemsDetailsShortInfoTableViewCell
            itemSellerCell.configureDetailsInfo("Seller:",value:self.itemSeller)
            
            return itemSellerCell
            
        case 4:
            let itemSellerCell = tableView.dequeueReusableCellWithIdentifier("itemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! ItemsDetailsShortInfoTableViewCell
            itemSellerCell.configureDetailsInfo("Stock:",value:String(self.itemNumbersInCache))
            
            return itemSellerCell
            
            
        default:
            let itemIntroCell = tableView.dequeueReusableCellWithIdentifier("itemsIntroCell", forIndexPath: indexPath) as! ItemsDetailsIntroTableViewCell
            itemIntroCell.configureDetailsInfo(self.itemIntro)
            
            return itemIntroCell
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
