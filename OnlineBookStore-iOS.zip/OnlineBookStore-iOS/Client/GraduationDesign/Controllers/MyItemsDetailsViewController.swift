//
//  MyItemsDetailsViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/16.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class MyItemsDetailsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var myItemsThumbnailImg: UIImageView!
    
    @IBOutlet weak var myItemsDetailsTable: UITableView!
    
    var itemThumbnailUInt8Array = [UInt8]()
    
    var itemName = String()
    
    var itemPrice = Double()
    
    var itemSeller = String()
    
    var itemIntro = String()
    
    var itemIdInDB = Int()
    
    var itemAuthor = String()
    
    var itemNumbersInCache = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myItemsThumbnailImg.image = UIImage(data: NSData(bytes: itemThumbnailUInt8Array, length: itemThumbnailUInt8Array.count))
        
        
        // Do any additional setup after loading the view.
    }

    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 6
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == 5{
            return 150
        }else{
            return 40
        }
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.row{
            
        case 0:
            let itemNameCell = tableView.dequeueReusableCellWithIdentifier("myItemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! MyItemsDetailsShortInfoTableCell
            itemNameCell.configureDetailsInfo("Name:",value:self.itemName)
            
            return itemNameCell
            
        case 1:
            let itemSellerCell = tableView.dequeueReusableCellWithIdentifier("myItemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! MyItemsDetailsShortInfoTableCell
            itemSellerCell.configureDetailsInfo("Author:",value:self.itemAuthor)
            
            return itemSellerCell
            
        case 2:
            let itemPriceCell = tableView.dequeueReusableCellWithIdentifier("myItemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! MyItemsDetailsShortInfoTableCell
            itemPriceCell.configureDetailsInfo("Price:",value:String(self.itemPrice))
            
            return itemPriceCell
            
            
        case 3:
            let itemSellerCell = tableView.dequeueReusableCellWithIdentifier("myItemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! MyItemsDetailsShortInfoTableCell
            itemSellerCell.configureDetailsInfo("Seller:",value:self.itemSeller)
            
            return itemSellerCell
            
        case 4:
            let itemNumberInCacheCell = tableView.dequeueReusableCellWithIdentifier("myItemsDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! MyItemsDetailsShortInfoTableCell
            itemNumberInCacheCell.configureDetailsInfo("Stock:",value:String(self.itemNumbersInCache))
            
            return itemNumberInCacheCell
            
            
        default:
            let itemIntroCell = tableView.dequeueReusableCellWithIdentifier("myItemsIntroCell", forIndexPath: indexPath) as! MyItemsDetailsIntroTableCell
            itemIntroCell.configureDetailsInfo(self.itemIntro)
            
            return itemIntroCell
            
        }
    }
    
}
