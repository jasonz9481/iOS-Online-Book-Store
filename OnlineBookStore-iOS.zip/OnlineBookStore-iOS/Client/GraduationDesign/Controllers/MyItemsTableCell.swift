//
//  MyItemsTableCell.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/14.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class MyItemsTableCell: UITableViewCell {
    
    @IBOutlet weak var itemThumbnailImg: UIImageView!
    
    @IBOutlet weak var itemNameLabel: UILabel!
    
    @IBOutlet weak var itemNumberInCacheLabel: UILabel!
    
    @IBOutlet weak var itemPriceLabel: UILabel!
    
    @IBOutlet weak var addBtn: UIButton!
    
    @IBAction func addNumAction(sender: UIButton) {
        
        itemNumberInCache += 1
        itemNumberTF.text = String(itemNumberInCache)
    }
    
    @IBOutlet weak var subtractBtn: UIButton!
    
    @IBAction func subtractNumAction(sender: UIButton) {
        
        if itemNumberInCache > 0{
            itemNumberInCache -= 1
            itemNumberTF.text = String(itemNumberInCache)
        }
    }
    
    
    @IBOutlet weak var itemNumberTF: UITextField!
    
    @IBOutlet weak var submitEditionBtn: UIButton!
    
    @IBAction func submitEditionAction(sender: UIButton) {
        
        let realRelatedController = relatedController as! MyItemsTableViewController
        
        if itemNumberInCache != originalItemNumberInCache{
            
            if itemNumberInCache == 0{
                
                showAlertDialog(realRelatedController, title: "Alert", message: "Are you sure to delete it?", OKHandler: { (action) -> Void in
                    
                    let deleteItemsParams = JSON(["itemId":self.itemIdInDB])
                    
                    ProcessNetworkMsg(relatedController: realRelatedController, request: "deleteItemInCache", params: deleteItemsParams, msg: "").processSocket()
                    
                    
                    
                    },cancelHandler: nil)
                
            }else{

                let getItemsParams = JSON(["itemId":self.itemIdInDB,"edittedNum":itemNumberInCache])
                
                ProcessNetworkMsg(relatedController: relatedController, request: "editItemNumberInCache", params: getItemsParams, msg: "").processSocket()
            }
            
        }
        addBtn.hidden = true
        subtractBtn.hidden = true
        itemNumberTF.hidden = true
        submitEditionBtn.hidden = true
        
        itemNameLabel.hidden = false
        itemNumberInCacheLabel.hidden = false
        itemPriceLabel.hidden = false
        
        self.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
    }
    
    
    var itemIdInDB = Int()
    
    var relatedController = UIViewController()
    
    var itemNumberInCache = Int()
    
    var originalItemNumberInCache = Int()
    
    
    func configureMyItemsInfo(item:Item,relatedController:UIViewController){
        
        itemNameLabel.text = item.itemName
        let priceDoubleToString = NSString(format: "%.2f" , item.itemEachPrice) as String
        itemPriceLabel.text = "price: $" + priceDoubleToString
        itemNumberInCacheLabel.text = "stock:" + String(item.itemNumbersInCache)
        
        itemThumbnailImg.image = UIImage(data: NSData(bytes: item.thumbnailUInt8Array, length: item.thumbnailUInt8Array.count))
        
        self.itemIdInDB = item.itemIdInDB
        self.relatedController = relatedController
        
        addBtn.layer.cornerRadius = 8
        subtractBtn.layer.cornerRadius = 8
        submitEditionBtn.layer.cornerRadius = 8
        
        
        originalItemNumberInCache = item.itemNumbersInCache
        itemNumberInCache = originalItemNumberInCache

        addBtn.hidden = true
        subtractBtn.hidden = true
        itemNumberTF.hidden = true
        submitEditionBtn.hidden = true
        
    }

}
