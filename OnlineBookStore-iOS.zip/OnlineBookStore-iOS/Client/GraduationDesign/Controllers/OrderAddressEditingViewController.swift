//
//  OrderAddressEditingViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/20.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class OrderAddressEditingViewController: UIViewController {
    
    @IBOutlet weak var receiverTF: UITextField!
    
    @IBOutlet weak var phoneTF: UITextField!
    
    @IBOutlet weak var passcodeTF: UITextField!

    @IBOutlet weak var addressTV: UITextView!
    
    @IBOutlet weak var isDefaultSwitch: UISwitch!
    
    var idInDB = Int()
    
    var downLayerController = OrderAddressesTableViewController()
    
    var originalReceiver = String()
    var receiver = String()
    
    var originalPhone = String()
    var phone = String()
    
    var originalPasscode = String()
    var passcode = String()
    
    var originalAddress = String()
    var address = String()
    
    var originalIsDefault = String()
    var isDefault = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addressTV.layer.borderWidth = 0.5
        
        receiverTF.text = originalReceiver
        phoneTF.text = originalPhone
        passcodeTF.text = originalPasscode
        addressTV.text = originalAddress
        
        switch originalIsDefault {
            
        case "Y":
            isDefaultSwitch.on = true
            break
            
        default:
            isDefaultSwitch.on = false
            break
        }
        
        let barButtonItem = UIBarButtonItem(title: "Save", style: UIBarButtonItemStyle.Plain, target: self, action: "save")
        self.navigationItem.rightBarButtonItem = barButtonItem
        
    }
    
    func save(){
        
        receiver = receiverTF.text!
        phone = phoneTF.text!
        passcode = passcodeTF.text!
        address = addressTV.text
        
        switch isDefaultSwitch.on{
            
        case true:
            isDefault = "Y"
            break
            
        default:
            isDefault = "N"
            break
        }
        
        if receiver == originalReceiver && phone == originalPhone && passcode == originalPasscode && address == originalAddress && isDefault == originalIsDefault{
            
            showAlertDialog(self, title: "Message", message: "Did not edit", OKHandler: { (action) -> Void in
                
                self.navigationController?.popViewControllerAnimated(true)
            })
            
        }else{
            
            if receiver != originalReceiver {
                let editAddressParams = JSON(["idInDB":idInDB,"column":"address_receiver","value":receiver])
                ProcessNetworkMsg(relatedController: self, request: "editAddress", params: editAddressParams, msg: "").processSocket()
            }
            
            if phone != originalPhone {
                let editAddressParams = JSON(["idInDB":idInDB,"column":"address_phone","value":phone])
                ProcessNetworkMsg(relatedController: self, request: "editAddress", params: editAddressParams, msg: "").processSocket()
            }
            
            if passcode != originalPasscode {
                let editAddressParams = JSON(["idInDB":idInDB,"column":"address_passcode","value":passcode])
                ProcessNetworkMsg(relatedController: self, request: "editAddress", params: editAddressParams, msg: "").processSocket()
            }
            
            if address != originalAddress {
                let editAddressParams = JSON(["idInDB":idInDB,"column":"address_address","value":address])
                ProcessNetworkMsg(relatedController: self, request: "editAddress", params: editAddressParams, msg: "").processSocket()
            }
            
            if isDefault != originalIsDefault {
                let editAddressParams = JSON(["idInDB":idInDB,"column":"isDefault","value":isDefault])
                ProcessNetworkMsg(relatedController: self, request: "editAddress", params: editAddressParams, msg: "").processSocket()
            }
            
        }
        
        
        
        
    }
}
