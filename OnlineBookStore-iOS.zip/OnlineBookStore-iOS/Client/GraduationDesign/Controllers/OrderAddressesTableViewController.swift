//
//  OrderAddressesTableViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/19.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class OrderAddressesTableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var orderAddressesTable: UITableView!
    
    var addresses:[OrderAddress] = []
    
    var userID = Int()
    
    var downLayerController = OrderTableViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        orderAddressesTable.tableFooterView = UIView()
        
        let barButtonItem = UIBarButtonItem(title: "Add a new address", style: UIBarButtonItemStyle.Plain, target: self, action: "addAddress")
        self.navigationItem.rightBarButtonItem = barButtonItem
        
        let getAddressesParams = JSON(["userID":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "getAddresses", params: getAddressesParams, msg: "").processSocket()
        
    }
    
    func addAddress(){
        self.performSegueWithIdentifier("addAddress", sender: nil)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "addAddress"{
            let controller = segue.destinationViewController as! OrderAddressAddingViewController
            
            controller.userID = self.userID
            controller.downLayerController = self
        }else if segue.identifier == "editAddress"{
            
            let index = sender as! Int
            
            let controller = segue.destinationViewController as! OrderAddressEditingViewController
            
            let selectedIdInDB = addresses[index].idInDB
            controller.idInDB = selectedIdInDB
            
            let selectedReceiver = addresses[index].receiver
            controller.originalReceiver = selectedReceiver
            
            let selectedPhone = addresses[index].phone
            controller.originalPhone = selectedPhone
            
            let selectedPasscode = addresses[index].passcode
            controller.originalPasscode = selectedPasscode
            
            let selectedRoad = addresses[index].road
            controller.originalAddress = selectedRoad
            
            let selectedIsDefault = addresses[index].isDefault
            controller.originalIsDefault = selectedIsDefault
            
            controller.downLayerController = self
            
        }
    }
    
    func autoRefresh(){
        
        addresses = []
        
        let getAddressesParams = JSON(["userID":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "getAddresses", params: getAddressesParams, msg: "").processSocket()
    }

    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.addresses.count
        
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return 120
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let orderAddressCell = tableView.dequeueReusableCellWithIdentifier("orderAddressTableCell", forIndexPath: indexPath) as! OrderAddressesTableCell
        orderAddressCell.configureAddressInfo(addresses[indexPath.row].receiver, phone: addresses[indexPath.row].phone, address: addresses[indexPath.row].road + "\n" + addresses[indexPath.row].passcode)
        
        return orderAddressCell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        downLayerController.orderAddress = addresses[indexPath.row]
        downLayerController.orderInfoTable.reloadData()
        
        self.navigationController?.popViewControllerAnimated(true)
 

    }
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        
        let delete = UITableViewRowAction(style: .Normal, title: "Delete") { action, index in
            
            showAlertDialog(self, title: "Alert", message: "Are you sure to delete this address?", OKHandler: { (action) -> Void in
                
                let deleteItemsParams = JSON(["idInDB":self.addresses[indexPath.row].idInDB])
                
                ProcessNetworkMsg(relatedController: self, request: "deleteAddress", params: deleteItemsParams, msg: "").processSocket()
   
                
                },cancelHandler: nil)
            
            
        }
        delete.backgroundColor = UIColor.redColor()
        
        let edit = UITableViewRowAction(style: .Normal, title: "Edit") { action, index in
            
            self.performSegueWithIdentifier("editAddress", sender: indexPath.row)
            
        }
        edit.backgroundColor = UIColor.blueColor()
        
        return [delete, edit]
    }
}
