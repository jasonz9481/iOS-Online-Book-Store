//
//  MeTopUpViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/12.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class MeTopUpViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: myUILabel!
    
    @IBOutlet weak var balanceLabel: UILabel!
    
    @IBOutlet weak var topUpBtn: UIButton!
    
    @IBAction func topUpAction(sender: UIButton) {
        
        let alertController = UIAlertController(title: "top up", message: "please input the number you need to top up", preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addTextFieldWithConfigurationHandler {
            (textField: UITextField!) -> Void in
            
        }
        let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler:{
            action in
            let topUpNumberTF = alertController.textFields!.first! as UITextField
            let topUpNumber = topUpNumberTF.text!
            
            let topUpParams = JSON(["userID":self.userID,"originalBalance":self.balance,"topUpNum":(topUpNumber as NSString).doubleValue])
            
            ProcessNetworkMsg(relatedController: self, request: "topUp", params: topUpParams, msg: "").processSocket()

        } )
        alertController.addAction(OKAction)
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    var username = String()
    var balance  = Double()
    var userID = Int()
    var downLayerController = MeViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        titleLabel.lineBreakMode = NSLineBreakMode.ByWordWrapping
        titleLabel.numberOfLines = 0
        titleLabel.text = "Hello, " + username + ",your balance is:"
        let balanceDoubleToString = NSString(format: "%.2f" , balance) as String
        balanceLabel.text = balanceDoubleToString
        topUpBtn.layer.cornerRadius = 8
        
    }

}
