//
//  OrderAddressAddingViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/20.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit


class OrderAddressAddingViewController: UIViewController {
    
    @IBOutlet weak var receiverTF: UITextField!
    
    @IBOutlet weak var phoneTF: UITextField!
    
    @IBOutlet weak var passcodeTF: UITextField!
    
    @IBOutlet weak var addressTV: UITextView!
    
    @IBOutlet weak var isDefaultSwtich: UISwitch!
    
    var userID = Int()
    
    var downLayerController = OrderAddressesTableViewController()
    
    var receiver = String()
    
    var phone = String()
    
    var passcode = String()
    
    var address = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addressTV.layer.borderWidth = 0.5
        
        let barButtonItem = UIBarButtonItem(title: "Save", style: UIBarButtonItemStyle.Plain, target: self, action: "save")
        self.navigationItem.rightBarButtonItem = barButtonItem
        
    }
    
    func save(){
        
        receiver = receiverTF.text!
        phone = phoneTF.text!
        passcode = passcodeTF.text!
        address = addressTV.text
        
        if receiver == "" && phone == "" && passcode == "" && address == ""{
            
            showAlertDialog(self, title: "Alert", message: "Did not add", OKHandler: { (action) -> Void in
                
                self.navigationController?.popViewControllerAnimated(true)
            })

        }else{
            if receiver != "" {
                
                if verifyPhone(phone) != "hasNotInput" {
   
                            if passcode != "" {
                                
                                if address != "" {
                                    
                                    if isDefaultSwtich.on{
                                        let addAddressesParams = JSON(["userID":userID,"receiver":receiver,"phone":phone,"passcode":passcode,"address":address,"isDefault":"Y"])
                                        ProcessNetworkMsg(relatedController: self, request: "addAddress", params: addAddressesParams, msg: "").processSocket()
                                        
                                    }else{
                                        let addAddressesParams = JSON(["userID":userID,"receiver":receiver,"phone":phone,"passcode":passcode,"address":address,"isDefault":"N"])
                                        
                                        ProcessNetworkMsg(relatedController: self, request: "addAddress", params: addAddressesParams, msg: "").processSocket()
                                    }
                                    
                                }else {
                                    showAlertDialog(self, title: "Alert", message: "please input your address!", OKHandler: nil)
                                }
                                
                            }else{
                                showAlertDialog(self, title: "Alert", message: "please input your postcode", OKHandler: nil)
                            }
                }else{
                    showAlertDialog(self, title: "Alert", message: "please input your phone number!", OKHandler: nil)
                }
                
            }else{
                showAlertDialog(self, title: "Alert", message: "please input receiver's name!", OKHandler: nil)
            }
        }
        
        
        
        
    }

}
