//
//  ShoppingCartDetailsViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/11.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class ShoppingCartDetailsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var shoppingCartItemDetailsTable: UITableView!
    
    @IBOutlet weak var shoppingCartItemImg: UIImageView!
    
    var itemThumbnailUInt8Array = [UInt8]()
    
    var itemName = String()
    
    var itemPrice = Double()
    
    var itemSeller = String()
    
    var itemIntro = String()
    
    var itemIdInDB = Int()
    
    var userID = Int()
    
    var isAbleToPutInShoppingCart = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        shoppingCartItemDetailsTable.scrollEnabled = false
        
        shoppingCartItemImg.image = UIImage(data: NSData(bytes: itemThumbnailUInt8Array, length: itemThumbnailUInt8Array.count))
        
        if isAbleToPutInShoppingCart {
            let barButtonItem = UIBarButtonItem(title: "PutInCart", style: UIBarButtonItemStyle.Plain, target: self, action: "putInShoppingCart")
            self.navigationItem.rightBarButtonItem = barButtonItem
        }
        
        
        
        // Do any additional setup after loading the view.
    }
    
    func putInShoppingCart(){
        
        let putInShoppingCartParams = JSON(["itemId":itemIdInDB,"userId":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "putInShoppingCart", params: putInShoppingCartParams, msg: "").processSocket()
    }
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 4
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == 3{
            return 150
        }else{
            return 40
        }
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.row{
            
        case 0:
            let itemNameCell = tableView.dequeueReusableCellWithIdentifier("shoppingCartDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! ShoppingCartDetailsShortInfoTableViewCell
            itemNameCell.configureDetailsInfo("Name:",value:self.itemName)
            
            return itemNameCell
            
        case 1:
            let itemPriceCell = tableView.dequeueReusableCellWithIdentifier("shoppingCartDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! ShoppingCartDetailsShortInfoTableViewCell
            itemPriceCell.configureDetailsInfo("Price",value:String(self.itemPrice))
            
            return itemPriceCell
            
            
        case 2:
            let itemSellerCell = tableView.dequeueReusableCellWithIdentifier("shoppingCartDetailsShortInfoTableViewCell", forIndexPath: indexPath) as! ShoppingCartDetailsShortInfoTableViewCell
            itemSellerCell.configureDetailsInfo("Seller:",value:self.itemSeller)
            
            return itemSellerCell
            
            
        default:
            let itemIntroCell = tableView.dequeueReusableCellWithIdentifier("shoppingCartDetaildIntroCell", forIndexPath: indexPath) as! ShoppingCartDetailsIntroTableViewCell
            itemIntroCell.configureDetailsInfo(self.itemIntro)
            
            return itemIntroCell
            
        }
    }
    

}
