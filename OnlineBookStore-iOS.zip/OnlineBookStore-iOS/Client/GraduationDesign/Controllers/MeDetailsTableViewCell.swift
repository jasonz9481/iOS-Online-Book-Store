//
//  MeDetailsTableViewCell.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/11.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class MeDetailsThumbnailTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var thumbnailImg: UIImageView!
    
    func configureThumbnailThroughUInt8Array(thumbnailUInt8Array:[UInt8]){
        
        titleLabel.text = "profile photo"
        
        thumbnailImg.image = UIImage(data: NSData(bytes: thumbnailUInt8Array, length: thumbnailUInt8Array.count))
        
    }
    
    func configureThumbnailThroughUIImage(thumbnailImage:UIImage){
        
        titleLabel.text = "profile photo"
        
        thumbnailImg.image = thumbnailImage
    }
    
}


class MeDetailsOthersTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var valueLabel: UILabel!
    
    func configureOthers(title:String,value:String){
        titleLabel.text = title
        valueLabel.text = value
    }
    
}

class MeDetailsPwdTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!

    @IBOutlet weak var valueTF: UITextField!
    
    func configurePwdInfo(value:String){
        
        titleLabel.text = "password"
        valueTF.text = value
        
        
    }
}


