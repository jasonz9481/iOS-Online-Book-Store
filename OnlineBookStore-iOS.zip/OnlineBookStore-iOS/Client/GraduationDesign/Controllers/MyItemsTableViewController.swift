//
//  MyItemsTableViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/14.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class MyItemsTableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchResultsUpdating {
    
    @IBOutlet weak var myItemsTable: UITableView!
    
    @IBOutlet weak var addItemsBtn: UIButton!
    
    @IBAction func addItemsAction(sender: UIButton) {
        
        self.performSegueWithIdentifier("addItems", sender: self.username)
    }
    
    var items:[Item] = []
    var username = String()
    
    var header = MJRefreshNormalHeader()
    var footer = MJRefreshAutoNormalFooter()
    
    var itemSearchController = UISearchController()

    var searchArray:[Item] = [Item](){
        didSet  {self.myItemsTable.reloadData()}
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let getMyItemsParams = JSON(["username":username,"action":"getMyItems_initialize"])
        
        ProcessNetworkMsg(relatedController: self, request: "getMyItems", params: getMyItemsParams, msg: "").processSocket()
        
        
        header.setRefreshingTarget(self, refreshingAction: Selector("headerRefresh"))
        self.myItemsTable.mj_header = header
        
        
        footer.setRefreshingTarget(self, refreshingAction: Selector("footerRefresh"))
        self.myItemsTable.tableFooterView = footer
        self.myItemsTable.mj_footer = footer
        
        
        
        self.itemSearchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.hidesNavigationBarDuringPresentation = false
            controller.dimsBackgroundDuringPresentation = false
            controller.searchBar.searchBarStyle = .Minimal
            controller.searchBar.sizeToFit()
            self.myItemsTable.tableHeaderView = controller.searchBar
            
            return controller
        })()
        
    }
    

    var hasLoadedMore = false
    

    func headerRefresh(){
        
        let getItemsParams = JSON(["username":username,"action":"getMyItems_refresh"])
        
        items = []
        
        if hasLoadedMore{
            footer = MJRefreshAutoNormalFooter()
            footer.setRefreshingTarget(self, refreshingAction: Selector("footerRefresh"))
            self.myItemsTable.tableFooterView = footer
            self.myItemsTable.mj_footer = footer
        }
        
        
        ProcessNetworkMsg(relatedController: self, request: "getMyItems", params: getItemsParams, msg: "").processSocket()

        self.myItemsTable.mj_header.endRefreshing()
    }
    

    var index = 0
    func footerRefresh(){
        
        let getItemsParams = JSON(["action":"getMyItems_loadMore","username":username,"minId": items[items.count - 1].itemIdInDB])
        
        ProcessNetworkMsg(relatedController: self, request: "getMyItems", params: getItemsParams, msg: "").processSocket()
        
        hasLoadedMore = true
        
    }
    
    func autoRefreshMyItemsTable(){
        
        items = []

        let getItemsParams = JSON(["username":username,"action":"getMyItems_refresh"])
        
        if hasLoadedMore{
            footer = MJRefreshAutoNormalFooter()
            footer.setRefreshingTarget(self, refreshingAction: Selector("footerRefresh"))
            self.myItemsTable.tableFooterView = footer
            self.myItemsTable.mj_footer = footer
        }
        
        
        ProcessNetworkMsg(relatedController: self, request: "getMyItems", params: getItemsParams, msg: "").processSocket()
        
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "viewMyItemDetails"{
            let controller = segue.destinationViewController as! MyItemsDetailsViewController
            let selectedItemsIdInDB = sender as! Int
            
            for item in items{
                
                if item.itemIdInDB == selectedItemsIdInDB{
                    controller.itemThumbnailUInt8Array = item.thumbnailUInt8Array
                    controller.itemName = item.itemName
                    controller.itemPrice = item.itemEachPrice
                    controller.itemSeller = item.itemSeller
                    controller.itemIntro = item.itemIntroduction
                    controller.itemIdInDB = item.itemIdInDB
                    controller.itemAuthor = item.itemAuthor
                    controller.itemNumbersInCache = item.itemNumbersInCache
                    
                }
            }
        }else if segue.identifier == "addItems"{
            let controller = segue.destinationViewController as! AddItemsTableViewController
            let username = sender as! String
            
            controller.username = username
            controller.downLayerController = self
        }
    }
    
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .Normal, title: "Delete") { action, index in
            
            showAlertDialog(self, title: "Alert", message: "Are you sure to delete it?", OKHandler: { (action) -> Void in
                
                let deleteItemsParams = JSON(["itemId":self.items[indexPath.row].itemIdInDB])
                
                ProcessNetworkMsg(relatedController: self, request: "deleteItemInCache", params: deleteItemsParams, msg: "").processSocket()
                
                
                
                },cancelHandler: nil)
            
            
        }
        delete.backgroundColor = UIColor.redColor()
        
        let edit = UITableViewRowAction(style: .Normal, title: "Edit") { action, index in
            
            let selectedCell = tableView.cellForRowAtIndexPath(indexPath) as! MyItemsTableCell
            selectedCell.accessoryType = UITableViewCellAccessoryType.None
            
            selectedCell.itemNameLabel.hidden = true
            selectedCell.itemNumberInCacheLabel.hidden = true
            selectedCell.itemPriceLabel.hidden = true
            
            selectedCell.addBtn.hidden = false
            selectedCell.subtractBtn.hidden = false
            selectedCell.itemNumberTF.hidden = false
            selectedCell.submitEditionBtn.hidden = false
            
            selectedCell.itemNumberTF.text = String(selectedCell.itemNumberInCache)
            
            tableView.setEditing(false, animated: true)
        }
        edit.backgroundColor = UIColor.blueColor()
        
        return [delete, edit]
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.itemSearchController.active){
            return self.searchArray.count
        } else{
            return self.items.count
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let itemCell = tableView.dequeueReusableCellWithIdentifier("myItemsTableCell", forIndexPath: indexPath) as! MyItemsTableCell
        
        if (self.itemSearchController.active){
            itemCell.configureMyItemsInfo(self.searchArray[indexPath.row],relatedController: self)
            return itemCell
        }else{
            itemCell.configureMyItemsInfo(items[indexPath.row],relatedController: self)
            return itemCell
        }
        
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let selectedItemIdInDB = items[indexPath.row].itemIdInDB
        
        self.performSegueWithIdentifier("viewMyItemDetails", sender: selectedItemIdInDB)
    }
    
    
    
    
    func updateSearchResultsForSearchController(searchController: UISearchController){
        
        self.searchArray.removeAll(keepCapacity: false)
        
        let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@",searchController.searchBar.text!)
        
        var itemsName = [String]()
        
        for eachItem in items{
            itemsName.append(eachItem.itemName)
        }
        
        let array = (itemsName as NSArray).filteredArrayUsingPredicate(searchPredicate)
        
        for var i = 0; i < array.count; i++ {
            for var j = 0; j < items.count; j++ {
                
                if items[j].itemName == (array as! [String])[i]{
                    searchArray.append(items[j])
                }
                
            }
            
        }
    }
    
    
}
