//
//  ViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/6.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class MainViewController: UITabBarController {
    
    var username = String()
    var email = String()
    var phone = String()
    var status = String()
    var balance = Double()
    var loginType = String()
    var userID = Int()
    var thumbnailArray = [UInt8]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let defaults = NSUserDefaults.standardUserDefaults()
        
        let itemsListNavigationViewController = UIStoryboard(name: "ItemsTable", bundle: nil).instantiateViewControllerWithIdentifier("itemsTableNav") as! UINavigationController
     
        let shoppingCartNavigationViewController = UIStoryboard(name: "ShoppingCart", bundle: nil).instantiateViewControllerWithIdentifier("ShoppingCartNav") as! UINavigationController
        let meNavigationViewController = UIStoryboard(name: "Me", bundle: nil).instantiateViewControllerWithIdentifier("meNav") as! UINavigationController
        
        defaults.setInteger(userID, forKey: "userID")
        defaults.setObject(username, forKey: "username")
        defaults.setObject(loginType, forKey: "loginType")
        defaults.setObject(status, forKey: "status")
        defaults.setObject(balance, forKey: "balance")
        
        itemsListNavigationViewController.tabBarItem.title = "Items"
        itemsListNavigationViewController.tabBarItem.image = UIImage(named:"itemsListIcon.png")
        shoppingCartNavigationViewController.tabBarItem.title = "Shopping Cart"
        shoppingCartNavigationViewController.tabBarItem.image = UIImage(named:"shoppingCartIcon.png")
        meNavigationViewController.tabBarItem.title = "Me"
        meNavigationViewController.tabBarItem.image = UIImage(named:"meIcon.png")
        
        let tabBarViewControllers = [itemsListNavigationViewController,shoppingCartNavigationViewController,meNavigationViewController]
        
        self.setViewControllers(tabBarViewControllers, animated: true)
        
        self.selectedIndex = 0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

