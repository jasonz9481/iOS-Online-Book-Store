//
//  ShoppingCartTableViewCell.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/31.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class ShoppingCartTableViewCell: UITableViewCell {
    
    @IBOutlet weak var itemsThumbnailImg: UIImageView!
    
    @IBOutlet weak var itemsNameLabel: UILabel!
    
    @IBOutlet weak var itemsSellerLabel: UILabel!
    
    @IBOutlet weak var itemsPrice: UILabel!

    @IBOutlet weak var addNumBtn: UIButton!
    
    @IBAction func addNumAction(sender: UIButton) {
        
        itemNumber += 1
        itemsNumberStr = String(itemNumber)
        
        itemsNumTF.text = itemsNumberStr
        
    }
    
    @IBOutlet weak var subtractNumBtn: UIButton!
    
    @IBAction func subtractAction(sender: UIButton) {
        
        if itemNumber > 0{
            itemNumber -= 1
            itemsNumberStr = String(itemNumber)
            
            itemsNumTF.text = itemsNumberStr
        }
        
    }
    
    @IBOutlet weak var itemsNumTF: UITextField!

    @IBOutlet weak var submitEditionBtn: UIButton!
    
    @IBAction func submitEditionAction(sender: UIButton) {
        
        if itemNumber != itemOriginalNumber{
            
            if itemNumber == 0{
                
                showAlertDialog(relatedController, title: "Alert", message: "Are you sure to delete this item?", OKHandler: { (action) -> Void in
                    
                    let deleteItemsParams = JSON(["userID":self.relatedController.userID,"itemName":self.itemsNameLabel.text!,"itemSeller":self.itemsSellerLabel.text!])
                    
                    ProcessNetworkMsg(relatedController: self.relatedController, request: "deleteItemInShoppingCart", params: deleteItemsParams, msg: "").processSocket()
                    
                    
                    
                    },cancelHandler: nil)
                
                
                
            }else{

                let getItemsParams = JSON(["userID":relatedController.userID,"itemName":itemsNameLabel.text!,"itemSeller":itemsSellerLabel.text!,"edittedNum":itemNumber])
                
                ProcessNetworkMsg(relatedController: relatedController, request: "editShoppingCartItemsNumber", params: getItemsParams, msg: "").processSocket()
            }

        }
        addNumBtn.hidden = true
        subtractNumBtn.hidden = true
        itemsNumTF.hidden = true
        submitEditionBtn.hidden = true
        
        itemsNameLabel.hidden = false
        itemsSellerLabel.hidden = false
        itemsPrice.hidden = false
        
        self.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
    }
    
    var itemOriginalNumber = Int()
    
    var itemNumber = Int()
    
    var itemsNumberStr = String()
    
    var itemsEachPriceStr = String()
    
    var relatedController = ShoppingCartTableViewController()
    
    
    func configureShoppingCartInfo(item:Item,itemNumber:Int,relatedController:ShoppingCartTableViewController){
        
        itemsNameLabel.text = item.itemName
        itemsSellerLabel.text = item.itemSeller
        
        itemsEachPriceStr = String(item.itemEachPrice)
        
        self.itemOriginalNumber = itemNumber
        self.itemNumber = itemNumber
        itemsNumberStr = String(itemNumber)
        
        itemsPrice.text = "$" + itemsEachPriceStr + " × " + itemsNumberStr
        
        itemsThumbnailImg.image = UIImage(data: NSData(bytes: item.thumbnailUInt8Array, length: item.thumbnailUInt8Array.count))
        
        addNumBtn.layer.cornerRadius = 8
        subtractNumBtn.layer.cornerRadius = 8
        submitEditionBtn.layer.cornerRadius = 8
        
        addNumBtn.hidden = true
        subtractNumBtn.hidden = true
        itemsNumTF.hidden = true
        submitEditionBtn.hidden = true
        
        self.relatedController = relatedController
        
    }


}
