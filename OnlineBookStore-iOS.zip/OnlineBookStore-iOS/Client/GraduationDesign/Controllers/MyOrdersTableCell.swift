//
//  MyOrdersTableCell.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/20.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class TitleCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    func configureTitleInfo(title:String){
        titleLabel.text = title
    }

}

class MyOrdersDetailsCell: UITableViewCell {
    
    var relatedController = UIViewController()
    var orderID = String()
    
    @IBOutlet weak var orderIDLabel: UILabel!
    
    @IBOutlet weak var itemsDetailsTV: UITextView!
    
    @IBOutlet weak var orderStatusLabel: myUILabel!

    @IBOutlet weak var sumPriceLabel: UILabel!
    
    @IBOutlet weak var informBtn: UIButton!
    
    @IBAction func informAction(sender: UIButton) {
        
        if informBtn.titleLabel?.text == "OK" {
            
            let alertController = UIAlertController(title: "Deliver", message: "please input the express code", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addTextFieldWithConfigurationHandler {
                (textField: UITextField!) -> Void in
                
            }
            let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler:{
                action in
                let expressIDTF = alertController.textFields!.first! as UITextField
                let expressID = expressIDTF.text!
                
                let submitExpressIDParams = JSON(["orderID":self.orderID,"expressID":expressID] )
                
                ProcessNetworkMsg(relatedController: self.relatedController, request: "hasSentItems", params: submitExpressIDParams, msg: "").processSocket()
                
            } )
            alertController.addAction(OKAction)
            relatedController.presentViewController(alertController, animated: true, completion: nil)
            
            
        } else if informBtn.titleLabel?.text == "confirm"{
            
            showAlertDialog(relatedController, title: "Message", message: "Do you confirm that you have got what you need?", OKHandler: { (action) -> Void in
                
                let hasReceivedParams = JSON(["orderID":self.orderID] )
                
                ProcessNetworkMsg(relatedController: self.relatedController, request: "hasReceived", params: hasReceivedParams, msg: "").processSocket()
               
                
                }, cancelHandler: nil)
            
        }
        
        
    }
    
    
    @IBOutlet weak var deleteOrderBtn: UIButton!
    
    @IBAction func deleteOrderAction(sender: UIButton) {
        
        
        showAlertDialog(relatedController, title: "Alert", message: "Are you sure to delete it?", OKHandler: { (action) -> Void in
            
            let deleteOrderParams = JSON(["orderID":self.orderID] )
            
            ProcessNetworkMsg(relatedController: self.relatedController, request: "deleteOrder", params: deleteOrderParams, msg: "").processSocket()
            
            
            }, cancelHandler: nil)
        
    }
    
    
    func configureOrdersDetails(order:Order,relatedController:UIViewController){
        self.orderID = order.id
        orderIDLabel.text = "orderID:" + self.orderID

        itemsDetailsTV.text = "Items:\n\n" + order.itemsInfo
        
        if order.orderType == "buyer"{
            informBtn.setTitle("confirm", forState: UIControlState.Normal)
        }else if order.orderType == "seller"{
            informBtn.setTitle("confirm", forState: UIControlState.Normal)
        }
        
        if order.hasSent == "N" {
            orderStatusLabel.text = "status:waiting for delivering"
            
            if order.orderType == "buyer"{
                informBtn.enabled = false
                informBtn.setTitleColor(UIColor.grayColor(), forState: UIControlState.Normal)
            }

        }else{
            if order.hasBeenReceived == "N"{
               orderStatusLabel.text = "status:delivered,express code:"+order.expressID
                if order.orderType == "buyer"{
                    informBtn.enabled = true
                }else if order.orderType == "seller"{
                    informBtn.enabled = false
                    informBtn.setTitleColor(UIColor.grayColor(), forState: UIControlState.Normal)
                }
            }else {
                orderStatusLabel.text = "status:confirmed"
                informBtn.enabled = false
                informBtn.setTitleColor(UIColor.grayColor(), forState: UIControlState.Normal)
            }
        }
        sumPriceLabel.text = "sum:$" + String(order.sumPrice)
        
        self.relatedController = relatedController
        orderStatusLabel.lineBreakMode = NSLineBreakMode.ByWordWrapping
        orderStatusLabel.numberOfLines = 0
        orderStatusLabel.verticalAlignment = VerticalAlignmentTop
    }
    
}