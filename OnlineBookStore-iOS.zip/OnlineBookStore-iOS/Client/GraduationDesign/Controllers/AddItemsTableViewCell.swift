//
//  AddItemsTableViewCell.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/16.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class AddItemsThumbnailCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var itemsThumbnailImg: UIImageView!
    
    func configureThumbnailInfo(thumbnailImage:UIImage){
        
        titleLabel.text = "Photo:"
        itemsThumbnailImg.image = thumbnailImage
    }
    

}

class AddItemsShortInfoCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var valueTF: UITextField!
    
    func configureShortInfo(title:String,placeholder:String){
        
        titleLabel.text = title
        valueTF.placeholder = placeholder
        
        if placeholder == "Price"{
            valueTF.keyboardType = UIKeyboardType.DecimalPad
        }else if placeholder == "Stock"{
            valueTF.keyboardType = UIKeyboardType.NumberPad
        }
        
    }
    
    
}

class AddItemsIntroCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var valueTV: UITextView!
    
    func configureIntro(){
        titleLabel.text = "Introduction:"
        valueTV.layer.borderWidth = 1
        valueTV.layer.cornerRadius = 8
        valueTV.tag = 1
    }
    
    
}