//
//  OrderTableCell.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/19.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class OrderTitleCell: UITableViewCell {
    
    @IBOutlet weak var orderTitleLabel: UILabel!
    
    func configureTitle(title:String){
        orderTitleLabel.text = title
    }
    
}


class OrderAddressCell: UITableViewCell {

    @IBOutlet weak var receiverLabel: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!

    @IBOutlet weak var addressLabel: myUILabel!
    
    func configureAddressInfo(receiver:String,phone:String,address:String){
        addressLabel.lineBreakMode = NSLineBreakMode.ByWordWrapping
        addressLabel.numberOfLines = 0
        addressLabel.verticalAlignment = VerticalAlignmentTop
        
        receiverLabel.text = "Receiver:" + receiver
        phoneLabel.text = phone
        addressLabel.text = "Address:\n" + address
        
    }
    
}

class OrderItemsCell: UITableViewCell {
    
    @IBOutlet weak var itemThumbnailImg: UIImageView!
    
    @IBOutlet weak var itemNameLabel: UILabel!
    
    @IBOutlet weak var itemSellerLabel: UILabel!
    
    @IBOutlet weak var itemPriceLabel: UILabel!
    
    var itemIdInDB = Int()
    
    var relatedController = UIViewController()
    
    func configueItemInfo(item: Item,relatedController:UIViewController){
        itemNameLabel.text = item.itemName
        itemSellerLabel.text = item.itemSeller
        let priceDoubleToString = NSString(format: "%.2f" , item.itemEachPrice) as String
        itemPriceLabel.text = "$" + priceDoubleToString
        
        itemThumbnailImg.image = UIImage(data: NSData(bytes: item.thumbnailUInt8Array, length: item.thumbnailUInt8Array.count))
        
        self.itemIdInDB = item.itemIdInDB
        self.relatedController = relatedController
    }
    
}