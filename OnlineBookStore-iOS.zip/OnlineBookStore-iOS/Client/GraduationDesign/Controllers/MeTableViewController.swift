//
//  MeViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/9.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

var relatedMeController = MeViewController()

var meControllerHasBeenInitialized = false

class MeViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var userInfoTable: UITableView!

    var username = String()
    var password = String()
    var email = String()
    var phone = String()
    var status = String()
    var balance = Double()
    var loginType = String()
    var thumbnailArray = [UInt8]()
    
    var actionLabelArray = [String]()
    
    var userID = Int()
    
    var header = MJRefreshNormalHeader()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        let defaults = NSUserDefaults.standardUserDefaults()
        userID = defaults.objectForKey("userID") as! Int
        
        let getItemsParams = JSON(["userID":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "getUserInfo", params: getItemsParams, msg: "").processSocket()
        
        loginType = defaults.objectForKey("loginType") as! String
        status = defaults.objectForKey("status") as! String
        
        switch status{
            
        case "seller":
            actionLabelArray = ["my orders","my stocks","feedback","update"]
            break
            
        case "buyer":
            actionLabelArray = ["my orders","feedback","update"]
            break
            
        default:
            break
        }
        
        header.setRefreshingTarget(self, refreshingAction: Selector("headerRefresh"))
        self.userInfoTable.mj_header = header

        self.userInfoTable.tableFooterView = UIView()
        
        relatedMeController = self
        meControllerHasBeenInitialized = true
        
        // Do any additional setup after loading the view.
    }
    

    func headerRefresh(){
        
        var refreshUserInfoParams:JSON
        
        switch loginType{
            
            case "username":
                
            refreshUserInfoParams = JSON(["username":username,"loginType":loginType])
            
            break
            
            case "email":
                
            refreshUserInfoParams = JSON(["email":email,"loginType":loginType])
            
            break
            
            
        default://phone
            
            refreshUserInfoParams = JSON(["phone":phone,"loginType":loginType])
            
            break
        }
        
        ProcessNetworkMsg(relatedController: self, request: "refreshUserInfo", params:refreshUserInfoParams, msg: "").processSocket()

        self.userInfoTable.mj_header.endRefreshing()
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        switch segue.identifier!{
            
        case "editUserInfo":
            
            let controller = segue.destinationViewController as! MeDetailsTableViewController
            
            controller.username = self.username
            controller.password = self.password
            controller.email = self.email
            controller.phone = self.phone
            controller.thumbnailArray = self.thumbnailArray
            controller.userID = self.userID
            controller.downLayerMeViewController = self
   
            break
            
        case "topUp":
            
            let controller = segue.destinationViewController as! MeTopUpViewController
            
            controller.username = self.username
            controller.balance = self.balance
            controller.userID = self.userID
            controller.downLayerController = self
            
            break
            
        case "viewMyItems":
            
             let controller = segue.destinationViewController as! MyItemsTableViewController
             
             controller.username = self.username
            
            break
            
        case "viewMyOrders":
            
            let controller = segue.destinationViewController as! MyOrdersTableViewController
            
            controller.username = self.username
            controller.status = self.status
            
            break
            
        default:
            
            break
            
        }

    }
    
    func refreshUserInfo(){
        
        var refreshUserInfoParams:JSON
        
        switch loginType{
            
        case "username":
            
            refreshUserInfoParams = JSON(["username":username,"loginType":loginType])
            
            break
            
        case "email":
            
            refreshUserInfoParams = JSON(["email":email,"loginType":loginType])
            
            break
            
            
        default://phone
            
            refreshUserInfoParams = JSON(["phone":phone,"loginType":loginType])
            
            break
        }
        
        ProcessNetworkMsg(relatedController: self, request: "refreshUserInfo", params:refreshUserInfoParams, msg: "").processSocket()
    }

    

    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (actionLabelArray.count + 3)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == 0{
            return 100
        }else{
            return 50
        }
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.row{
            
        case 0:
            let userProfileCell = tableView.dequeueReusableCellWithIdentifier("userProfileTableCell", forIndexPath: indexPath) as! UserProfileTableViewCell
            userProfileCell.configueUserProfileInfo(self.username, email: self.email, phone: self.phone,thumbnailUInt8Array: self.thumbnailArray)
            
            return userProfileCell
        case 1:
            let balanceTableCell = tableView.dequeueReusableCellWithIdentifier("balanceTableCell", forIndexPath: indexPath) as! BalanceTableViewCell
            balanceTableCell.configueBalanceInfo(balance)
            
            return balanceTableCell
            
        case 2...(2 + actionLabelArray.count - 1):
            let actionTableCell = tableView.dequeueReusableCellWithIdentifier("actionTableCell", forIndexPath: indexPath) as! ActionTableViewCell
            actionTableCell.configureActionInfo(actionLabelArray[indexPath.row - 2])
            
            return actionTableCell
            
        default:
            let exitBtnTableCell = tableView.dequeueReusableCellWithIdentifier("exitBtnTableCell", forIndexPath: indexPath) as! ExitBtnTableViewCell
            exitBtnTableCell.configureExitBtnInfo("退出登录", relatedController: self)
            
            return exitBtnTableCell
            
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        if actionLabelArray.count == 4{
            
            switch indexPath.row{
                
            case 0:
                self.performSegueWithIdentifier("editUserInfo", sender: nil)
                break
            
            case 1:
                self.performSegueWithIdentifier("topUp", sender: nil)
                break
                
            case 2:
                self.performSegueWithIdentifier("viewMyOrders", sender: nil)
                break
                
            case 3:
                self.performSegueWithIdentifier("viewMyItems", sender: nil)
                break
                
            case 4:
                self.performSegueWithIdentifier("giveSuggestions", sender: nil)
                break
                
            default:

                break
                
            }
            
            
        }else if actionLabelArray.count == 3{
            
            switch indexPath.row{
                
            case 0:
                self.performSegueWithIdentifier("editUserInfo", sender: nil)
                break
                
            case 1:
                self.performSegueWithIdentifier("topUp", sender: nil)
                break
                
            case 2:
                self.performSegueWithIdentifier("viewMyOrders", sender: nil)
                break
                
            case 3:
                self.performSegueWithIdentifier("giveSuggestions", sender: nil)
                break
                
            default:
                
                break
                
            }
            
        }else{
            showAlertDialog(self, title: "Alert", message: "A bug!", OKHandler: nil)
        }
        
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
