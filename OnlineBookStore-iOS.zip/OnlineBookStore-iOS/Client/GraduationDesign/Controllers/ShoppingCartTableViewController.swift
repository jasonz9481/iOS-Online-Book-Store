//
//  ShoppingCartViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/9.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

var shoppingCartTableViewControllerHasBeenInitialized = false

var thisShoppingCartTableViewController = ShoppingCartTableViewController()

class ShoppingCartTableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchResultsUpdating {
    
    @IBOutlet weak var shoppingCartTable: UITableView!
    
    @IBOutlet weak var sumPriceLabel: UILabel!
    
    @IBOutlet weak var payForItBtn: UIButton!
    
    @IBAction func payForItAction(sender: UIButton) {
        
        self.performSegueWithIdentifier("payForIt", sender: nil)
    }
    
    
    
    var itemsInShoppingCart:[Item] = []
    var itemsNumberInShoppingCart:[Int] = []
    
    var userID = Int()
    
    var sumPrice = 0.0
    
    var header = MJRefreshNormalHeader()
    
    var itemSearchController = UISearchController()
    var searchItemsArray:[Item] = [Item](){
        didSet  {self.shoppingCartTable.reloadData()}
    }
    var searchItemsNumArray:[Int] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()

        shoppingCartTableViewControllerHasBeenInitialized = true
        thisShoppingCartTableViewController = self
        
        let defaults = NSUserDefaults.standardUserDefaults()
        userID = defaults.objectForKey("userID") as! Int
        
        let getItemsParams = JSON(["userID":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "getShoppingCart", params: getItemsParams, msg: "").processSocket()
        
        header.setRefreshingTarget(self, refreshingAction: Selector("headerRefresh"))
        self.shoppingCartTable.mj_header = header
        
        
        self.shoppingCartTable.tableFooterView = UIView()
        
        self.itemSearchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.hidesNavigationBarDuringPresentation = false
            controller.dimsBackgroundDuringPresentation = false
            controller.searchBar.searchBarStyle = .Minimal
            controller.searchBar.sizeToFit()
            self.shoppingCartTable.tableHeaderView = controller.searchBar
            
            return controller
        })()
        
        var sumPriceStr:String = "Sum: $"
        sumPriceStr += String(sumPrice)
        
        sumPriceLabel.text = sumPriceStr

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func headerRefresh(){
        
        itemsInShoppingCart = []
        itemsNumberInShoppingCart = []
        
        sumPrice = 0.0
        var sumPriceStr:String = "Sum: $"
        sumPriceStr += String(sumPrice)
        sumPriceLabel.text = sumPriceStr

        let getItemsParams = JSON(["userID":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "getShoppingCart", params: getItemsParams, msg: "").processSocket()

        self.shoppingCartTable.mj_header.endRefreshing()
    }
    
    func autoRefreshShoppingCart(){
        
        itemsInShoppingCart = []
        itemsNumberInShoppingCart = []
        sumPrice = 0.0
        
        var sumPriceStr:String = "Sum: $"
        sumPriceStr += String(sumPrice)
        
        sumPriceLabel.text = sumPriceStr
        
        let getItemsParams = JSON(["userID":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "getShoppingCart", params: getItemsParams, msg: "notShowNoneDialog").processSocket()
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "viewDetails"{
            let controller = segue.destinationViewController as! ShoppingCartDetailsViewController
            let selectedItemsIdInDB = sender as! Int
            
            for item in itemsInShoppingCart{
                
                if item.itemIdInDB == selectedItemsIdInDB{
                    controller.itemThumbnailUInt8Array = item.thumbnailUInt8Array
                    controller.itemName = item.itemName
                    controller.itemPrice = item.itemEachPrice
                    controller.itemSeller = item.itemSeller
                    controller.itemIntro = item.itemIntroduction
                    controller.itemIdInDB = item.itemIdInDB
                    controller.userID = userID
                }
            }
        }else{
            let controller = segue.destinationViewController as! OrderTableViewController
            
            controller.itemsInOrder = itemsInShoppingCart
            controller.itemsNumberInOrder = itemsNumberInShoppingCart
            controller.userID = userID
            controller.sumPrice = sumPrice
            controller.downLayerController = self
            
        }
    }
    

    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if (self.itemSearchController.active){
            return self.searchItemsArray.count
        } else{
            return self.itemsInShoppingCart.count
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let itemCell = tableView.dequeueReusableCellWithIdentifier("shoppingCartCell", forIndexPath: indexPath) as! ShoppingCartTableViewCell
        
        if (self.itemSearchController.active){
            itemCell.configureShoppingCartInfo(self.searchItemsArray[indexPath.row],itemNumber: self.searchItemsNumArray[indexPath.row],relatedController: self)
            return itemCell
        }else{
            itemCell.configureShoppingCartInfo(itemsInShoppingCart[indexPath.row],itemNumber: itemsNumberInShoppingCart[indexPath.row],relatedController: self)
            return itemCell
        }
        
        
    }
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .Normal, title: "Delete") { action, index in
            
            showAlertDialog(self, title: "Alert", message: "Are you sure to delete this item?", OKHandler: { (action) -> Void in
                
                let deleteItemsParams = JSON(["userID":self.userID,"itemName":self.itemsInShoppingCart[indexPath.row].itemName,"itemSeller":self.itemsInShoppingCart[indexPath.row].itemSeller])
                
                ProcessNetworkMsg(relatedController: self, request: "deleteItemInShoppingCart", params: deleteItemsParams, msg: "").processSocket()
                
                

            },cancelHandler: nil)
            

        }
        delete.backgroundColor = UIColor.redColor()

        let edit = UITableViewRowAction(style: .Normal, title: "Edit") { action, index in
            
            let selectedCell = tableView.cellForRowAtIndexPath(indexPath) as! ShoppingCartTableViewCell
            selectedCell.accessoryType = UITableViewCellAccessoryType.None
            
            selectedCell.itemsNameLabel.hidden = true
            selectedCell.itemsSellerLabel.hidden = true
            selectedCell.itemsPrice.hidden = true
            
            selectedCell.addNumBtn.hidden = false
            selectedCell.subtractNumBtn.hidden = false
            selectedCell.itemsNumTF.hidden = false
            selectedCell.submitEditionBtn.hidden = false
            
            selectedCell.itemsNumTF.text = selectedCell.itemsNumberStr
            
            tableView.setEditing(false, animated: true)

        }
        edit.backgroundColor = UIColor.blueColor()
        
        return [delete, edit]
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {

        return true
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {

    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let selectedItemIdInDB = itemsInShoppingCart[indexPath.row].itemIdInDB
        
        self.performSegueWithIdentifier("viewDetails", sender: selectedItemIdInDB)
    }
    
    
    
    
    
    func updateSearchResultsForSearchController(searchController: UISearchController){
        
        self.searchItemsArray.removeAll(keepCapacity: false)
        self.searchItemsNumArray.removeAll(keepCapacity: false)
        
        let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@",searchController.searchBar.text!)
        
        var itemsName = [String]()
        
        for eachItem in itemsInShoppingCart{
            itemsName.append(eachItem.itemName)
        }
        
        let array = (itemsName as NSArray).filteredArrayUsingPredicate(searchPredicate)
   
        for var i = 0; i < array.count; i++ {
            for var j = 0; j < itemsInShoppingCart.count; j++ {
                
                if itemsInShoppingCart[j].itemName == (array as! [String])[i]{
                    searchItemsArray.append(itemsInShoppingCart[j])
                    searchItemsNumArray.append(itemsNumberInShoppingCart[j])
                }
                
            }
            
        }

    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
