//
//  AddItemsTableViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/16.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class AddItemsTableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate,UITextViewDelegate {

    @IBOutlet weak var addItemsInfoTable: UITableView!
    
    var itemThumbnail = UIImage()
    
    var username = String()
    
    var itemName = String()
    
    var itemAuthor = String()
    
    var itemPrice = Double()
    
    var itemNumberInCache = Int()
    
    var itemIntro = String()
    
    var downLayerController = MyItemsTableViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addItemsInfoTable.separatorStyle = UITableViewCellSeparatorStyle.None
        
        let barButtonItem = UIBarButtonItem(title: "OK", style: UIBarButtonItemStyle.Plain, target: self, action: "addItems")
        self.navigationItem.rightBarButtonItem = barButtonItem
        self.navigationItem.rightBarButtonItem?.enabled = false

    }
    
    func addItems(){
        
        let addItemsParams = JSON(["itemName":itemName,"itemSeller":username,"itemAuthor":itemAuthor,"itemPrice":itemPrice,"itemNumberInCache":itemNumberInCache,"itemIntro":itemIntro])
        
        ProcessNetworkMsg(relatedController: self, request: "addItems", params: addItemsParams, msg: "").processSocket()

        
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 6
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == 5{
            return 150
        }else{
            return 60
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        if indexPath.row == 0{
            
            let picker = UIImagePickerController()
            picker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
            picker.allowsEditing = true
            picker.delegate = self
            self.presentViewController(picker, animated: true, completion: nil)
        }
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.row{
            
        case 0:
            
            let itemsThumbnailCell = tableView.dequeueReusableCellWithIdentifier("itemsThumbnailCell", forIndexPath: indexPath) as! AddItemsThumbnailCell
            itemsThumbnailCell.configureThumbnailInfo(itemThumbnail)
            
            return itemsThumbnailCell
       
        case 1:
            let itemNameCell = tableView.dequeueReusableCellWithIdentifier("itemShortInfoCell", forIndexPath: indexPath) as! AddItemsShortInfoCell
            itemNameCell.configureShortInfo("Name:",placeholder: "Item Name")
            itemNameCell.valueTF.delegate = self
            
            return itemNameCell
            
        case 2:
            let itemSellerCell = tableView.dequeueReusableCellWithIdentifier("itemShortInfoCell", forIndexPath: indexPath) as! AddItemsShortInfoCell
            itemSellerCell.configureShortInfo("Author:",placeholder: "Author")
            itemSellerCell.valueTF.delegate = self
            
            return itemSellerCell
            
        case 3:
            let itemPriceCell = tableView.dequeueReusableCellWithIdentifier("itemShortInfoCell", forIndexPath: indexPath) as! AddItemsShortInfoCell
            itemPriceCell.configureShortInfo("Price:",placeholder: "Price(please input a number)")
            itemPriceCell.valueTF.delegate = self
            
            return itemPriceCell
            
        case 4:
            let itemNumberInCacheCell = tableView.dequeueReusableCellWithIdentifier("itemShortInfoCell", forIndexPath: indexPath) as! AddItemsShortInfoCell
            itemNumberInCacheCell.configureShortInfo("stock",placeholder: "Stock(please input a number)")
            itemNumberInCacheCell.valueTF.delegate = self
            
            return itemNumberInCacheCell
            
            
        default:
            let itemIntroCell = tableView.dequeueReusableCellWithIdentifier("itemsIntroCell", forIndexPath: indexPath) as! AddItemsIntroCell
            itemIntroCell.configureIntro()
            itemIntroCell.valueTV.delegate = self
            
            return itemIntroCell
            
        }
    }

    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
        self.itemThumbnail = image
        self.addItemsInfoTable.reloadData()
        self.dismissViewControllerAnimated(true, completion: nil)

        self.navigationItem.rightBarButtonItem?.enabled = true
        
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        
        switch textField.placeholder!{
            
        case "Item Name":
            self.navigationItem.rightBarButtonItem?.enabled = true
            
            if textField.text == nil{
                self.itemName = ""
            }else{
               self.itemName = textField.text!
            }
            
            break
            
        case "Author":
            self.navigationItem.rightBarButtonItem?.enabled = true
            
            if textField.text == nil{
                self.itemAuthor = ""
            }else{
                self.itemAuthor = textField.text!
            }
            break
            
        case "Price(please input a number)":
            self.navigationItem.rightBarButtonItem?.enabled = true
            
            if textField.text == nil{
                self.itemPrice = 0.0
            }else{
                self.itemPrice = (textField.text! as NSString).doubleValue
            }
            break
            
        default:
            self.navigationItem.rightBarButtonItem?.enabled = true
            
            if textField.text == nil{
                self.itemNumberInCache = 0
            }else{
                self.itemNumberInCache = (textField.text! as NSString).integerValue
            }
            break
            
        }
        
    }
    
    func textViewDidChange(textView: UITextView) {
        if textView.tag == 1{
            self.navigationItem.rightBarButtonItem?.enabled = true
            if textView.text == nil{
                self.itemIntro = ""
            }else{
                self.itemIntro = textView.text!
            }
        }
    }

    
}
