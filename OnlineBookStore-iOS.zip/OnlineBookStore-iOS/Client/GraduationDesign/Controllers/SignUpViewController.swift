//
//  SignUpViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/10.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController {
    
    @IBOutlet var backgroundView: UIView!
    
    @IBOutlet weak var usernameTF: UITextField!
    
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var emailTF: UITextField!
    
    @IBOutlet weak var phoneTF: UITextField!
    
    @IBOutlet weak var signUpBtn: UIButton!
    
    @IBOutlet weak var isSellerSwitch: UISwitch!
    
    @IBAction func signUpBtnAction(sender: UIButton) {
        
        let username = usernameTF.text
        let password = passwordTF.text
        let email = emailTF.text
        let phone = phoneTF.text
        
        if (username == nil) || (password == nil) || (email == nil) || (phone == nil){
            
            showAlertDialog("There is a problem in the widget,please check!")
            
        }else{
            
            switch verifyInputInfo(username!, password: password!, email: email!,phone: phone!) {
                
                case "usernameHasNotInput":
                    showAlertDialog("please input your username!")
                    break
                case "passwordHasNotInput":
                    showAlertDialog("please input your password!")
                    break
                case "emailHasNotInput":
                    showAlertDialog("please input your email!")
                    break
                case "invalidEmail":
                    showAlertDialog("Sorry,your email is invalid,please input it again!")
                    break
                case "phoneHasNotInput":
                    showAlertDialog("please input your phone!")
                    break
                default:

                    var params = NSDictionary()
                    if isSellerSwitch.on {
                        params = ["username":username!,"password":password!,"email":email!,
                            "phone":phone!,"status":"seller"]
                    }else{
                        params = ["username":username!,"password":password!,"email":email!,
                            "phone":phone!,"status":"buyer"]
                    }
                    
                    let paramsJSON = JSON(params)
                    
                    let modifiedParamsJSON = JSON(paramsJSON.rawString()!.deleteStr("\n"))

                    let processNetworkMsg = ProcessNetworkMsg(relatedController: self,request: "signUp",params: modifiedParamsJSON,msg: "")
                    
                    processNetworkMsg.processSocket()
                
            }
            
        }
        
        
        
    }
    
    func showAlertDialog(message:String){
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil)
        let CancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel, handler: nil)
        alertController.addAction(OKAction)
        alertController.addAction(CancelAction)
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    
    
    @IBOutlet weak var cancelBtn: UIButton!
    
    @IBAction func cancelBtnAction(sender: UIButton) {
        let returnToLoginStoryBoard = UIStoryboard(name: "Login", bundle: nil).instantiateViewControllerWithIdentifier("Login")
        
        self.presentViewController(returnToLoginStoryBoard, animated: true, completion: nil)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        backgroundView.backgroundColor = UIColor(patternImage: UIImage(named:"background.jpg")!)
        passwordTF.secureTextEntry = true
        signUpBtn.layer.cornerRadius = 8
        cancelBtn.layer.cornerRadius = 8
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
