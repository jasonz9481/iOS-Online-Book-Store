//
//  ItemsTableViewCellController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/3/24.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class ItemsTableViewCell: UITableViewCell {
    
    
    var itemIdInDB = Int()
    
    var relatedController = UIViewController()

    @IBOutlet weak var itemThumbnailImg: UIImageView!
    
    @IBOutlet weak var itemNameLabel: UILabel!
    
    @IBOutlet weak var itemSellerLabel: UILabel!

    @IBOutlet weak var itemPriceLabel: UILabel!    
    
    func configueItemInfo(item: Item,relatedController:UIViewController){
        itemNameLabel.text = item.itemName
        itemSellerLabel.text = item.itemSeller
        let priceDoubleToString = NSString(format: "%.2f" , item.itemEachPrice) as String
        itemPriceLabel.text = "$" + priceDoubleToString
        
        itemThumbnailImg.image = UIImage(data: NSData(bytes: item.thumbnailUInt8Array, length: item.thumbnailUInt8Array.count))
        
        self.itemIdInDB = item.itemIdInDB
        self.relatedController = relatedController
    }
    
    
}
