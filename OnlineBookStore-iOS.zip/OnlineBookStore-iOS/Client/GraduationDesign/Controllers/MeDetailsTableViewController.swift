//
//  MeDetailsTableViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/11.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class MeDetailsTableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var meDetailsInfoTable: UITableView!
    
    var username = String()
    var password = String()
    var email = String()
    var phone = String()
    var thumbnailArray = [UInt8]()
    var thumbnailType:String = "UInt8Array"
    var thumbnailImage = UIImage()
    var userID = Int()
    
    var edittedUsername = String()
    var edittedPassword = String()
    var edittedEmail = String()
    var edittedPhone = String()
    
    var thumbnailHasBeenEditted = false
    var usernameHasBeenEditted = false
    var passwordHasBeenEditted = false
    var emailHasBeenEditted = false
    var phoneHasBeenEditted = false
    
    var downLayerMeViewController = MeViewController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let barButtonItem = UIBarButtonItem(title: "Save", style: UIBarButtonItemStyle.Plain, target: self, action: "saveEdition")
        
        self.navigationItem.rightBarButtonItem = barButtonItem
        self.navigationItem.rightBarButtonItem?.enabled = false
        
        meDetailsInfoTable.tableFooterView = UIView()
        meDetailsInfoTable.scrollEnabled = false
        
        edittedUsername = username
        edittedPassword = password
        edittedEmail = email
        edittedPhone = phone
        
    }
    
    func saveEdition(){
        
        switch verifyInputInfo(edittedUsername, password: edittedPassword, email: edittedEmail,phone: edittedPhone) {
            
        case "usernameHasNotInput":
            showAlertDialog(self,title: "Alert",message: "please input your username!",OKHandler: nil)
            break
        case "passwordHasNotInput":
            showAlertDialog(self,title: "Alert",message: "please input your password!",OKHandler: nil)
            break
        case "emailHasNotInput":
            showAlertDialog(self,title: "Alert",message: "please input your email!",OKHandler: nil)
            break
        case "invalidEmail":
            showAlertDialog(self,title: "Alert",message: "sorry,your email is invalid,please input it again!",OKHandler: nil)
            break
        case "phoneHasNotInput":
            showAlertDialog(self,title: "Alert",message: "please inpout your phone number!",OKHandler: nil)
            break
        default:
            
            if thumbnailHasBeenEditted {
                
                let imageData = UIImagePNGRepresentation(self.thumbnailImage)
                let count = imageData!.length / sizeof(UInt8)
                
                // create an array of Uint8
                var array = [UInt8](count: count, repeatedValue: 0)
                
                // copy bytes into array
                imageData!.getBytes(&array, length: count)
                
                let editUserInfoParams = JSON(["userID":userID,"key":"thumbnail","originalLength":count])
                
                ProcessNetworkMsg(relatedController: self, request: "editUserInfo", params: editUserInfoParams, msg: "",thumbnailArrayToSend: array).processSocket()
                
                
            }
            
            if usernameHasBeenEditted {
                
                let editUserInfoParams = JSON(["userID":userID,"key":"username","value":edittedUsername])
                
                ProcessNetworkMsg(relatedController: self, request: "editUserInfo", params: editUserInfoParams, msg: "").processSocket()
            }
            
            if passwordHasBeenEditted {
                
                let editUserInfoParams = JSON(["userID":userID,"key":"password","value":edittedPassword])
                
                ProcessNetworkMsg(relatedController: self, request: "editUserInfo", params: editUserInfoParams, msg: "").processSocket()
            }
            
            if emailHasBeenEditted {
                
                let editUserInfoParams = JSON(["userID":userID,"key":"email","value":edittedEmail])
                
                ProcessNetworkMsg(relatedController: self, request: "editUserInfo", params: editUserInfoParams, msg: "").processSocket()
            }
            
            if phoneHasBeenEditted {
                
                let editUserInfoParams = JSON(["userID":userID,"key":"phone","value":edittedPhone])
                
                ProcessNetworkMsg(relatedController: self, request: "editUserInfo", params: editUserInfoParams, msg: "").processSocket()
            }
            
            
            break
        }
        
        
        
        
        
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        let rowNum = sender as! Int
        
        let controller = segue.destinationViewController as! MeDetailsEdtionView
        
        controller.downLayerController = self
        
        switch rowNum{
            
        case 1:
            
            controller.titleStr = "username:"
            controller.placeholder = "please input your username here"
            controller.valueStr = edittedUsername
            
            break
            
        case 2:
            
            controller.titleStr = "password:"
            controller.placeholder = "please input your password here"
            controller.valueStr = edittedPassword
            
            break
         
        case 3:
            
            controller.titleStr = "email:"
            controller.placeholder = "please input your email here"
            controller.valueStr = edittedEmail
            
            break
            
        default:
            
            controller.titleStr = "phone:"
            controller.placeholder = "please input your phone number here"
            controller.valueStr = edittedPhone
            
            break
            
        }
        
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 5
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == 0{
            return 100
        }else{
            return 50
        }
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.row{
            
        case 0:
            let userThumbnailCell = tableView.dequeueReusableCellWithIdentifier("meDetailsThumbnailCell", forIndexPath: indexPath) as! MeDetailsThumbnailTableViewCell
            if thumbnailType == "UInt8Array"{
                userThumbnailCell.configureThumbnailThroughUInt8Array(thumbnailArray)
            }else{
                userThumbnailCell.configureThumbnailThroughUIImage(thumbnailImage)
            }
            
            return userThumbnailCell
        case 1:
            let usernameCell = tableView.dequeueReusableCellWithIdentifier("meDetailsOthersCell", forIndexPath: indexPath) as! MeDetailsOthersTableViewCell
            usernameCell.configureOthers("username", value: edittedUsername)
            
            return usernameCell
            
        case 2:
            let passwordCell = tableView.dequeueReusableCellWithIdentifier("meDetailsPwdCell", forIndexPath: indexPath) as! MeDetailsPwdTableViewCell
            passwordCell.configurePwdInfo(edittedPassword)
            
            return passwordCell
            
        case 3:
            let emailCell = tableView.dequeueReusableCellWithIdentifier("meDetailsOthersCell", forIndexPath: indexPath) as! MeDetailsOthersTableViewCell
            emailCell.configureOthers("email", value: edittedEmail)
            
            return emailCell
         
        default:
            let phoneCell = tableView.dequeueReusableCellWithIdentifier("meDetailsOthersCell", forIndexPath: indexPath) as! MeDetailsOthersTableViewCell
            phoneCell.configureOthers("phone", value: edittedPhone)
            
            return phoneCell
            
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        switch indexPath.row{
            
        case 0:
            
            let picker = UIImagePickerController()
            picker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
            picker.allowsEditing = true
            picker.delegate = self
            self.presentViewController(picker, animated: true, completion: nil)

            break
            
        default:
            self.performSegueWithIdentifier("showEditingView", sender: indexPath.row)
        
            break
            
        }
        
        
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
        self.thumbnailImage = image
        self.thumbnailType = "UIImage"
        self.meDetailsInfoTable.reloadData()
        self.dismissViewControllerAnimated(true, completion: nil)
        
        let originalImage = UIImage(data: NSData(bytes: thumbnailArray, length: thumbnailArray.count))
        if image != originalImage {
            self.thumbnailHasBeenEditted = true
            self.navigationItem.rightBarButtonItem?.enabled = true
        }else{
            self.thumbnailHasBeenEditted = false
        }
        
    }
    
    
}
