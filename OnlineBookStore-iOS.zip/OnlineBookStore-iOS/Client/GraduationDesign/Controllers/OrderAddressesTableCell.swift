//
//  OrderAddressesTableCell.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/19.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class OrderAddressesTableCell: UITableViewCell {

    @IBOutlet weak var receiverLabel: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!
    
    @IBOutlet weak var addressLabel: myUILabel!
    
    
    func configureAddressInfo(receiver:String,phone:String,address:String){
        addressLabel.lineBreakMode = NSLineBreakMode.ByWordWrapping
        addressLabel.numberOfLines = 0
        addressLabel.verticalAlignment = VerticalAlignmentTop
        
        receiverLabel.text = "Receiver:" + receiver
        phoneLabel.text = phone
        addressLabel.text = "Address:\n" + address
        
    }
    
    
}
