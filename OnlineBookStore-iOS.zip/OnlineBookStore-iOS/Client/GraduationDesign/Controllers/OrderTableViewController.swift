//
//  OrderTableViewController.swift
//  GraduationDesign
//
//  Created by 郑翔军 on 16/4/19.
//  Copyright © 2016年 Jasonz. All rights reserved.
//

import UIKit

class OrderTableViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var orderInfoTable: UITableView!
    
    @IBOutlet weak var sumPriceLabel: UILabel!

    @IBOutlet weak var submitOrderBtn: UIButton!
    
    @IBAction func submitOrderAction(sender: UIButton) {
        
        if orderAddress.receiver != "" && orderAddress.phone != "" && orderAddress.passcode != ""
            && orderAddress.road != "" {
                
                let defaults = NSUserDefaults.standardUserDefaults()
                let balance = defaults.objectForKey("balance") as! Double
                
                if balance < sumPrice {
                    
                    showAlertDialog(self, title: "Alert", message: "your account is not affordable for this order,please top it up first!", OKHandler: nil)
                }else{
                    
                    var someItemNumberNotEnough = false
                    var notEnoughItemsName:[String] = []
                    
                    for var i = 0 ; i < itemsInOrder.count ; i++ {
                        
                        if itemsInOrder[i].itemNumbersInCache < itemsNumberInOrder[i] {
                            someItemNumberNotEnough = true
                            notEnoughItemsName.append(itemsInOrder[i].itemName)
                        }
                        
                    }
                    
                    if someItemNumberNotEnough {
                        
                        var notEnoughItemsNameStr:String = notEnoughItemsName[0]
                        
                        for var i = 1 ; i < notEnoughItemsName.count ; i++ {
                            
                            notEnoughItemsNameStr = notEnoughItemsNameStr + "," + notEnoughItemsName[i]
                        }
                        
                         showAlertDialog(self, title: "Alert", message: notEnoughItemsNameStr + "the number in stock is less than the number you need,please change the your number!", OKHandler: nil)
                        
                    }else {
                        
                        let addressToSend = orderAddress.road + "\n" + orderAddress.passcode + "\n" + orderAddress.receiver + "\n" + orderAddress.phone
                        
                        var sellerToSend:String = itemsInOrder[0].itemSeller
                        
                        for var i = 1 ; i < itemsInOrder.count ; i++ {
                            sellerToSend = sellerToSend +  "," + itemsInOrder[i].itemSeller
                            
                        }
                        
                        var itemsIDAndNumToSend:String = String(itemsInOrder[0].itemIdInDB) + "*" +  String(itemsNumberInOrder[0])
                        
                        for var i = 1 ; i < itemsInOrder.count ; i++ {
                            itemsIDAndNumToSend = itemsIDAndNumToSend +  "," + String(itemsInOrder[i].itemIdInDB) + "*" +  String(itemsNumberInOrder[i])
                        }
                        
                        var itemsIDAndNumInCacheToSend:String = String(itemsInOrder[0].itemIdInDB) + "*" +  String(itemsInOrder[0].itemNumbersInCache - itemsNumberInOrder[0])
                        
                        for var i = 1 ; i < itemsInOrder.count ; i++ {
                            itemsIDAndNumInCacheToSend = itemsIDAndNumInCacheToSend +  "," + String(itemsInOrder[i].itemIdInDB) + "*" +  String(itemsInOrder[i].itemNumbersInCache - itemsNumberInOrder[i])
                        }
                        
                        let submitOrderParams = JSON(["address":addressToSend,"buyerID":userID,"seller":sellerToSend,"itemIDAndNum":itemsIDAndNumToSend,"itemsIDAndNumInCache":itemsIDAndNumInCacheToSend,"sumPrice":sumPrice,"balance":balance-sumPrice])
                        
                        ProcessNetworkMsg(relatedController: self, request: "submitOrder", params: submitOrderParams, msg: "").processSocket()
                        
                    }
                    
                    
                    
                }
            
                
        }else{
            showAlertDialog(self, title: "Alert", message: "Please input your address", OKHandler: nil)
        }
        
    }
    
    var orderAddress:OrderAddress = OrderAddress(idInDB:0,receiver:"",phone: "",passcode:"",road: "",isDefault: "")
    
    var itemsInOrder:[Item] = []
    var itemsNumberInOrder:[Int] = []
    var userID = Int()
    
    var sumPrice = 0.0
    
    var downLayerController = ShoppingCartTableViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.orderInfoTable.tableFooterView = UIView()
        
        let getDefaultAddressParams = JSON(["userID":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "getDefaultAddress", params: getDefaultAddressParams, msg: "").processSocket()
        
        var sumPriceStr:String = "Sum: $"
        sumPriceStr += String(sumPrice)
        
        sumPriceLabel.text = sumPriceStr
        
    }
    
    func autoRefresh(){
        
        orderAddress = OrderAddress(idInDB:0,receiver:"",phone: "",passcode:"",road: "",isDefault: "")
        
        let getDefaultAddressParams = JSON(["userID":userID])
        
        ProcessNetworkMsg(relatedController: self, request: "getDefaultAddress", params: getDefaultAddressParams, msg: "").processSocket()

    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "viewDetailsFromOrder"{
            let controller = segue.destinationViewController as! ShoppingCartDetailsViewController
            let selectedItemsIdInDB = sender as! Int
            
            for item in itemsInOrder{
                
                if item.itemIdInDB == selectedItemsIdInDB{
                    controller.isAbleToPutInShoppingCart = false
                    controller.itemThumbnailUInt8Array = item.thumbnailUInt8Array
                    controller.itemName = item.itemName
                    controller.itemPrice = item.itemEachPrice
                    controller.itemSeller = item.itemSeller
                    controller.itemIntro = item.itemIntroduction
                    controller.itemIdInDB = item.itemIdInDB
                    controller.userID = userID
                }
            }
        }else{//viewMyAddresses
            let controller = segue.destinationViewController as! OrderAddressesTableViewController
            
            controller.userID = self.userID
            controller.downLayerController = self
        }
    }
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return self.itemsInOrder.count + 3

    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == 0 || indexPath.row == 2{
            return 50
        }else{
            return 100
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.row {
            
        case 0:
            let orderTitleCell = tableView.dequeueReusableCellWithIdentifier("orderTitleCell", forIndexPath: indexPath) as! OrderTitleCell
            orderTitleCell.configureTitle("address")
            
            return orderTitleCell

            
        case 1:
            let orderAddressCell = tableView.dequeueReusableCellWithIdentifier("orderAddressCell", forIndexPath: indexPath) as! OrderAddressCell
            orderAddressCell.configureAddressInfo(orderAddress.receiver, phone: orderAddress.phone, address: orderAddress.road + "\n" + orderAddress.passcode)
            
            return orderAddressCell
            
        case 2:
            let orderTitleCell = tableView.dequeueReusableCellWithIdentifier("orderTitleCell", forIndexPath: indexPath) as! OrderTitleCell
            orderTitleCell.configureTitle("item")
            
            return orderTitleCell
            
        default:
            let itemCell = tableView.dequeueReusableCellWithIdentifier("orderItemsCell", forIndexPath: indexPath) as! OrderItemsCell
            itemCell.configueItemInfo(itemsInOrder[indexPath.row - 3],relatedController: self)
            
            return itemCell
            
        }
        
        
    }
  
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        switch indexPath.row{
            
        case 0:
            break
            
        case 1:
            
            self.performSegueWithIdentifier("viewMyAddresses", sender: nil)
            break
            
        case 2:
            break
            
        default:
            let selectedItemIdInDB = itemsInOrder[indexPath.row - 3].itemIdInDB
            
            self.performSegueWithIdentifier("viewDetailsFromOrder", sender: selectedItemIdInDB)
            
            break
        }
        

    }
    
    
    
}
